r"""Generates LaTeX table fragments for the OCE-bates report from the two
result JSONs written by run_oce_bates.py and run_quadratic_oce_bates.py.
Run AFTER both of those have completed.
"""

from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "report_oce_bates" / "data"
DATA.mkdir(parents=True, exist_ok=True)

EXP_PATH = HERE / "report_historical" / "data" / "oce_bates_exponential_result.json"
QUAD_PATH = HERE / "report_historical" / "data" / "oce_bates_quadratic_result.json"


def write_table(path: Path, rows: list[tuple], header: tuple) -> None:
    with open(path, "w") as f:
        f.write("\\begin{tabular}{" + "l" * len(header) + "}\n\\toprule\n")
        f.write(" & ".join(header) + " \\\\\n\\midrule\n")
        for row in rows:
            f.write(" & ".join(str(x) for x in row) + " \\\\\n")
        f.write("\\bottomrule\n\\end{tabular}\n")


def _escape(label: str) -> str:
    return label.replace("_", "\\_")


def main() -> None:
    with open(EXP_PATH) as f:
        exp = json.load(f)
    with open(QUAD_PATH) as f:
        quad = json.load(f)

    pop = exp["population"]
    write_table(DATA / "population_table.tex", [
        ("Seed date (real, daily\\_data\\_cache)", pop["initial_date"]),
        ("Path count", str(pop["path_count"])),
        ("Horizon (business days)", str(pop["horizon_days"])),
        ("Feature count", str(pop["feature_count"])),
        ("Instrument count", str(pop["instrument_count"])),
        ("Generation time (s)", f"{pop['generation_seconds']:.1f}"),
    ], ("Quantity", "Value"))

    rows = []
    for label, d in (("Exponential (front\\_spot run\\_oce.py)", exp), ("Quadratic (front\\_spot run\\_quadratic\\_oce.py)", quad)):
        h = d["headline_heldout_conditional_drift"]
        rows.append((label, str(h["antithetic_pair_count"]), f"{h['mean_daily_conditional_drift']:.3e}",
                     f"{h['pair_based_standard_error']:.3e}", f"{h['z_score']:.2f}"))
    write_table(DATA / "headline_table.tex", rows,
                ("Objective", "Pairs", "Mean drift", "Pair SE", "$z$"))

    for name, d in (("exponential", exp), ("quadratic", quad)):
        ua = d["unconditional_spot_scaled_martingale_audit"]
        write_table(DATA / f"audit_{name}_table.tex", [
            ("Spot", str(ua["spot"]["tested_coordinate_count"]), f"{ua['spot']['max_absolute_z']:.2f}",
             f"{ua['spot']['rms_z']:.2f}", str(ua["spot"]["count_above_3"])),
            ("Options", str(ua["options"]["tested_coordinate_count"]), f"{ua['options']['max_absolute_z']:.2f}",
             f"{ua['options']['rms_z']:.2f}", str(ua["options"]["count_above_3"])),
            ("All instruments", str(ua["all_instruments"]["tested_coordinate_count"]),
             f"{ua['all_instruments']['max_absolute_z']:.2f}", f"{ua['all_instruments']['rms_z']:.2f}",
             str(ua["all_instruments"]["count_above_3"])),
        ], ("Coordinate group", "N tested", "Max $|z|$", "RMS $|z|$", "$N(|z|>3)$"))

        top = ua["all_instruments"]["top_absolute_z_coordinates"][:8]
        write_table(DATA / f"audit_{name}_top_table.tex", [
            (str(c["day_index"]), _escape(c["instrument_label"]), f"{c['mean']:+.5f}", f"{c['z_score']:+.2f}")
            for c in top
        ], ("Day", "Instrument", "Mean", "$z$"))

    print("Wrote OCE-bates report artifacts to", DATA)


if __name__ == "__main__":
    main()
