r"""Apply `quantdata.sdlv.daily.front_spot.run_quadratic_oce`'s quadratic
second-moment OCE conditional-no-arbitrage test methodology to the
bates_crc model, seeded from a real calibrated state in `daily_data_cache`.

Reuses `oce.py`'s `quadratic_second_moment_reward` (`a'R-|a|^2/2-
lambda*(a'R)^2/2`) directly, matching front_spot's own objective -- NOT
`negative_exponential_statistics` (an exponential-OCE-specific summary
that does not apply to this reward), consistent with
`run_quadratic_oce.py` itself not importing that function either.

Run (needs QUANTDATA_TEST_MODE=1; reads the local daily_data_cache):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/run_quadratic_oce_bates.py
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from quantdata.dysanos.bates_crc.real_data_study.run_oce_bates_shared import (
    _json_default,
    build_report,
    evaluate_policy,
    fit_policy,
    generate_split_population,
)
from quantdata.sdlv.daily.front_spot.oce import quadratic_second_moment_reward

HERE = Path(__file__).resolve().parent
RESULT_PATH = HERE / "report_historical" / "data" / "oce_bates_quadratic_result.json"

PATH_COUNT = 4_000
LAMBDA_SECOND_MOMENT = 1.0


def _reward(action, returns):
    return quadratic_second_moment_reward(action, returns, lambda_second_moment=LAMBDA_SECOND_MOMENT)


def _reward_summary(gain: np.ndarray) -> dict:
    values = gain.reshape(-1)
    mean = float(np.mean(values))
    se = float(np.std(values, ddof=1) / np.sqrt(len(values)))
    return {
        "mean_reward": mean, "standard_error": se,
        "z_vs_zero": mean / se if se > 0 else float("nan"),
        "minimum": float(np.min(values)), "maximum": float(np.max(values)),
    }


def main() -> None:
    population, date = generate_split_population(path_count=PATH_COUNT, seed=20261016)
    print(f"population generated: date={date}, path_count={PATH_COUNT}, "
          f"generation_seconds={population.generation_seconds:.1f}", flush=True)

    split = PATH_COUNT // 2
    policy, history = fit_policy(
        population.features[:split], population.returns[:split], population.active_mask,
        _reward, label="bates-oce-quadratic", epochs=100,
    )
    print(f"training complete: {len(history)} epochs, final loss={history[-1]:.6f}", flush=True)

    train_gain, train_action = evaluate_policy(
        policy, population.features[:split], population.returns[:split], population.active_mask, _reward,
    )
    heldout_gain, heldout_action = evaluate_policy(
        policy, population.features[split:], population.returns[split:], population.active_mask, _reward,
    )

    report = build_report(
        schema="bates-crc-quadratic-oce-v1",
        population=population, policy_label="bates-oce-quadratic", reward_fn=_reward,
        train_action=train_action, train_returns=population.returns[:split], train_gain=train_gain,
        heldout_action=heldout_action, heldout_returns=population.returns[split:], heldout_gain=heldout_gain,
        history=history,
        extra={
            "objective": {
                "requested": "sup_theta E[a(theta)'R - 0.5*|a(theta)|^2 - 0.5*lambda*(a(theta)'R)^2]",
                "lambda_second_moment": LAMBDA_SECOND_MOMENT,
                "note": "same quadratic second-moment OCE reward as front_spot's run_quadratic_oce.py, reusing oce.quadratic_second_moment_reward unchanged",
            },
            "training_reward_summary": _reward_summary(train_gain),
            "heldout_reward_summary": _reward_summary(heldout_gain),
        },
    )
    RESULT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(RESULT_PATH, "w") as f:
        json.dump(report, f, indent=2, default=_json_default)
    print("Wrote", RESULT_PATH, flush=True)
    print(json.dumps(report["headline_heldout_conditional_drift"], indent=2), flush=True)


if __name__ == "__main__":
    main()
