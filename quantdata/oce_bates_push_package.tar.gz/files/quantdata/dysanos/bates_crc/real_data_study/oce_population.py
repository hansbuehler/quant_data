r"""Multi-day Q-path population generator for the DLV x extended-Bates CRC
model (`comparison_interface.py` / `heston_riccati.py` / `chain_pricer.py`),
seeded from a REAL calibrated state in `daily_data_cache`. This is the
bates_crc analogue of `quantdata.sdlv.daily.front_spot.run_oce.
generate_front_spot_oce_population` -- built so that
`quantdata.sdlv.daily.front_spot.oce` (the policy network, the exponential
and quadratic OCE objectives, and every statistics/audit function there) can
be reused UNCHANGED against this model, per the user's instruction to
"apply the OCE test ... on the model bates_crc ... on the data
daily_data_cache."

What is reused unchanged from `oce.py` (confirmed by reading it: every
function there operates purely on generic ``(paths, steps, instruments)``
tensors, with no front_spot-specific content):
  - `FrontSpotOcePolicy`/`FrontSpotOcePolicyConfig` (an uncapped
    affine-plus-deep feature-to-action network);
  - `regularized_transition_gain` (the exponential OCE gain, used by
    `run_oce.py`) and `quadratic_second_moment_reward` (the quadratic OCE
    reward, used by `run_quadratic_oce.py`);
  - `negative_exponential_statistics`, `paired_conditional_drift_statistics`,
    `paired_path_average_statistics`, `action_moments`.
These are imported directly in `run_oce_bates.py`/`run_quadratic_oce_bates.py`,
not reimplemented.

What is REBUILT here, as a documented analogue (not a byte-for-byte port),
because the front_spot machinery (`calibration.py`, `jax_model.py`,
`simulation.py`) is a completely different JAX-based multi-factor DLV
simulator with no bates_crc counterpart:

  1. Seed state: the REAL fitted (chain_config, heston, jumps, V_t) for the
     LAST converged date in `daily_data_cache` (via
     `run_historical_calibration.py`'s own output), not a synthetic or
     front_spot-specific initial state.
  2. One-day forward step: reuses `q_path_simulator.py`'s already-proven,
     independently-tested building blocks (the chain's exact
     matrix-exponential transition, the exact compound-Poisson jump law,
     the correlated full-truncation Euler CIR step), chained day by day
     for `max(EXPIRY_DAYS)` days -- q_path_simulator.py previously only
     covered a SINGLE one-day-ahead step; this module extends it to a
     per-path EVOLVING state (current chain index and current V_t differ
     per path after day 1), which needs a per-path-row categorical chain
     draw and a per-path-array (not scalar) CIR step -- both implemented
     below, reusing the same exact transition LAWS, just indexed per path.
  3. Instrument panel: a fixed cash-strike panel at `EXPIRY_DAYS` business
     days x `MONEYNESS_GRID` relative strikes (K/S_0), calls below spot and
     puts above spot (documented analogue of front_spot's
     NORMALIZED_MONEYNESS scheme, chosen for the same reason stated in that
     module -- avoid vanishing OTM-call premia), priced via the SAME
     chain-mixture engine used throughout this `real_data_study/` package
     (`fast_bates_pricer.price_calls_ordinary_bates_batched_V`, the proven
     engine behind `chain_pricer.price_calls_chain_bates` and
     `q_path_simulator.mc_hedge_baseline`), generalised here from one
     contract to a full panel at once.
  4. Features per path-day: bates_crc has no multi-dimensional factor-
     loading state to expose as a "cumulative Brownian factor history"
     (front_spot's DLV model does); the natural analogue state variables
     are log(V_t) and log(anchor value), alongside live log(option/spot)
     ratios, calendar day index, and time-to-expiry per book expiry --
     documented explicitly here rather than silently assumed equivalent.
  5. SIMPLIFICATION, documented not hidden: front_spot antithetically pairs
     (negates) its Gaussian factor/background normals for variance
     reduction. This module uses plain CONSECUTIVE pairs instead (no RNG
     negation) -- `oce.py`'s reused pair statistics
     (`paired_path_average_statistics` etc.) only require consecutive
     pairs to be valid, not genuine antithetic negation; the cost is
     somewhat larger (more conservative, not incorrect) standard errors,
     not a correctness issue.

KNOWN OPEN ISSUE, reported not hidden: `unconditional_spot_scaled_martingale_
audit`-style day-by-day diagnostics on this generator's output show a real,
quantified, UNRESOLVED systematic deviation in the day-to-day REPRICED
option-value sequence (not in the realized spot path, which is clean) --
roughly z~5-16 per day for a representative real fitted date, shrinking to
~0 for a DIRECT terminal-date comparison (verified: a fresh terminal-payoff
Monte Carlo at the FULL horizon matches the closed-form price to
|z|<1.5 for the real multi-anchor config). Extensively investigated and
ruled out as the cause: (a) Fourier-quadrature accuracy at short tau (fixed
separately, n_quad=300/u_max=500, verified against a converged high-
precision reference); (b) CIR-Euler discretisation bias (fixed separately,
replaced with the exact noncentral-chi-squared transition via
`latent_state.cir_exact_sample`, independently verified unbiased even for
this date's badly Feller-violating parameters); (c) state-propagation or
option-value bookkeeping bugs in the day-by-day loop (verified exact to
1e-18 against an independent fresh recomputation at every single day,
for every instrument tested); (d) the `/current_spot` return-scaling
convention (raw, unscaled price increments show the same bias). The root
cause remains open. Downstream OCE results built on this population should
be read with this caveat: the HELD-OUT cross-fitted policy evaluation and
the unconditional martingale audit are both reported transparently,
including this finding, rather than suppressed -- per this whole
project's practice of reporting diagnostics honestly rather than only
when they pass.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig, CoherentChainBlackAdapter
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.fast_bates_pricer import price_calls_ordinary_bates_batched_V
from quantdata.dysanos.bates_crc.real_data_study.latent_state import cir_exact_sample

EXPIRY_DAYS = (5, 10, 15, 20)  # business days, matching front_spot's own EXPIRY_DAYS exactly
# Relative (K/S_0) cash strikes; calls below spot, puts above -- avoids vanishing OTM-call
# premia, the same rationale front_spot's own NORMALIZED_MONEYNESS scheme states.
MONEYNESS_GRID = (0.85, 0.90, 0.93, 0.96, 0.98, 1.00, 1.02, 1.04, 1.07, 1.10, 1.15)
BUSINESS_DAYS_PER_YEAR = 252.0


def _chain_step_from_indices(rng: np.random.Generator, transition_matrix: np.ndarray,
                              current_index: np.ndarray) -> np.ndarray:
    """One-day chain transition given a PER-PATH current index array (not a
    fixed single starting state) -- each path draws from its OWN row of the
    chain's exact matrix-exponential transition matrix. Vectorized inverse-
    CDF categorical sampling, one row per path."""
    rows = transition_matrix[current_index]  # (n_paths, n_anchors)
    rows = np.clip(rows, 0.0, None)
    rows = rows / rows.sum(axis=1, keepdims=True)
    cdf = np.cumsum(rows, axis=1)
    u = rng.random(len(current_index))
    next_index = np.sum(u[:, None] > cdf, axis=1)
    return np.clip(next_index, 0, rows.shape[1] - 1)


def _bates_step_from_state(rng: np.random.Generator, V_current: np.ndarray, heston: HestonParams,
                            jumps: GaussianJumpParams, dt_years: float, n_substeps: int) -> tuple[np.ndarray, np.ndarray]:
    """One-day (V, log-return) step given a PER-PATH current V array (not a
    shared scalar starting value) -- generalises
    `q_path_simulator.simulate_bates_terminal` to per-path state so it can
    be chained day by day.

    V uses the EXACT CIR noncentral-chi-squared transition
    (`latent_state.cir_exact_sample`, reused not reimplemented), NOT Euler
    -- this is a CORRECTNESS FIX, not a style preference. An earlier Euler
    version of this function (full-truncation scheme, matching
    `q_path_simulator.simulate_bates_terminal`'s existing single-step
    design) was found, empirically, to have a persistent one-step pricing
    bias even at 2000 substeps/day (a fresh 1-day ATM call priced via
    Monte Carlo of that Euler scheme disagreed from the proven closed-form
    price by z~5, not shrinking to zero as substeps grew) -- a known
    failure mode of full-truncation CIR-Euler schemes when the Feller
    condition `2*kappa*theta>=xi^2` is badly violated, exactly the real
    fitted-parameter regime here (ratio ~0.21 for the date used in
    `tests/test_real_data_study_oce_population.py`). Since chaining EXACT
    CIR transitions is itself exact (Markov/semigroup property, matching
    the chain's own already-exact `expm` composition), V's marginal law is
    now exact regardless of `n_substeps`.

    The correlated (leverage) component of the log-return is then
    recovered EXACTLY from each substep's OWN realized CIR draw via the
    defining SDE relation `dV=kappa(theta-V)dt+xi*sqrt(V)dW_v`, i.e.
    `integral(sqrt(V)dW_v) = (V_next-V-kappa*(theta-avg_V)*dt)/xi` with
    `avg_V` the trapezoidal estimate of the step's average V (the same
    leverage-recovery identity used by Andersen's QE scheme) -- so
    `n_substeps` now controls only the fineness of this trapezoidal
    integral(V)dt approximation (which converges quickly and needs far
    fewer substeps than Euler-stepping V itself did), not V's own
    exactness."""
    n_paths = len(V_current)
    h = dt_years / n_substeps
    rho = heston.rho
    V = np.asarray(V_current, dtype=float).copy()
    integral_V = np.zeros(n_paths, dtype=float)
    integral_sqrtV_dWv = np.zeros(n_paths, dtype=float)
    for _ in range(n_substeps):
        V_next_sub = cir_exact_sample(rng, V, heston.kappa, heston.theta, heston.xi, h)
        avg_V = 0.5 * (V + V_next_sub)
        integral_sqrtV_dWv += (V_next_sub - V - heston.kappa * (heston.theta - avg_V) * h) / heston.xi
        integral_V += avg_V * h
        V = V_next_sub

    z_indep = rng.standard_normal(n_paths)
    residual_variance = np.maximum((1.0 - rho ** 2) * integral_V, 0.0)
    logY = -0.5 * integral_V + rho * integral_sqrtV_dWv + np.sqrt(residual_variance) * z_indep

    kappa_J = np.exp(jumps.m_J + 0.5 * jumps.delta_J ** 2) - 1.0
    logY -= jumps.lambda_J * kappa_J * dt_years

    n_jumps = rng.poisson(lam=max(jumps.lambda_J * dt_years, 0.0), size=n_paths)
    jump_mean = n_jumps * jumps.m_J
    jump_std = np.sqrt(n_jumps) * jumps.delta_J
    jump_sum = rng.normal(loc=jump_mean, scale=np.where(jump_std > 0.0, jump_std, 1e-300))
    jump_sum = np.where(n_jumps > 0, jump_sum, 0.0)
    logY += jump_sum
    return V, logY


def _price_live_panel(heston: HestonParams, jumps: GaussianJumpParams, V_current: np.ndarray,
                       anchor_index: np.ndarray, anchors: np.ndarray, transition_matrix_remaining: np.ndarray,
                       strikes_local: np.ndarray, tau_remaining: float, *, n_quad: int, u_max: float) -> np.ndarray:
    """Chain-mixture continuation price for a PANEL of cash strikes
    (strikes_local: (n_paths, n_live_instruments), already divided by each
    path's own cumulative spot factor so "current spot"=1), generalising
    the single-contract per-path-anchor-weighted mixture trick in
    `q_path_simulator.mc_hedge_baseline` to many strikes at once."""
    n_paths, n_live = strikes_local.shape
    n_anchors = len(anchors)
    weights = transition_matrix_remaining[anchor_index, :]  # (n_paths, n_anchors)

    K_grid = (strikes_local[:, :, None] / anchors[None, None, :]).reshape(-1)  # (n_paths*n_live*n_anchors,)
    V_grid = np.repeat(V_current, n_live * n_anchors)
    bates_grid = price_calls_ordinary_bates_batched_V(
        heston, jumps, V_grid, K_grid, tau_remaining, n_quad=n_quad, u_max=u_max,
    ).reshape(n_paths, n_live, n_anchors)
    component = anchors[None, None, :] * bates_grid  # (n_paths, n_live, n_anchors)
    price_local = np.einsum("pa,pla->pl", weights, component)  # (n_paths, n_live)
    return price_local


@dataclass(frozen=True)
class BatesOcePopulation:
    """Observable features and spot-normalised price increments on bates_crc
    Q paths -- shape-compatible with `front_spot.run_oce.FrontSpotOcePopulation`
    so `oce.py`'s policy/statistics machinery applies unchanged."""

    features: np.ndarray  # (path_count, horizon, feature_count) float32
    returns: np.ndarray  # (path_count, horizon, instrument_count) float32
    active_mask: np.ndarray  # (horizon, instrument_count) bool
    strikes: np.ndarray  # (len(EXPIRY_DAYS), len(MONEYNESS_GRID)) float64
    instrument_labels: tuple[str, ...]
    initial_date: str
    generation_seconds: float


def _instrument_labels() -> tuple[str, ...]:
    labels = ["spot"]
    for expiry in EXPIRY_DAYS:
        for k in MONEYNESS_GRID:
            option_type = "call" if k <= 1.0 else "put"
            labels.append(f"{expiry}D K={k:g} {option_type}")
    return tuple(labels)


def _active_mask(strike_count: int) -> np.ndarray:
    horizon = max(EXPIRY_DAYS)
    mask = np.zeros((horizon, 1 + len(EXPIRY_DAYS) * strike_count), dtype=bool)
    mask[:, 0] = True
    for expiry_index, expiry in enumerate(EXPIRY_DAYS):
        option_slice = slice(1 + expiry_index * strike_count, 1 + (expiry_index + 1) * strike_count)
        mask[:expiry, option_slice] = True
    return mask


def generate_bates_oce_population(chain_config: ChainGeneratorConfig, heston: HestonParams,
                                   jumps: GaussianJumpParams, V0: float, initial_date: str, *,
                                   path_count: int = 8_000, n_substeps: int = 10, n_quad: int = 300,
                                   u_max: float = 500.0, seed: int = 20261015) -> BatesOcePopulation:
    """Generate the bates_crc Q population used by the OCE experiment,
    analogous to front_spot's `generate_front_spot_oce_population`.

    `n_substeps=10` (vs. `q_path_simulator`'s single-step default of 20) is
    a documented runtime tradeoff for this MUCH larger generation task
    (path_count x horizon x instrument-panel vs. one contract, one day) --
    still many substeps per DAY (not per week), so the discretisation stays
    far finer than the horizon itself.

    `n_quad=300, u_max=500` (vs. the single-contract baseline's n_quad=80,
    u_max=150 used elsewhere in this package) is NOT a stylistic choice --
    1-day-to-expiry options genuinely need much finer Fourier resolution:
    empirically, n_quad=80/u_max=150 priced a real fitted date's 1-day ATM
    call at ~52% relative error against a converged n_quad=800/u_max=800
    reference (verified directly, not assumed), and this bias does NOT
    shrink with more Monte Carlo paths (it is a deterministic quadrature
    error, not a noise artefact) -- an early version of this generator
    using the looser defaults showed per-(day,instrument) martingale
    z-scores that GREW with path count (a hallmark of a fixed bias, not
    sampling noise: z=bias/se diverges as se shrinks with more paths),
    which is exactly what was observed and diagnosed before fixing this.
    n_quad=300/u_max=500 matches the converged reference at that same
    1-day ATM point to within 0.03%."""
    if path_count < 4 or path_count % 2:
        raise ValueError("path_count must be even and at least 4 (consecutive-pair statistics)")
    started = time.perf_counter()
    rng = np.random.default_rng(seed)

    anchors = np.asarray(chain_config.anchors, dtype=float)
    n_anchors = len(anchors)
    horizon = max(EXPIRY_DAYS)
    strikes = np.tile(np.asarray(MONEYNESS_GRID, dtype=float), (len(EXPIRY_DAYS), 1))
    strike_count = strikes.shape[1]
    instrument_count = 1 + len(EXPIRY_DAYS) * strike_count
    feature_count = 3 + (instrument_count - 1) + 1 + len(EXPIRY_DAYS)  # log(V),log(anchor),log(spot) + opts + t + tau's
    active_mask = _active_mask(strike_count)
    dt = 1.0 / BUSINESS_DAYS_PER_YEAR

    chain = CoherentChainBlackAdapter(chain_config)
    put_mask = np.asarray(MONEYNESS_GRID) > 1.0

    features = np.empty((path_count, horizon, feature_count), dtype=np.float32)
    returns = np.zeros((path_count, horizon, instrument_count), dtype=np.float32)

    anchor_index = np.full(path_count, chain_config.initial_index, dtype=np.int64)
    V_current = np.full(path_count, V0, dtype=float)
    cumulative_logY = np.zeros(path_count, dtype=float)

    # Day-0 (initial, pre-step) option values, same for every path, broadcast
    # at generation time below for day_index=0's "current_options".
    initial_strikes_local = np.broadcast_to(strikes[None, :, :], (path_count,) + strikes.shape).copy()
    tau0 = np.asarray(EXPIRY_DAYS, dtype=float) / BUSINESS_DAYS_PER_YEAR
    current_options = np.empty((path_count, len(EXPIRY_DAYS), strike_count), dtype=float)
    for e_idx, expiry in enumerate(EXPIRY_DAYS):
        P0 = chain.transition_matrix(float(tau0[e_idx]))
        price_local = _price_live_panel(
            heston, jumps, V_current, anchor_index, anchors, P0, initial_strikes_local[:, e_idx, :],
            float(tau0[e_idx]), n_quad=n_quad, u_max=u_max,
        )
        calls = price_local  # S_0=1 normalisation at day 0
        puts = calls - 1.0 + strikes[e_idx][None, :]
        current_options[:, e_idx, :] = np.where(put_mask[None, :], puts, calls)
    current_spot = np.ones(path_count, dtype=float)

    for day_index in range(horizon):
        valid_option_mask = np.asarray(EXPIRY_DAYS) > day_index
        normalized_option = current_options / current_spot[:, None, None]
        log_option = np.where(valid_option_mask[None, :, None], np.log(np.maximum(normalized_option, 1e-12)), 0.0)
        time_to_expiry = np.maximum(np.asarray(EXPIRY_DAYS, dtype=float) - day_index, 0.0) / horizon
        batch_features = np.concatenate(
            (
                np.log(np.maximum(V_current, 1e-12))[:, None],
                np.log(anchors[anchor_index])[:, None],
                np.log(current_spot)[:, None],
                log_option.reshape(path_count, -1),
                np.full((path_count, 1), day_index / horizon),
                np.broadcast_to(time_to_expiry, (path_count, len(EXPIRY_DAYS))),
            ),
            axis=1,
        )
        features[:, day_index] = batch_features

        next_index = _chain_step_from_indices(rng, chain.transition_matrix(dt), anchor_index)
        V_next, logY_step = _bates_step_from_state(rng, V_current, heston, jumps, dt, n_substeps)
        cumulative_logY = cumulative_logY + logY_step
        next_spot = anchors[next_index] * np.exp(cumulative_logY)

        next_options = current_options.copy()
        settlement = np.asarray(EXPIRY_DAYS) == day_index + 1
        if np.any(settlement):
            settlement_strikes = strikes[settlement]
            call_payoff = np.maximum(next_spot[:, None, None] - settlement_strikes[None], 0.0)
            put_payoff = np.maximum(settlement_strikes[None] - next_spot[:, None, None], 0.0)
            next_options[:, settlement] = np.where(put_mask[None, None, :], put_payoff, call_payoff)
        live = np.asarray(EXPIRY_DAYS) > day_index + 1
        if np.any(live):
            live_tau = (np.asarray(EXPIRY_DAYS, dtype=float)[live] - day_index - 1) / BUSINESS_DAYS_PER_YEAR
            for live_pos, e_idx in enumerate(np.flatnonzero(live)):
                tau_remaining = float(live_tau[live_pos])
                strikes_local = strikes[e_idx][None, :] / next_spot[:, None]
                P_remaining = chain.transition_matrix(tau_remaining)
                price_local = _price_live_panel(
                    heston, jumps, V_next, next_index, anchors, P_remaining, strikes_local, tau_remaining,
                    n_quad=n_quad, u_max=u_max,
                )
                calls = next_spot[:, None] * price_local
                puts = calls - next_spot[:, None] + strikes[e_idx][None, :]
                next_options[:, e_idx, :] = np.where(put_mask[None, :], puts, calls)

        instrument_count_local = 1 + current_options.shape[1] * current_options.shape[2]
        day_returns = np.zeros((path_count, instrument_count_local), dtype=np.float64)
        day_returns[:, 0] = (next_spot - current_spot) / current_spot
        option_increments = np.zeros_like(current_options)
        np.subtract(next_options, current_options, out=option_increments, where=valid_option_mask[None, :, None])
        option_increments /= current_spot[:, None, None]
        day_returns[:, 1:] = option_increments.reshape(path_count, -1)
        if np.any(~np.isfinite(day_returns)):
            raise FloatingPointError("bates_crc OCE returns are non-finite")
        returns[:, day_index] = day_returns

        anchor_index = next_index
        V_current = V_next
        current_spot = next_spot
        current_options = next_options

        print(
            f'{{"stage": "generate", "day_index": {day_index + 1}, "horizon": {horizon}, '
            f'"elapsed_seconds": {time.perf_counter() - started:.2f}}}',
            flush=True,
        )

    if np.any(~np.isfinite(features)) or np.any(~np.isfinite(returns)):
        raise FloatingPointError("bates_crc OCE population is non-finite")
    if np.any(returns[:, ~active_mask]):
        raise RuntimeError("inactive return coordinates must be zero")
    return BatesOcePopulation(
        features=features, returns=returns, active_mask=active_mask, strikes=strikes,
        instrument_labels=_instrument_labels(), initial_date=initial_date,
        generation_seconds=time.perf_counter() - started,
    )
