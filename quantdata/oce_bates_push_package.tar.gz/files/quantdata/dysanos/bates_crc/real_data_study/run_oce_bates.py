r"""Apply `quantdata.sdlv.daily.front_spot.run_oce`'s exponential-OCE
conditional-no-arbitrage test methodology to the bates_crc model
(`quantdata/dysanos/bates_crc/`), seeded from a real calibrated state in
`daily_data_cache` (via `run_historical_calibration.py`'s output).

Reuses `oce.py`'s `regularized_transition_gain` (the exponential OCE gain
`a'R - epsilon*a'a/2`) directly, matching front_spot's own objective.

Run (needs QUANTDATA_TEST_MODE=1; reads the local daily_data_cache):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/run_oce_bates.py
"""

from __future__ import annotations

import json
from pathlib import Path

from quantdata.dysanos.bates_crc.real_data_study.run_oce_bates_shared import (
    _json_default,
    build_report,
    evaluate_policy,
    fit_policy,
    generate_split_population,
)
from quantdata.sdlv.daily.front_spot.oce import regularized_transition_gain

HERE = Path(__file__).resolve().parent
RESULT_PATH = HERE / "report_historical" / "data" / "oce_bates_exponential_result.json"

PATH_COUNT = 4_000
EPSILON = 1.0


def _reward(action, returns):
    return regularized_transition_gain(action, returns, epsilon=EPSILON)


def main() -> None:
    population, date = generate_split_population(path_count=PATH_COUNT, seed=20261015)
    print(f"population generated: date={date}, path_count={PATH_COUNT}, "
          f"generation_seconds={population.generation_seconds:.1f}", flush=True)

    split = PATH_COUNT // 2
    policy, history = fit_policy(
        population.features[:split], population.returns[:split], population.active_mask,
        _reward, label="bates-oce-exponential", epochs=100,
    )
    print(f"training complete: {len(history)} epochs, final loss={history[-1]:.6f}", flush=True)

    train_gain, train_action = evaluate_policy(
        policy, population.features[:split], population.returns[:split], population.active_mask, _reward,
    )
    heldout_gain, heldout_action = evaluate_policy(
        policy, population.features[split:], population.returns[split:], population.active_mask, _reward,
    )

    report = build_report(
        schema="bates-crc-exponential-oce-v1",
        population=population, policy_label="bates-oce-exponential", reward_fn=_reward,
        train_action=train_action, train_returns=population.returns[:split], train_gain=train_gain,
        heldout_action=heldout_action, heldout_returns=population.returns[split:], heldout_gain=heldout_gain,
        history=history,
        extra={
            "objective": {
                "requested": "sup_theta -E[exp(-a(theta)'R+0.5*epsilon*a(theta)'a(theta))]",
                "epsilon": EPSILON,
                "note": "same entropic OCE objective as front_spot's run_oce.py, reusing oce.regularized_transition_gain unchanged",
            },
        },
    )
    RESULT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(RESULT_PATH, "w") as f:
        json.dump(report, f, indent=2, default=_json_default)
    print("Wrote", RESULT_PATH, flush=True)
    print(json.dumps(report["headline_heldout_conditional_drift"], indent=2), flush=True)


if __name__ == "__main__":
    main()
