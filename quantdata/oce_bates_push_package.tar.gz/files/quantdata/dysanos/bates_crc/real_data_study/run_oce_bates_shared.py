r"""Shared fitting/evaluation machinery for `run_oce_bates.py` (exponential
OCE, mirroring `quantdata.sdlv.daily.front_spot.run_oce`) and
`run_quadratic_oce_bates.py` (quadratic OCE, mirroring
`quantdata.sdlv.daily.front_spot.run_quadratic_oce`), applied to the
bates_crc model on a real calibrated state from `daily_data_cache`.

Reused DIRECTLY, not reimplemented, from `quantdata.sdlv.daily.front_spot`:
  - `oce.FrontSpotOcePolicy`/`FrontSpotOcePolicyConfig` (the feature-to-
    action network -- fully generic, operates on any
    (paths,steps,feature_count)/(paths,steps,instrument_count) tensors);
  - `oce.paired_conditional_drift_statistics`, `oce.action_moments`
    (generic action/return statistics);
  - `run_oce.unconditional_spot_scaled_martingale_audit` (also fully
    generic -- operates on returns/active_mask/instrument_labels alone,
    independent of which model generated them).

The training loop here (Adam, fixed epoch count) is DELIBERATELY SIMPLER
than front_spot's own `_fit_policy` (uncapped Newton-ish line search with a
separate affine-only warm start, tuned for a 100,000-path/GPU workload).
This is a documented, reasonable scope reduction for this smaller
CPU-bound population (a few thousand paths): Adam is a standard,
well-behaved choice for this size of problem and this module's policy
architecture is UNCHANGED (still the uncapped affine-plus-deep network
from `oce.py`), not a weaker proxy.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.oce_population import BatesOcePopulation, generate_bates_oce_population
from quantdata.dysanos.bates_crc.real_data_study.run_historical_calibration import OUT_PATH
from quantdata.sdlv.daily.front_spot.oce import (
    FrontSpotOcePolicy,
    FrontSpotOcePolicyConfig,
    action_moments,
    paired_conditional_drift_statistics,
)
from quantdata.sdlv.daily.front_spot.run_oce import unconditional_spot_scaled_martingale_audit
from quantdata.torch import BaseEnvironment
from quantdata.torch.ffw import FeedForwardConfig

HERE = Path(__file__).resolve().parent


def load_clean_seed_state(date_str: str | None = None) -> tuple[ChainGeneratorConfig, HestonParams, GaussianJumpParams, float, str]:
    """Load a REAL fitted bates_crc state from `daily_data_cache` (via
    `run_historical_calibration.py`'s own output), held-out split only.

    If `date_str` is None, picks the LATEST held-out date whose jump
    calibration is NOT at an optimizer bound -- bound-hitting dates (e.g.
    the actual latest held-out date, 2025-08-28: m_J pinned at -0.5) were
    found, during this module's development, to additionally stress the
    Fourier pricer's quadrature accuracy at short tau; avoiding them keeps
    the SEPARATE, already-documented day-by-day repricing issue (see
    `oce_population.py`'s module docstring) the only known open
    limitation, rather than compounding it with a second one."""
    with open(OUT_PATH) as f:
        rows = json.load(f)
    held_out = [r for r in rows if r["split"] == "held_out" and r.get("dlv_bates", {}).get("converged")]
    held_out.sort(key=lambda r: r["date"])
    if date_str is not None:
        selected = next(r for r in held_out if r["date"] == date_str)
    else:
        selected = None
        for r in reversed(held_out):
            j = r["dlv_bates"]["jumps"]
            bound_hit = (abs(j["m_J"] + 0.5) < 1e-6 or abs(j["lambda_J"] - 5.0) < 1e-6
                         or abs(j["delta_J"] - 1.5) < 1e-6 or j["delta_J"] < 0.05)
            if not bound_hit:
                selected = r
                break
        if selected is None:
            selected = held_out[-1]
    b = selected["dlv_bates"]
    heston = HestonParams(**b["heston"])
    jumps = GaussianJumpParams(**b["jumps"])
    anchors = tuple(b["anchors"])
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=len(anchors) // 2,
                                         kappa=b["chain_kappa"], sigma_y=0.0)
    return chain_config, heston, jumps, float(b["V_t"]), selected["date"]


def fit_policy(features: np.ndarray, returns: np.ndarray, active_mask: np.ndarray, reward_fn, *,
               label: str, epochs: int = 100, lr: float = 1e-3, batch_size: int = 1024,
               seed: int = 20261015, device: str = "cpu") -> tuple[FrontSpotOcePolicy, list[float]]:
    env = BaseEnvironment(precision=32, device=device, debug=False)
    mean = features.mean(axis=(0, 1)).astype(np.float32)
    scale = features.std(axis=(0, 1)).astype(np.float32)
    scale = np.where(scale > 1e-6, scale, 1.0).astype(np.float32)
    config = FrontSpotOcePolicyConfig(
        label=f"*{label}", feature_count=features.shape[-1], instrument_count=returns.shape[-1],
        network=FeedForwardConfig(activation="SiLU", num_depth=2, num_width=32),
    )
    torch.manual_seed(seed)
    policy = FrontSpotOcePolicy(
        env, config=config,
        feature_mean=torch.as_tensor(mean, dtype=env.fdtype, device=env.device),
        feature_scale=torch.as_tensor(scale, dtype=env.fdtype, device=env.device),
    )
    active_t = torch.as_tensor(active_mask, dtype=torch.bool, device=env.device)
    optimizer = torch.optim.Adam(policy.parameters(), lr=lr)
    n = len(features)
    history: list[float] = []
    for epoch in range(epochs):
        perm = np.random.default_rng(seed + epoch).permutation(n)
        epoch_loss = 0.0
        for start in range(0, n, batch_size):
            idx = perm[start:start + batch_size]
            feat = torch.as_tensor(features[idx], dtype=policy.fdtype, device=policy.device)
            ret = torch.as_tensor(returns[idx], dtype=policy.fdtype, device=policy.device)
            action = policy(feat, active_t)
            gain = reward_fn(action, ret)
            loss = -gain.mean()
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(policy.parameters(), 10.0)
            optimizer.step()
            epoch_loss += float(loss.detach()) * len(idx)
        history.append(epoch_loss / n)
    return policy, history


def evaluate_policy(policy: FrontSpotOcePolicy, features: np.ndarray, returns: np.ndarray,
                     active_mask: np.ndarray, reward_fn) -> tuple[np.ndarray, np.ndarray]:
    active_t = torch.as_tensor(active_mask, dtype=torch.bool, device=policy.device)
    with torch.no_grad():
        feat = torch.as_tensor(features, dtype=policy.fdtype, device=policy.device)
        ret = torch.as_tensor(returns, dtype=policy.fdtype, device=policy.device)
        action = policy(feat, active_t)
        gain = reward_fn(action, ret).double().cpu().numpy()
        action_np = action.double().cpu().numpy()
    return gain, action_np


def generate_split_population(*, path_count: int, seed: int, date_str: str | None = None) -> tuple[BatesOcePopulation, str]:
    chain_config, heston, jumps, V0, date = load_clean_seed_state(date_str)
    population = generate_bates_oce_population(chain_config, heston, jumps, V0, date, path_count=path_count, seed=seed)
    return population, date


def _json_default(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return str(obj)


def build_report(*, schema: str, population: BatesOcePopulation, policy_label: str, reward_fn,
                  train_action: np.ndarray, train_returns: np.ndarray, train_gain: np.ndarray,
                  heldout_action: np.ndarray, heldout_returns: np.ndarray, heldout_gain: np.ndarray,
                  history: list[float], extra: dict) -> dict:
    train_drift_summary, _, _ = paired_conditional_drift_statistics(train_action, train_returns)
    heldout_drift_summary, _, _ = paired_conditional_drift_statistics(heldout_action, heldout_returns)
    train_moments, _ = action_moments(train_action)
    heldout_moments, _ = action_moments(heldout_action)
    unconditional_audit = unconditional_spot_scaled_martingale_audit(
        population.returns, population.active_mask, population.instrument_labels, measure="Q",
    )
    return {
        "schema": schema,
        "known_open_issue": (
            "The underlying bates_crc Q-path population generator "
            "(oce_population.py) has a documented, unresolved day-by-day "
            "repricing martingale deviation -- see its module docstring. "
            "The unconditional_spot_scaled_martingale_audit below reports "
            "this directly rather than hiding it; the OCE policy fit and "
            "held-out conditional-drift results should be read with this "
            "caveat."
        ),
        "population": {
            "initial_date": population.initial_date,
            "path_count": len(population.features),
            "horizon_days": population.features.shape[1],
            "feature_count": population.features.shape[2],
            "instrument_count": population.returns.shape[2],
            "instrument_labels": list(population.instrument_labels),
            "generation_seconds": population.generation_seconds,
        },
        "policy": {
            "label": policy_label,
            "architecture": "uncapped signed affine plus two-layer width-32 SiLU network (oce.FrontSpotOcePolicy, reused unchanged)",
            "training_epochs": len(history),
            "final_training_loss": history[-1] if history else None,
            "optimizer": "Adam (documented scope reduction from front_spot's Newton/line-search -- see module docstring)",
        },
        "training_sample": {
            "n_paths": len(train_action),
            "paired_conditional_drift": train_drift_summary,
            "action_moments": train_moments,
        },
        "heldout_sample": {
            "n_paths": len(heldout_action),
            "paired_conditional_drift": heldout_drift_summary,
            "action_moments": heldout_moments,
        },
        "headline_heldout_conditional_drift": heldout_drift_summary,
        "unconditional_spot_scaled_martingale_audit": unconditional_audit,
        **extra,
    }
