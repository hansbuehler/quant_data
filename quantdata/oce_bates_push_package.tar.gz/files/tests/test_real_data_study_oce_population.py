"""Tests for real_data_study.oce_population -- the multi-day bates_crc Q-path
population generator built to apply front_spot's run_oce.py/run_quadratic_oce.py
OCE methodology to the bates_crc model.

Per the module's own docstring, there is a KNOWN, DOCUMENTED, UNRESOLVED
day-by-day repricing martingale deviation. These tests check what IS
verified correct (the exact-CIR one-step marginal law, the chain-mixture
pricer's exactness against the proven reference, output well-formedness)
and separately ENCODE the open issue as an explicit regression-tracking
assertion (not silently skipped) -- if a future fix resolves it, this test
will start failing as a deliberate reminder to update the docstring."""

from __future__ import annotations

import numpy as np
import pytest

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig, CoherentChainBlackAdapter
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.chain_pricer import price_calls_chain_bates
from quantdata.dysanos.bates_crc.real_data_study.oce_population import (
    EXPIRY_DAYS,
    MONEYNESS_GRID,
    _active_mask,
    _bates_step_from_state,
    _instrument_labels,
    _price_live_panel,
    generate_bates_oce_population,
)

# A representative real fitted state (2025-08-14, badly Feller-violating:
# 2*kappa*theta/xi^2 ~ 0.21), used throughout -- not bound-hitting, unlike
# the raw latest held-out date (see run_oce_bates_shared.load_clean_seed_state).
HESTON = HestonParams(kappa=8.841793213907524, theta=0.0330460951278101,
                       xi=1.6580914038961705, rho=-0.9044632293188142)
JUMPS = GaussianJumpParams(lambda_J=0.01565383097251491, m_J=-0.20092134913021634,
                            delta_J=0.6680129415118682)
V0 = 0.005
ANCHORS = (0.9689738182153914, 0.9792074184434829, 0.9895490985511951, 1.0,
           1.0105612763066594, 1.0212340931705444, 1.0320196286022991)


def test_active_mask_matches_expected_count():
    mask = _active_mask(len(MONEYNESS_GRID))
    expected = sum(EXPIRY_DAYS) * len(MONEYNESS_GRID) + max(EXPIRY_DAYS)  # spot active every day
    assert int(mask.sum()) == expected


def test_instrument_labels_count_and_order():
    labels = _instrument_labels()
    assert labels[0] == "spot"
    assert len(labels) == 1 + len(EXPIRY_DAYS) * len(MONEYNESS_GRID)
    assert labels[1].startswith(f"{EXPIRY_DAYS[0]}D")


def test_exact_cir_step_marginal_matches_analytic_cir_moments():
    rng = np.random.default_rng(0)
    n = 300_000
    V_current = np.full(n, V0)
    V_next, _ = _bates_step_from_state(rng, V_current, HESTON, GaussianJumpParams(lambda_J=0.0, m_J=0.0, delta_J=1.0),
                                        dt_years=1 / 252, n_substeps=1)
    dt = 1 / 252
    analytic_mean = V0 * np.exp(-HESTON.kappa * dt) + HESTON.theta * (1 - np.exp(-HESTON.kappa * dt))
    se = V_next.std(ddof=1) / np.sqrt(n)
    assert abs(V_next.mean() - analytic_mean) < 5 * se


def test_price_live_panel_matches_proven_reference_at_short_and_long_tau():
    chain_config = ChainGeneratorConfig(anchors=ANCHORS, initial_index=len(ANCHORS) // 2, kappa=0.2, sigma_y=0.0)
    anchors_arr = np.asarray(ANCHORS)
    chain = CoherentChainBlackAdapter(chain_config)
    for tau in (1 / 252, 5 / 252, 20 / 252):
        for strike in (0.95, 1.00, 1.05):
            ref = price_calls_chain_bates(chain_config, HESTON, JUMPS, V0, np.array([strike]), np.array([tau]),
                                           n_quad=300, u_max=500.0)[0]
            anchor_index = np.full(1, chain_config.initial_index, dtype=np.int64)
            P = chain.transition_matrix(tau)
            mine = _price_live_panel(HESTON, JUMPS, np.full(1, V0), anchor_index, anchors_arr, P,
                                      np.full((1, 1), strike), tau, n_quad=300, u_max=500.0)
            assert abs(mine.ravel()[0] - ref) < 1e-9


def test_generate_bates_oce_population_shapes_and_finiteness():
    chain_config = ChainGeneratorConfig(anchors=ANCHORS, initial_index=len(ANCHORS) // 2, kappa=0.2, sigma_y=0.0)
    pop = generate_bates_oce_population(chain_config, HESTON, JUMPS, V0, "2025-08-14", path_count=40, n_substeps=4)
    horizon = max(EXPIRY_DAYS)
    instrument_count = 1 + len(EXPIRY_DAYS) * len(MONEYNESS_GRID)
    assert pop.features.shape[:2] == (40, horizon)
    assert pop.returns.shape == (40, horizon, instrument_count)
    assert np.all(np.isfinite(pop.features))
    assert np.all(np.isfinite(pop.returns))
    assert not np.any(pop.returns[:, ~pop.active_mask])


def test_generate_bates_oce_population_rejects_odd_path_count():
    chain_config = ChainGeneratorConfig(anchors=ANCHORS, initial_index=len(ANCHORS) // 2, kappa=0.2, sigma_y=0.0)
    with pytest.raises(ValueError):
        generate_bates_oce_population(chain_config, HESTON, JUMPS, V0, "2025-08-14", path_count=41)


def test_known_open_issue_day_by_day_repricing_shows_detectable_drift():
    """Regression-tracking test for the module's documented OPEN issue (see
    its docstring): the day-to-day repriced option-value sequence shows a
    real, non-noise, systematic deviation for a representative real fitted
    date -- NOT asymptotically vanishing with more paths. This test
    verifies the finding is still present (a sizeable z-score on a direct,
    minimal one-step check), so it is tracked explicitly rather than
    silently assumed fixed. If a future change resolves the root cause,
    this assertion should start FAILING -- that is the intended signal to
    update this test and the module's docstring together, not a reason to
    quietly loosen the threshold."""
    chain_config = ChainGeneratorConfig(anchors=(1.0,), initial_index=0, kappa=0.1, sigma_y=0.0)
    anchors = np.asarray((1.0,))
    chain = CoherentChainBlackAdapter(chain_config)
    rng = np.random.default_rng(42)
    dt = 1 / 252
    n = 300_000
    V_current0 = np.full(n, V0)
    V_next, logY_step = _bates_step_from_state(rng, V_current0, HESTON, JUMPS, dt, 20)
    next_spot = anchors[0] * np.exp(logY_step)
    K = 1.00
    payoff = np.maximum(next_spot - K, 0.0)
    mc_price = payoff.mean()
    mc_se = payoff.std(ddof=1) / np.sqrt(n)
    closed_form = _price_live_panel(HESTON, JUMPS, np.full(1, V0), np.full(1, 0, dtype=np.int64), anchors,
                                     chain.transition_matrix(dt), np.full((1, 1), K), dt,
                                     n_quad=300, u_max=500.0).ravel()[0]
    z = (mc_price - closed_form) / mc_se
    assert abs(z) > 3.0, (
        "the known open day-by-day repricing deviation (see oce_population.py's module "
        "docstring) was NOT detected -- if this is because the root cause has been fixed, "
        "update the docstring and loosen/remove this regression-tracking assertion"
    )
