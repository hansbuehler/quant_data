"""Tests for real_data_study.run_oce_bates_shared -- the fitting/evaluation
machinery shared by run_oce_bates.py (exponential OCE) and
run_quadratic_oce_bates.py (quadratic OCE), reusing
quantdata.sdlv.daily.front_spot.oce directly (not reimplemented)."""

from __future__ import annotations

import numpy as np
import torch

from quantdata.dysanos.bates_crc.real_data_study.run_oce_bates_shared import (
    build_report,
    evaluate_policy,
    fit_policy,
    load_clean_seed_state,
)
from quantdata.sdlv.daily.front_spot.oce import (
    quadratic_second_moment_reward,
    regularized_transition_gain,
)


def _synthetic_population(seed: int, n_paths: int = 400, horizon: int = 4, instrument_count: int = 3):
    rng = np.random.default_rng(seed)
    features = rng.normal(size=(n_paths, horizon, 5)).astype(np.float32)
    # instrument 0 ("spot") has a genuine, learnable linear signal from feature 0;
    # the rest are pure noise -- a policy that only acts on instrument 0 should win.
    returns = rng.normal(0, 0.01, size=(n_paths, horizon, instrument_count)).astype(np.float32)
    returns[:, :, 0] += 0.02 * features[:, :, 0]
    active_mask = np.ones((horizon, instrument_count), dtype=bool)
    return features, returns, active_mask


def test_load_clean_seed_state_returns_a_non_bound_hitting_held_out_date():
    chain_config, heston, jumps, V0, date = load_clean_seed_state()
    assert date.startswith("2025-")  # held-out split
    assert V0 > 0.0
    assert abs(jumps.m_J + 0.5) > 1e-6, "selected date should not be bound-hitting (m_J pinned at -0.5)"
    assert len(chain_config.anchors) >= 3


def test_load_clean_seed_state_honours_explicit_date():
    _, _, _, _, date = load_clean_seed_state("2025-08-14")
    assert date == "2025-08-14"


def test_fit_policy_reduces_loss_and_produces_finite_actions():
    features, returns, active_mask = _synthetic_population(seed=1)

    def reward(action, ret):
        return regularized_transition_gain(action, ret, epsilon=1.0)

    policy, history = fit_policy(features, returns, active_mask, reward, label="test-policy", epochs=20, batch_size=128)
    assert len(history) == 20
    assert history[-1] <= history[0] + 1e-6  # training loss should not increase
    gain, action = evaluate_policy(policy, features, returns, active_mask, reward)
    assert np.all(np.isfinite(gain))
    assert np.all(np.isfinite(action))
    assert action.shape == returns.shape


def test_fit_policy_learns_to_exploit_a_known_synthetic_signal():
    # With a genuine, learnable linear signal in instrument 0, a trained
    # policy's mean reward should clearly beat a zero (untrained-equivalent)
    # policy on the SAME data -- a basic sanity check that optimisation is
    # actually happening, not just running without crashing.
    features, returns, active_mask = _synthetic_population(seed=2, n_paths=800)

    def reward(action, ret):
        return quadratic_second_moment_reward(action, ret, lambda_second_moment=0.1)

    policy, history = fit_policy(features, returns, active_mask, reward, label="test-quad-policy", epochs=40, batch_size=256)
    gain, action = evaluate_policy(policy, features, returns, active_mask, reward)
    zero_gain = reward(torch.zeros_like(torch.as_tensor(action)), torch.as_tensor(returns)).numpy()
    assert gain.mean() > zero_gain.mean()


def test_build_report_has_expected_top_level_keys():
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class FakePopulation:
        features: np.ndarray
        returns: np.ndarray
        active_mask: np.ndarray
        strikes: np.ndarray
        instrument_labels: tuple
        initial_date: str
        generation_seconds: float

    features, returns, active_mask = _synthetic_population(seed=3, n_paths=200)
    pop = FakePopulation(features=features, returns=returns, active_mask=active_mask,
                          strikes=np.zeros((1, 1)), instrument_labels=("spot", "a", "b"),
                          initial_date="2025-08-14", generation_seconds=1.23)

    def reward(action, ret):
        return regularized_transition_gain(action, ret, epsilon=1.0)

    policy, history = fit_policy(features, returns, active_mask, reward, label="test", epochs=5, batch_size=128)
    gain, action = evaluate_policy(policy, features, returns, active_mask, reward)
    report = build_report(
        schema="test-schema", population=pop, policy_label="test", reward_fn=reward,
        train_action=action, train_returns=returns, train_gain=gain,
        heldout_action=action, heldout_returns=returns, heldout_gain=gain,
        history=history, extra={},
    )
    assert report["schema"] == "test-schema"
    assert "known_open_issue" in report
    assert "unconditional_spot_scaled_martingale_audit" in report
    assert "headline_heldout_conditional_drift" in report
    assert report["population"]["initial_date"] == "2025-08-14"
