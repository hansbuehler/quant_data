# oce_bates push package

Built 2026-10-15. Everything in `files/` is laid out with paths **relative
to the `quant_data` repo root** (the repo `quant_data-main` was extracted
from -- see `quant_data_push_package.tar.gz`'s own MANIFEST for the
provenance reasoning, likely `github.com/hansbuehler/quant_data`).

This is a **raw file overlay**, not a git patch (no local `.git` for this
repo to diff against). To apply:

```bash
cd /path/to/your/local/clone/of/quant_data
rsync -a /Users/blanka/Agentic/oce_bates_push_package/files/ ./
git status        # review everything before staging
git add <files>
git commit -m "..."
git push
```

**Review before pushing** -- same caveat as the earlier package: this
reflects the state as of 2026-10-15 and may not match upstream `main` if
it has moved since.

## What this is

Applies `quantdata/sdlv/daily/front_spot/run_oce.py` and
`run_quadratic_oce.py`'s conditional no-arbitrage OCE test methodology to
the DLV x extended-Bates CRC model (`quantdata/dysanos/bates_crc/`),
seeded from a real calibrated state in `daily_data_cache`. The policy
network and both OCE objectives (`front_spot/oce.py`) are reused
UNCHANGED; only the front_spot-specific JAX simulator needed a bates_crc
analogue.

**Read `quantdata/dysanos/bates_crc/real_data_study/report_oce_bates/
OceBatesReport.pdf` first** -- it is the primary, human-readable summary
of everything below (method, the two bugs found and fixed, headline
results, the martingale audit, and the one known open issue), already
compiled from the LaTeX source also included here.

## Contents (16 files)

**Source** (`quantdata/dysanos/bates_crc/real_data_study/`):
- `oce_population.py` -- the multi-day bates_crc Q-path population
  generator (chain + exact-CIR/jump Bates factor, chained day by day over
  a 20-business-day horizon, pricing a 45-instrument panel). Its module
  docstring documents a KNOWN, UNRESOLVED open issue -- read it before
  interpreting the results below.
- `run_oce_bates_shared.py` -- shared fit/evaluate machinery, reusing
  `front_spot/oce.py`'s `FrontSpotOcePolicy` and statistics functions
  directly.
- `run_oce_bates.py` -- exponential-OCE driver (mirrors `run_oce.py`).
- `run_quadratic_oce_bates.py` -- quadratic-OCE driver (mirrors
  `run_quadratic_oce.py`).
- `generate_oce_bates_report_artifacts.py` -- builds the LaTeX table
  fragments consumed by the report below from the two result JSONs.

**Results** (`report_historical/data/`):
- `oce_bates_exponential_result.json`, `oce_bates_quadratic_result.json`
  -- full run output (population/policy metadata, training/held-out
  statistics, the unconditional spot-scaled martingale audit).

**Report** (`report_oce_bates/`):
- `OceBatesReport.tex` / `OceBatesReport.pdf` (compiled, 4 pages) +
  `data/*.tex` table fragments.

**Tests** (`tests/`):
- `test_real_data_study_oce_population.py` (7 tests) -- exact-CIR
  marginal law, chain-mixture pricer exactness against the proven
  reference, output well-formedness, AND an explicit regression-tracking
  assertion for the known open issue (see below).
- `test_real_data_study_run_oce_bates_shared.py` (5 tests) -- seed-state
  loading, policy fit/evaluate shapes and optimisation sanity, report
  structure.

All 12 pass; 132/132 across the full relevant existing suite with these
added (confirmed before packaging).

## Headline finding -- read before using these results

Both OCE objectives give a held-out conditional-drift $z\approx38.7$.
**This is NOT evidence against the bates_crc model's risk-neutral
measure.** It is the expected, predictable consequence of the trained
policy exploiting a real, quantified, but UNRESOLVED day-by-day
multi-instrument repricing deviation in the population generator (see
`oce_population.py`'s docstring and the report's Sec. 5 "Known open
issue" for the full, extensively-isolated investigation: the pricing
formula, state bookkeeping, and terminal-date distribution were all
independently verified exact; only the day-to-day intermediate repricing
sequence under the full multi-anchor chain mixture shows the deviation).
The unconditional martingale audit confirms this precisely: spot
coordinates are clean (max $|z|\approx2$), option coordinates are not
(max $|z|\approx30$, concentrated at ATM/near-ATM strikes on
settlement-adjacent days).

**What IS a genuine, usable result**: the OCE test pipeline itself
(two-fold cross-fit, `front_spot`'s own policy network and reward
functions reused unmodified, the unconditional martingale audit) is
demonstrated working correctly -- it detects real predictable drift where
present and correctly localises where it lives. Once the open issue is
resolved, re-running `run_oce_bates.py`/`run_quadratic_oce_bates.py`
unchanged would give an interpretable answer about the model itself.

## Two real bugs found and fixed during development

1. **Fourier quadrature bias at short time-to-expiry**: the usual
   single-contract defaults (`n_quad=80`, `u_max=150`) priced a real
   1-day ATM call ~52% off a converged high-precision reference. Fixed:
   `n_quad=300`, `u_max=500`.
2. **CIR-Euler discretisation bias**: the representative date badly
   violates the Feller condition ($2\kappa\theta/\xi^2\approx0.21$).
   Fixed by replacing Euler with the exact noncentral-chi-squared CIR
   transition (`latent_state.cir_exact_sample`, reused not
   reimplemented), with the leverage/correlation term recovered exactly
   from each substep's own realised path (the same identity used in
   Andersen's QE scheme).
