# quant_data push package

Built 2026-10-14. Everything in `files/` is laid out with paths **relative to
the `quant_data` repo root** (i.e. what you get from `github.com/.../quant_data`,
the repo whose `main`-branch zip export extracts to a folder named
`quant_data-main` — matching `/Users/blanka/Agentic/quant_data-main`, and
whose README links to `https://hansbuehler.github.io/quant_data/`).

This is a **raw file overlay**, not a git patch: there is no local `.git` for
this repo (it was extracted from a zip, not cloned), so a proper diff/patch
against the real upstream history isn't possible from here. To apply:

```bash
cd /path/to/your/local/clone/of/quant_data   # a real git clone, on the branch you want to update
rsync -a /Users/blanka/Agentic/quant_data_push_package/files/ ./
git status        # review everything before staging
git add <files>
git commit -m "..."
git push
```

**Review before pushing.** This package was assembled by diffing two local
trees (a zip extracted 2026-10-12, vs. the working tree used across this
session) and may not reflect the exact current state of the real upstream
`main` branch if it has moved since 2026-10-12. Check `git status`/`git diff`
in your real clone before committing, and resolve any conflicts there rather
than force-overwriting.

## What's included (101 files)

### New files (97)

**`dlv_no_arbitrage_tests/`** (8 files) — a self-contained DLV no-arbitrage
test suite (Heston control experiment, Level 0/1 admissibility, Level 2 Ito
drift residual), already committed to the Agentic-repo history (commits
`b70df8a`, `3b8cea0`, `99bace0`, 2026-09-15) but never pushed upstream:
`__init__.py`, `common.py`, `heston.py`, `heston_control_experiment.py`,
`level0_level1_admissibility.py`, `level2_ito_drift_residual.py`, `README.md`,
`TASK_SPEC.tex`.

**`quantdata/dysanos/bates_crc/real_data_study/`** — the Historical Simulator
task (full P/Q specification, latent-state particle filter + TV-denoising,
chronological calibration, arbitrage diagnostics, OCE hedge-ratio
optimization, and the Renyuan-grid data converter), 2026-10-06/07:
- Source: `latent_state.py`, `historical_dynamics.py`, `arbitrage_diagnostics.py`,
  `dynamics_comparison.py`, `q_path_simulator.py`, `daily_cache_loader.py`,
  `convert_to_renyuan_grid.py`
- Drivers: `run_historical_calibration.py`, `run_historical_latent_state.py`,
  `run_historical_arbitrage_diagnostics.py`, `run_historical_oce_test.py`,
  `run_historical_oce_panel_test.py`, `generate_historical_report_artifacts.py`
- Docs: `DAILY_DATA_PROVENANCE.md`, `HISTORICAL_PQ_SPECIFICATION.md`
- `report_historical/` — compiled PDF + LaTeX sources + figures + table
  fragments (the full Historical Simulator report)
- `report/data/historical_{arbitrage_diagnostics,calibration,latent_state}.json`

**Test fixtures** (24 files) — WIDB raw/enrich/arbfree/training cache entries
for the 6 real SPX dates used throughout the CRC/Bates work (2005-11-21,
2010-07-07, 2011-07-07, 2024-03-05, 2024-12-26, 2025-01-03), under
`tests/stored_data/`.

**Tests** (18 files) — `test_bates_crc_*.py` (7), `test_flex_crc_extension.py`,
`test_real_data_study_*.py` (10, for the Historical Simulator modules above).

**One notebook**: `quantdata/dysanos/notebooks/test.ipynb`.

### Modified files (4)

All are additive extensions to files that already exist upstream; no content
was removed from the upstream version, only added:

- `quantdata/dysanos/bates_crc/real_data_study/chain_bates_calibration.py` —
  adds an optional `warm_start_x0` parameter to `calibrate_chain_bates` for
  chronological warm-starting (backward compatible, default `None`).
- `quantdata/dysanos/bates_crc/real_data_study/config.py` — adds
  `HISTORICAL_WEEKLY_STRIDE`, `HISTORICAL_TRAIN_END`,
  `HISTORICAL_VALIDATION_END` constants.
- `quantdata/dysanos/bates_crc/real_data_study/crc_real_sequence.py` — fixes
  an unguarded `OverflowError` in `evaluate_transition`'s dominating-envelope
  construction (moves it inside the existing `try/except` guard, widens the
  caught exception type).
- `quantdata/dysanos/bates_crc/real_data_study/fast_bates_pricer.py` — adds
  `price_calls_ordinary_bates_batched_V`, a vectorized-over-paths pricer
  variant needed for Monte Carlo repricing in `q_path_simulator.py`.

## What was deliberately EXCLUDED

A direct file-diff between the two local trees also showed 30 other files
differing (`.github/workflows/*`, `.gitignore`, `.vscode/settings.json`,
`AGENTS.md`, `pyproject.toml`, `quantdata/dysanos/flex/*` (11 files),
`quantdata/dysanos/tangent_levy/*` (3 files), `quantdata/sanos/sanos_tools.py`,
`quantdata/dysanos/tex/*`, top-level `STYLE_GUIDE.md`, and 5 test files under
`tests/quantdata/` / `tests/test_flex_*`). **None of these were authored or
edited in this session** — they differ only because the two local trees were
extracted/checked out from different points in the upstream repo's own
history (unrelated upstream work by other collaborators landed between the
two snapshots). Including them would risk silently reverting newer upstream
work to an older state. They are intentionally left out of this package.

## Verification already done

- The full `quant_data-main` tree (upstream-extracted + this package's
  content merged in) was tested with `pytest` on this machine: **120/120
  tests pass** across every `test_real_data_study_*.py`, `test_bates_crc_*.py`,
  and `test_flex_crc_extension.py` file listed above.
