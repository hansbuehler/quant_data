"""Level 2 (local Ito drift residual) test for the DLV/regrid simulator.

Per ``TASK_SPEC.tex`` Section 3:

  For every tested contract, evaluate
    r_{T,K}(t,z) = d_tF + DF*mu^Q + (1/2) D^2F : Sigma Sigma^T.
  Report the residual by maturity, strike and state, both in absolute price
  units and normalized by a meaningful local scale (option price, vega, or
  spot). Localize any failure: wings vs ATM, short vs long maturity, interior
  vs boundary states.

IMPORTANT METHODOLOGICAL FINDING (read before interpreting the numbers below)
-------------------------------------------------------------------------
mu = ``fixed_contract_lvsq_drift(...).raw_drift`` and Sigma = ``...raw_diffusion``
are *finite-step* (one calendar week) transition parameters -- the function is
literally named for the "fixed [calendar] horizon" construction, calibrated so
that ``raw_states + dt*mu + sqrt(dt)*Sigma@dW`` reproduces the *exact discrete
density-tower martingale over one full week* (Level 0/1 verified this to
machine precision). They were never engineered as instantaneous (dt -> 0) SDE
coefficients valid at arbitrarily fine time resolution.

Level 2 as specified assumes exactly that continuous-time limit exists.
Plugging the finite-week mu, Sigma into the literal Ito formula below produces
a large residual that is dominated by theta (d_tF) -- confirmed via an
independent finite-difference cross-check, and economically sane (price rises
smoothly with tenor) -- while the drift and Ito/gamma terms are ~1e3-1e4x
smaller and closely cancel each other. This is best read as a **time-scale
mismatch** (testing an infinitesimal-dt claim against finite-week-calibrated
coefficients), not a Level-0/1-style structural arbitrage finding. See the
"diagnostics" section of the report for the evidence (three-term decomposition
+ finite-difference cross-check), and Level 4 (finite-step conditional drift,
Delta-refinement) for the test that is actually native to this simulator's
discrete time scale.

Per the user's explicit choice, this script reports the literal Level-2 result
as specified, together with the full diagnostic evidence above, rather than
silently reframing the test.

Usage::

    QUANTDATA_TEST_MODE=1 PYTHONPATH=. python -m dlv_no_arbitrage_tests.level2_ito_drift_residual
"""

from __future__ import annotations

import json

import numpy as np
import torch

from quantdata.dysanos.flex.lvsq_drift import fixed_contract_lvsq_drift
from quantdata.dysanos.flex.model import bound_native_raw

from dlv_no_arbitrage_tests.common import abs_quantiles, build_synthetic_population, quantiles

NUM_STATES = 48
STRIKE_LOG_MONEYNESS = (-0.30, -0.20, -0.10, 0.0, 0.10, 0.20, 0.30)
TENOR_LABELS = {"short": None, "mid": None, "long": None}  # filled from expiry count
PRICE_FLOOR_FOR_RELATIVE_RESIDUAL = 1.0e-4


def moneyness_bucket(log_k: float) -> str:
    if abs(log_k) < 0.05:
        return "ATM"
    if abs(log_k) < 0.20:
        return "near_wing"
    return "far_wing"


def price_fixed_cash_options(decoder, geometry, z: torch.Tensor, tau: torch.Tensor, strikes: torch.Tensor):
    """Differentiable pricing map C(raw_state, tau=T-t, K) -> price, batched."""
    parameters = bound_native_raw(z, geometry=geometry)
    surface = decoder.forward_batch(
        dlvsqs=parameters.dlvsqs, forward_vols=parameters.forward_vols, eta=parameters.eta
    )
    return decoder.price_calls_batch(surface, expiries_y=tau, strikes=strikes)


def ito_terms_for_contract(
    decoder, geometry, raw_states, mu, diffusion, *, tau_value: float, k_value: float
):
    """Return (price, theta, drift_term, ito_term) each shape (B,) for one (T,K)."""
    B = raw_states.shape[0]
    num_factors = diffusion.shape[-1]
    z = raw_states.detach().clone().requires_grad_(True)
    tau = torch.full((B, 1), tau_value, dtype=raw_states.dtype, requires_grad=True)
    strikes = torch.full((B, 1), k_value, dtype=raw_states.dtype)

    price = price_fixed_cash_options(decoder, geometry, z, tau, strikes)[:, 0]
    dF_dz, dF_dtau = torch.autograd.grad(
        price.sum(), [z, tau], create_graph=True, retain_graph=True
    )
    theta = -dF_dtau.squeeze(-1)
    drift_term = (dF_dz * mu).sum(dim=-1)
    ito_term = torch.zeros(B, dtype=raw_states.dtype)
    for f in range(num_factors):
        v = diffusion[:, :, f]
        directional_grad = (dF_dz * v).sum(dim=-1)
        hvp_z, = torch.autograd.grad(directional_grad.sum(), z, retain_graph=True)
        ito_term = ito_term + (hvp_z * v).sum(dim=-1)
    ito_term = 0.5 * ito_term
    return price.detach(), theta.detach(), drift_term.detach(), ito_term.detach()


def finite_difference_theta(decoder, geometry, raw_states, *, tau_value: float, k_value: float, eps: float = 1.0e-6):
    """Independent (non-autodiff) cross-check of theta via central differences."""
    B = raw_states.shape[0]
    z = raw_states.detach()
    strikes = torch.full((B, 1), k_value, dtype=raw_states.dtype)
    tau_up = torch.full((B, 1), tau_value + eps, dtype=raw_states.dtype)
    tau_dn = torch.full((B, 1), tau_value - eps, dtype=raw_states.dtype)
    price_up = price_fixed_cash_options(decoder, geometry, z, tau_up, strikes)[:, 0]
    price_dn = price_fixed_cash_options(decoder, geometry, z, tau_dn, strikes)[:, 0]
    return -(price_up - price_dn) / (2 * eps)


def run(*, report_path: str | None = None) -> dict[str, object]:
    population = build_synthetic_population(num_states=NUM_STATES)
    geometry = population.geometry
    decoder = population.decoder
    raw_states = population.raw_states

    drift = fixed_contract_lvsq_drift(decoder, raw_states.detach(), raw_log_loadings=population.loadings)
    mu = drift.raw_drift.detach()
    diffusion = drift.raw_diffusion.detach()

    num_expiries = population.num_model_expiries
    tenor_indices = {
        "short": 1,
        "mid": num_expiries // 2,
        "long": num_expiries - 2,
    }

    # Interior vs boundary classification, reusing the DLVsq bound-margin idea
    # from Level 0/1.
    dlvsq_margin = torch.minimum(
        population.parameters.dlvsqs - geometry.min_dlvsq,
        geometry.max_dlvsq - population.parameters.dlvsqs,
    ).amin(dim=(-1, -2))  # (B,) worst-case margin per state
    boundary_cutoff = torch.quantile(dlvsq_margin, 0.15)
    is_boundary_state = dlvsq_margin <= boundary_cutoff

    rows: list[dict[str, object]] = []
    for tenor_label, tenor_idx in tenor_indices.items():
        node = float(decoder.model_expiries_y[tenor_idx].detach())
        prev_node = float(decoder.model_expiries_y[tenor_idx - 1].detach())
        tau_value = prev_node + 0.5 * (node - prev_node)  # interior test point,
        # strictly inside the interpolation interval (avoids the boundary
        # clamp's zero-gradient artifact exactly at a model node).
        for log_k in STRIKE_LOG_MONEYNESS:
            k_value = float(np.exp(log_k))
            price, theta, drift_term, ito_term = ito_terms_for_contract(
                decoder, geometry, raw_states, mu, diffusion,
                tau_value=tau_value, k_value=k_value,
            )
            residual = theta + drift_term + ito_term
            relative_residual = residual.abs() / price.clamp_min(PRICE_FLOOR_FOR_RELATIVE_RESIDUAL)
            for b in range(NUM_STATES):
                rows.append(
                    {
                        "tenor_label": tenor_label,
                        "tenor_idx": tenor_idx,
                        "tau": tau_value,
                        "log_moneyness": log_k,
                        "moneyness_bucket": moneyness_bucket(log_k),
                        "state_boundary": bool(is_boundary_state[b]),
                        "price": float(price[b]),
                        "theta": float(theta[b]),
                        "drift_term": float(drift_term[b]),
                        "ito_term": float(ito_term[b]),
                        "residual_abs_price_units": float(residual[b].abs()),
                        "residual_relative_to_price": float(relative_residual[b]),
                    }
                )

    residual_abs = torch.tensor([r["residual_abs_price_units"] for r in rows])
    residual_rel = torch.tensor([r["residual_relative_to_price"] for r in rows])

    def subset_quantiles(name: str, predicate) -> dict[str, object]:
        idx = [i for i, r in enumerate(rows) if predicate(r)]
        sub_abs = residual_abs[idx]
        sub_rel = residual_rel[idx]
        return {
            "n_contract_state_pairs": len(idx),
            "absolute_price_units": quantiles(f"{name}_abs", sub_abs),
            "relative_to_price": quantiles(f"{name}_rel", sub_rel),
        }

    report: dict[str, object] = {
        "config": {
            "num_states": NUM_STATES,
            "num_inner_strikes": population.num_inner_strikes,
            "num_model_expiries": population.num_model_expiries,
            "num_factors": diffusion.shape[-1],
            "strikes_log_moneyness": list(STRIKE_LOG_MONEYNESS),
            "tenor_indices": tenor_indices,
            "num_contracts_per_state": len(TENOR_LABELS if False else tenor_indices) * len(STRIKE_LOG_MONEYNESS),
            "boundary_state_cutoff_dlvsq_margin_p15": float(boundary_cutoff),
            "num_boundary_states": int(is_boundary_state.sum()),
            "note": "Synthetic initial states; see dlv_no_arbitrage_tests/common.py.",
        },
        "methodology_note": (
            "mu/Sigma are finite-week (calendar_time_increment_y) transition "
            "parameters from fixed_contract_lvsq_drift, calibrated to match "
            "the exact one-week discrete density-tower martingale (see Level "
            "0/1). The literal continuous-time Ito residual below is "
            "dominated by theta and does NOT indicate a Level-0/1-style "
            "structural arbitrage -- see 'diagnostics' for the evidence. "
            "See also Level 4 (finite-step conditional drift) for the test "
            "native to this simulator's actual (discrete, weekly) time scale."
        ),
        "overall": {
            "absolute_price_units": quantiles("residual_abs", residual_abs),
            "relative_to_price": quantiles("residual_rel", residual_rel),
        },
        "by_tenor": {
            label: subset_quantiles(f"tenor_{label}", lambda r, label=label: r["tenor_label"] == label)
            for label in tenor_indices
        },
        "by_moneyness": {
            bucket: subset_quantiles(
                f"moneyness_{bucket}", lambda r, bucket=bucket: r["moneyness_bucket"] == bucket
            )
            for bucket in ("ATM", "near_wing", "far_wing")
        },
        "by_state_region": {
            "interior": subset_quantiles("interior", lambda r: not r["state_boundary"]),
            "boundary": subset_quantiles("boundary", lambda r: r["state_boundary"]),
        },
    }

    # -------------------------------------------------------------
    # Diagnostics: three-term decomposition + finite-difference cross-check,
    # on a small subsample (mid tenor, ATM + one wing strike, first 8 states).
    # -------------------------------------------------------------
    diag_tenor_idx = tenor_indices["mid"]
    node = float(decoder.model_expiries_y[diag_tenor_idx].detach())
    prev_node = float(decoder.model_expiries_y[diag_tenor_idx - 1].detach())
    diag_tau = prev_node + 0.5 * (node - prev_node)

    diag_rows = [r for r in rows if r["tenor_label"] == "mid" and r["log_moneyness"] in (0.0, 0.3)]
    theta_autodiff = torch.tensor([r["theta"] for r in diag_rows[:8]])
    fd_theta = finite_difference_theta(
        decoder, geometry, raw_states[:8], tau_value=diag_tau, k_value=1.0
    )
    report["diagnostics"] = {
        "explanation": (
            "theta (autodiff) vs theta (independent finite-difference, "
            "eps=1e-6, central) at the mid tenor/ATM strike, first 8 states "
            "-- confirms theta is a real, correctly-computed quantity, not "
            "an autodiff artifact."
        ),
        "theta_autodiff_first8_states_mid_tenor_ATM": [float(x) for x in theta_autodiff[: len(fd_theta)]],
        "theta_finite_difference_first8_states_mid_tenor_ATM": [float(x) for x in fd_theta],
        "term_magnitude_comparison_mid_tenor": {
            "median_abs_theta": float(
                torch.tensor([abs(r["theta"]) for r in rows if r["tenor_label"] == "mid"]).median()
            ),
            "median_abs_drift_term": float(
                torch.tensor([abs(r["drift_term"]) for r in rows if r["tenor_label"] == "mid"]).median()
            ),
            "median_abs_ito_term": float(
                torch.tensor([abs(r["ito_term"]) for r in rows if r["tenor_label"] == "mid"]).median()
            ),
            "note": (
                "drift_term and ito_term are consistently ~1e3-1e4x smaller "
                "than theta and closely cancel each other (drift_term "
                "approx -ito_term); theta alone accounts for nearly all of "
                "the residual."
            ),
        },
    }

    if report_path:
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2, default=str)

    return report


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, default=str))
