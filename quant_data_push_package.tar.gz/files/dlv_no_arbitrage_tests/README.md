# DLV no-arbitrage test hierarchy

Implements the testing hierarchy from `TASK_SPEC.tex` ("Testing Dynamic
No-Arbitrage in a DLV Option-Market Simulator") against the DLV/regrid
simulator in `quantdata/dysanos/flex`.

## Status

| Level | Description | Status |
|---|---|---|
| 0 | Static admissibility | Done — `level0_level1_admissibility.py` |
| 1 | Structural dynamic compatibility (Magnus/Wiese drift equations) | Done — `level0_level1_admissibility.py` |
| 2 | Local Itô drift residual | Done — `level2_ito_drift_residual.py` (see its docstring: a real methodological finding, not a bug — the literal residual is large because μ/Σ are finite-week transition parameters, not an infinitesimal-dt SDE limit) |
| 3 | Exact finite-step identities | Partially done — collected at every roll inside `heston_control_experiment.py` (branch-probability-sum, branch-tower, conditional mass/mean, regrid cash-price, put-call parity); not yet a standalone script against the synthetic population like Levels 0-2 |
| 4 | Finite-step conditional drift (Δ-refinement) | Not yet started |
| 5 | Monte-Carlo zero-drift inference | Not yet started |
| 6 | Out-of-sample OCE/mean-variance test | Not yet started |
| 7 | Out-of-sample dynamic Bellman trader | Not yet started |

## Why the tested states are synthetic

No trained decoder checkpoint or certified historical-state report exists in
this repo copy — `paper/DLV_REGRID_MARTINGALE_SUMMARY.md`'s "Reproducibility
pointers" section documents that these large artifacts are intentionally kept
outside Git. `common.py`'s `build_synthetic_population()` instead builds a
population of initial states directly through the real production classes
(`FlexSanosDecoder`, `bound_native_raw`, `fixed_contract_lvsq_drift`,
`density_martingale_lvsq_step`, ...), so every level here exercises the real
DLV/regrid numerics — just not calibrated to real market history. If the real
checkpoint + static report become available, swap `build_synthetic_population`
for `quantdata.dysanos.flex.static_q_inputs.load_static_q_inputs` and the rest
of each level script is unaffected.

## Running

Requires the full `pyproject.toml` dependency stack (notably `torch` and
`cdxcore`) on Python >=3.12 — these are not part of the lightweight notebook
venv (`../.venv`) elsewhere in this repo. From `quant_data-main/`:

```bash
QUANTDATA_TEST_MODE=1 PYTHONPATH=. python -m dlv_no_arbitrage_tests.level0_level1_admissibility
```

`QUANTDATA_TEST_MODE=1` points the `quantdata` package's data-location
machinery at the small fixtures already committed under `tests/stored_data/`
rather than requiring external `QUANTDATA_*` environment variables.

## Design notes

- Every residual is either a genuine public dataclass field already computed
  by the production code, or reconstructed algebraically from public
  fields/functions using the exact same formulas as the source — the scripts
  never reimplement new numerics, only defer the final `.max()` reduction so
  the full per-node/per-expiry/per-state residual population can be reported
  as max/median/p99 rather than a single collapsed number. Reconstructions are
  cross-checked against the production code's own already-reduced scalar
  (`cross_check_*` entries).
- `common.py` centralizes the synthetic-state construction and the
  `quantiles`/`abs_quantiles` reporting helpers so later levels don't
  duplicate this setup.

## Heston control experiment (`heston.py` + `heston_control_experiment.py`)

A separate control experiment isolating DLV/regrid implementation/
discretization issues from model-misspecification or real-data noise:

1. `heston.py` — a closed-form (non-Monte-Carlo) Heston pricer. No
   Heston-specific pricer existed in this repo; this reuses the existing
   generic Carr-Madan-style Fourier pricer in
   `quantdata.dysanos.tangent_levy.pricing.fourier_call_prices` and supplies
   Heston's closed-form characteristic function (Little Trap formulation).
   Validated against closed-form Black-Scholes in the ξ→0 degenerate limit.
2. `heston_control_experiment.py` — fits one DLV state to an exact Heston
   surface at t=0 (backbone stripped, X-only, since Heston is single-factor),
   evolves it forward via the real `fixed_grid_dlv.py`/`floating_grid_dlv.py`
   roll machinery across many Monte Carlo paths, and compares the evolved
   surface against the analytic Heston surface two ways (fixed-contract
   martingale test against the t=0 prices; re-anchored shape test at the
   DLV's own currently-implied variance). Also runs Levels 0-3 against the
   calibrated initial state and a time-step-refinement sweep. See its
   module docstring for the exact scope notes and caveats.
