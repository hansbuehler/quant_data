"""Static-Heston control experiment for the DLV/regrid simulator.

Isolates implementation/discretization bugs in the DLV/regrid machinery from
model-misspecification or real-data noise, by:

  1. Using a closed-form (non-Monte-Carlo) Heston pricer (``heston.py``) to
     generate an exact reference option-price surface at t=0, for one fixed,
     well-behaved, static (no term structure) Heston parameter set.
  2. Fitting an initial DLV state to that exact surface at t=0, via the real
     production classes (FlexSanosDecoder / bound_native_raw), backbone
     stripped (X-only) since Heston has a single volatility factor.
  3. Evolving the fitted state forward via the REAL regrid/dynamics code
     (fixed_grid_dlv.py for the first weekly roll, floating_grid_dlv.py for
     subsequent rolls) across many Monte Carlo paths -- no synthetic
     shortcuts.
  4. Comparing the evolved DLV-implied surface against the exact analytic
     Heston surface two ways: (a) a fixed-contract martingale test against
     the ORIGINAL t=0 Heston prices, and (b) a re-anchored shape test against
     a FRESH Heston surface at the DLV's own currently-implied variance.
  5. Running Levels 0-3 of TASK_SPEC.tex against the Heston-calibrated
     initial state, plus Level-3-style exact finite-step identities
     collected across every weekly roll.
  6. A time-step-refinement sweep (Level-4 style): repeating the FIRST
     weekly step at different sub-step counts (holding total elapsed time
     fixed) to see whether the deviation from Heston shrinks as step size
     shrinks (discretization bias) or stays flat (model misspecification /
     structural issue).

SCOPE NOTE: Levels 0-3 are run on the initial Heston-calibrated state only
(a fixed-grid state, directly compatible with fixed_contract_lvsq_drift's
raw-coordinate parameterization). They are not re-run on each evolved
floating-grid week: floating-grid surfaces are realized/regridded outcomes
with no underlying raw-coordinate parameterization, so extending Level 1/2
to later weeks would require re-fitting a raw state to each week's realized
surface -- a separate undertaking. Level-3-style tower/regrid identities ARE
collected at every roll (fixed and floating), since those residuals are
already produced by the roll machinery itself.

SCOPE NOTE 2: the far-expiry boundary uses the production code's own simple
tail extension in floating_surface_from_regrid (propagates the last
surviving DLVsq curve one more SANOS step), not the additional AR1
boundary-model refinement layer, which requires historical calibration data
not present in this repo copy. Comparisons below only use ORIGINAL,
genuinely-declared contracts that have not yet aged past this synthetic tail.

Usage::

    QUANTDATA_TEST_MODE=1 PYTHONPATH=. python -m dlv_no_arbitrage_tests.heston_control_experiment
"""

from __future__ import annotations

import dataclasses
import json
import sys
import time

import numpy as np
import torch

from quantdata.biz_calendar import DAYS_PER_YEAR
from quantdata.dysanos.flex.config import FixedRelativeStrikeCappedUnboundedDlvFlexGeometryConfig
from quantdata.dysanos.flex.fixed_grid_dlv import (
    build_fixed_grid_dlv_kernel,
    exact_fixed_grid_dlv_diagnostics,
    make_fixed_grid_dlv_randoms,
    sample_fixed_grid_dlv_paths,
    strip_fixed_grid_black_backbone,
)
from quantdata.dysanos.flex.floating_grid_dlv import (
    build_floating_grid_dlv_kernel,
    floating_surface_from_regrid,
    price_floating_surface_options,
    roll_floating_grid_dlv_kernel,
    smooth_floating_log_loadings,
)
from quantdata.dysanos.flex.lvsq_drift import (
    _decode_lvsq_branch_densities,
    density_martingale_lvsq_step,
    discrete_lvsq_grid_operator_product,
    fixed_contract_lvsq_drift,
    smooth_lvsq_log_loadings,
)
from quantdata.dysanos.flex.model import NativeParameters, bound_native_raw, raw_from_native_parameters
from quantdata.dysanos.flex.sanos import FlexSanosDecoder, make_inner_nms_nodes
from quantdata.torch import BaseEnvironment

from dlv_no_arbitrage_tests.common import abs_quantiles, quantiles
from dlv_no_arbitrage_tests.heston import HestonParameters, heston_call_prices, heston_surface

# ---------------------------------------------------------------------------
# Declared experiment configuration
# ---------------------------------------------------------------------------

NUM_INNER = 61
NUM_EXPIRIES = 8
NUM_PATHS = 20_000
NUM_WEEKS = 4  # 1 fixed-grid roll + 3 floating-grid rolls
CALIB_LOG_MONEYNESS = np.array([-0.3, -0.2, -0.1, -0.05, 0.0, 0.05, 0.1, 0.2, 0.3])
DLVSQ_ANNUALIZED_LOG_VOLATILITY = 0.10  # generic loading scale, matches Level 0/1/2's own default
SEED = 20260915

# Fixed, static (no term structure), well-behaved Heston parameters.
HESTON_PARAMS = HestonParameters(kappa=2.0, theta=0.04, xi=0.3, rho=-0.6, v0=0.04)
# Feller condition 2*kappa*theta >= xi^2: 2*2.0*0.04=0.16 >= 0.3^2=0.09 -> satisfied.


def build_geometry_and_decoder():
    env = BaseEnvironment(precision=64, device="cpu", debug=False)
    inner_nodes = make_inner_nms_nodes(num_inner_strikes=NUM_INNER, nms_range=(-3.0, 2.0))
    inner_relative_strikes = tuple(np.exp(0.35 * inner_nodes).tolist())
    geometry = FixedRelativeStrikeCappedUnboundedDlvFlexGeometryConfig(
        num_inner_strikes=NUM_INNER,
        num_model_expiries=NUM_EXPIRIES,
        inner_relative_strikes=inner_relative_strikes,
    )
    decoder = FlexSanosDecoder(env, geometry=geometry)
    return env, geometry, decoder


def strip_backbone(surface):
    return dataclasses.replace(surface, backbone_total_vols=torch.zeros_like(surface.backbone_total_vols))


def calibrate_initial_state(env, geometry, decoder, *, num_epochs=3000, lr=0.03):
    """Fit ONE DLV state (X-only, backbone stripped) to the exact t=0 Heston surface."""

    model_expiries_y = decoder.model_expiries_y.detach().numpy()
    target_surface_np = heston_surface(CALIB_LOG_MONEYNESS, model_expiries_y, HESTON_PARAMS)  # (T, K)
    K = len(CALIB_LOG_MONEYNESS)
    target_prices_flat = torch.as_tensor(target_surface_np, dtype=env.fdtype).reshape(1, -1)
    target_taus = torch.as_tensor(model_expiries_y, dtype=env.fdtype).reshape(1, -1, 1).expand(
        1, NUM_EXPIRIES, K
    ).reshape(1, -1)
    target_strikes = torch.as_tensor(np.exp(CALIB_LOG_MONEYNESS), dtype=env.fdtype).reshape(1, 1, -1).expand(
        1, NUM_EXPIRIES, K
    ).reshape(1, -1)

    dlvsq_raw = torch.full(
        (1, NUM_EXPIRIES, NUM_INNER), np.log(HESTON_PARAMS.v0 - geometry.min_dlvsq), dtype=env.fdtype
    ).clone().requires_grad_(True)
    forward_vol_fixed = torch.full((1, NUM_EXPIRIES), 0.2, dtype=env.fdtype)
    eta_fixed = torch.full((1, NUM_EXPIRIES), 0.3, dtype=env.fdtype)
    max_log_dlvsq = torch.as_tensor(geometry.maximum_log_dlvsq, dtype=env.fdtype)

    def price_from_dlvsq_raw(z):
        clamped = torch.minimum(z, max_log_dlvsq)
        dlvsqs = geometry.min_dlvsq + torch.exp(clamped)
        surface = decoder.forward_batch(dlvsqs=dlvsqs, forward_vols=forward_vol_fixed, eta=eta_fixed)
        surface = strip_backbone(surface)
        return decoder.price_calls_batch(surface, expiries_y=target_taus, strikes=target_strikes), dlvsqs

    optimizer = torch.optim.Adam([dlvsq_raw], lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs, eta_min=1e-5)
    for _ in range(num_epochs):
        optimizer.zero_grad()
        prices, _ = price_from_dlvsq_raw(dlvsq_raw)
        loss = torch.mean((prices - target_prices_flat) ** 2)
        loss.backward()
        optimizer.step()
        scheduler.step()

    with torch.no_grad():
        final_prices, final_dlvsqs = price_from_dlvsq_raw(dlvsq_raw)
    calibration_error = (final_prices - target_prices_flat).detach()

    parameters0 = NativeParameters(dlvsqs=final_dlvsqs.detach(), forward_vols=forward_vol_fixed, eta=eta_fixed)
    raw_states = raw_from_native_parameters(parameters0, geometry=geometry)

    return {
        "raw_states": raw_states,
        "target_surface": target_surface_np,
        "calib_log_moneyness": CALIB_LOG_MONEYNESS,
        "calib_taus": model_expiries_y,
        "calibration_price_error_abs": abs_quantiles("calibration_price_error", calibration_error),
        "calibration_target_price_range": [float(target_prices_flat.min()), float(target_prices_flat.max())],
    }


def evolve_paths(env, geometry, decoder, raw_states, *, num_paths, num_weeks, calendar_dt, seed):
    """Evolve the calibrated state forward via the REAL regrid/roll machinery.

    Returns per-week (surface, current_spot) plus Level-3-style tower/regrid
    residuals collected at every roll.
    """

    torch_gen = torch.Generator().manual_seed(seed)
    fixed_loadings = smooth_lvsq_log_loadings(
        decoder.forward_batch(
            dlvsqs=bound_native_raw(raw_states, geometry=geometry).dlvsqs,
            forward_vols=bound_native_raw(raw_states, geometry=geometry).forward_vols,
            eta=bound_native_raw(raw_states, geometry=geometry).eta,
        ).support_strikes[0, 0],
        num_model_expiries=NUM_EXPIRIES,
        annualized_log_volatility=DLVSQ_ANNUALIZED_LOG_VOLATILITY,
    )
    fixed_kernel = build_fixed_grid_dlv_kernel(
        decoder, raw_states, raw_log_loadings=fixed_loadings, calendar_time_increment_y=calendar_dt
    )
    fixed_kernel = strip_fixed_grid_black_backbone(fixed_kernel)

    exact_diag = exact_fixed_grid_dlv_diagnostics(
        fixed_kernel, fixed_cash_strikes=torch.as_tensor(np.exp(CALIB_LOG_MONEYNESS), dtype=env.fdtype)
    )
    level3_records = [
        {
            "week": 1,
            "kind": "fixed_grid_exact_diagnostics",
            "maximum_density_tower_residual": float(exact_diag.maximum_density_tower_residual),
            "maximum_option_tower_residual": float(exact_diag.maximum_option_tower_residual),
            "maximum_spot_mean_residual": float(exact_diag.maximum_spot_mean_residual),
            "branch_probabilities_sum_to_one_residual": float(
                torch.abs(fixed_kernel.finite_step.branch_probabilities.sum() - 1.0)
                if hasattr(fixed_kernel.finite_step, "branch_probabilities")
                else 0.0
            ),
        }
    ]

    randoms = make_fixed_grid_dlv_randoms(
        batch_size=1, num_paths=num_paths, dtype=env.fdtype, device=env.device,
        generator=torch_gen, antithetic=True,
    )
    strikes = torch.as_tensor(np.exp(CALIB_LOG_MONEYNESS), dtype=env.fdtype)
    sampled = sample_fixed_grid_dlv_paths(decoder, fixed_kernel, fixed_cash_strikes=strikes, randoms=randoms)
    level3_records.append(
        {
            "week": 1,
            "kind": "regrid_conditional_residuals",
            "maximum_conditional_mass_residual": float(sampled.maximum_conditional_mass_residual),
            "maximum_conditional_mean_residual": float(sampled.maximum_conditional_mean_residual),
            "maximum_cash_price_residual (regrid vs direct)": float(
                sampled.regridded_state.maximum_cash_price_residual
            ),
        }
    )

    surface = floating_surface_from_regrid(decoder, sampled.regridded_state)
    current_spot = sampled.normalized_spot.reshape(-1)
    weekly_states = [{"week": 1, "surface": surface, "current_spot": current_spot}]

    for week in range(2, num_weeks + 1):
        loadings = smooth_floating_log_loadings(
            surface.support_strikes[:, 0],
            num_model_expiries=NUM_EXPIRIES,
            annualized_log_volatility=DLVSQ_ANNUALIZED_LOG_VOLATILITY,
        )
        kernel = build_floating_grid_dlv_kernel(
            decoder, surface, raw_log_loadings=loadings, calendar_time_increment_y=calendar_dt
        )
        level3_records.append(
            {
                "week": week,
                "kind": "floating_kernel_diagnostics",
                "maximum_density_mean_residual (branch tower)": float(kernel.maximum_density_mean_residual),
                "maximum_decoder_density_residual": float(kernel.maximum_decoder_density_residual),
                "maximum_mass_residual": float(kernel.maximum_mass_residual),
                "maximum_mean_residual": float(kernel.maximum_mean_residual),
                "branch_probabilities_sum_to_one_residual": float(
                    torch.abs(kernel.branch_probabilities.sum() - 1.0)
                ),
            }
        )
        u1 = torch.rand(num_paths, dtype=env.fdtype, generator=torch_gen)
        u2 = torch.rand(num_paths, dtype=env.fdtype, generator=torch_gen)
        z1 = torch.randn(num_paths, dtype=env.fdtype, generator=torch_gen)
        rolled = roll_floating_grid_dlv_kernel(
            decoder, kernel, surface_branch_uniforms=u1, front_node_uniforms=u2, front_backbone_normals=z1
        )
        level3_records.append(
            {
                "week": week,
                "kind": "roll_conditional_residuals",
                "maximum_conditional_mass_residual": float(rolled.maximum_conditional_mass_residual),
                "maximum_conditional_mean_residual": float(rolled.maximum_conditional_mean_residual),
            }
        )
        current_spot = current_spot * rolled.gross_spot_return
        surface = rolled.surface
        weekly_states.append({"week": week, "surface": surface, "current_spot": current_spot})

    # Put-call parity cross-check (all weeks' final surface): directly-priced
    # put vs calls-spot+K, independent of the tower/regrid checks above.
    final_surface, final_spot = weekly_states[-1]["surface"], weekly_states[-1]["current_spot"]
    calls = price_floating_surface_options(
        final_surface, current_spot=final_spot, fixed_cash_strikes=strikes,
        is_call=torch.ones(len(strikes), dtype=torch.bool),
    )
    puts_direct = price_floating_surface_options(
        final_surface, current_spot=final_spot, fixed_cash_strikes=strikes,
        is_call=torch.zeros(len(strikes), dtype=torch.bool),
    )
    puts_via_parity = calls - final_spot[:, None, None] + strikes.reshape(1, 1, -1)
    parity_residual = (puts_direct - puts_via_parity).abs()
    level3_records.append(
        {
            "week": num_weeks,
            "kind": "put_call_parity_cross_check",
            "residual": abs_quantiles("put_call_parity", parity_residual),
        }
    )

    return weekly_states, level3_records


def fixed_contract_martingale_test(weekly_states, target_surface_np, calendar_dt):
    """Compare E[DLV price] for ORIGINAL (T,K) contracts against t=0 Heston."""

    strikes_np = np.exp(CALIB_LOG_MONEYNESS)
    strikes = torch.as_tensor(strikes_np, dtype=torch.float64)
    results = []
    for record in weekly_states:
        week = record["week"]
        surface, spot = record["surface"], record["current_spot"]
        # Force calls (matching the Heston reference, always call_prices):
        # price_floating_surface_options' default is_call rule is K<=1.0
        # (original spot), not K<=current spot, so it would silently price
        # puts for K>1 without this.
        prices = price_floating_surface_options(
            surface, current_spot=spot, fixed_cash_strikes=strikes,
            is_call=torch.ones(len(strikes), dtype=torch.bool),
        )
        mean_prices = prices.mean(dim=0)  # (expiries, strikes)
        se_prices = prices.std(dim=0, unbiased=True) / (len(spot) ** 0.5)
        # original expiry index j is at relative index j-week+1 (see docstring
        # bookkeeping); only original indices >= week survive without having
        # touched the synthetic tail extension.
        for original_j in range(week, NUM_EXPIRIES):
            relative_j = original_j - week + 1
            # week=1 uses fixed_grid_dlv's own week-1 output, which is already
            # "post one roll" (relative index 0 = original index 1); adjust:
            # for week==1, relative index i corresponds to original index i+1.
            pass
        # Recompute cleanly: for week w (1-indexed), relative index i (0..T-1)
        # corresponds to original index (i + w).
        for i in range(NUM_EXPIRIES):
            original_j = i + week
            if original_j >= NUM_EXPIRIES:
                continue  # this relative slot is (partly) synthetic tail
            for k_idx, k_val in enumerate(strikes_np):
                dlv_mean = float(mean_prices[i, k_idx])
                dlv_se = float(se_prices[i, k_idx])
                heston_t0 = float(target_surface_np[original_j, k_idx])
                deviation = dlv_mean - heston_t0
                results.append(
                    {
                        "week": week,
                        "original_expiry_idx": original_j,
                        "log_moneyness": float(CALIB_LOG_MONEYNESS[k_idx]),
                        "heston_t0_price": heston_t0,
                        "dlv_mean_price": dlv_mean,
                        "dlv_price_std_error": dlv_se,
                        "deviation_abs": abs(deviation),
                        "deviation_in_std_errors": abs(deviation) / max(dlv_se, 1e-12),
                        "deviation_relative_to_price": abs(deviation) / max(heston_t0, 1e-4),
                    }
                )
    return results


def implied_atm_variance(surface, relative_expiry_idx=0):
    """Extract a simple 'current instantaneous variance' proxy: the ATM
    (nearest-to-forward) DLVsq at the front surviving expiry, per path."""
    support = surface.support_strikes[:, relative_expiry_idx]  # (paths, N+2)
    dlvsq = surface.dlvsqs[:, relative_expiry_idx]  # (paths, N)
    inner_support = support[:, 1:-1]
    atm_idx = torch.argmin(torch.abs(inner_support - 1.0), dim=-1)
    return torch.gather(dlvsq, 1, atm_idx[:, None]).squeeze(-1)


def reanchored_shape_test(weekly_states, decoder):
    """At each week, re-anchor a fresh analytic Heston surface at the DLV's
    own currently-implied ATM variance, and compare SHAPE (skew/smile) against
    the evolved DLV surface's own prices at the same relative maturities."""

    strikes_np = np.exp(CALIB_LOG_MONEYNESS)
    strikes = torch.as_tensor(strikes_np, dtype=torch.float64)
    model_expiries_y = decoder.model_expiries_y.detach().numpy()
    results = []
    for record in weekly_states:
        week = record["week"]
        surface, spot = record["surface"], record["current_spot"]
        v_current = implied_atm_variance(surface).clamp_min(1e-6)
        v_mean = float(v_current.mean())
        v_median = float(v_current.median())
        reanchored_params = HESTON_PARAMS.with_v0(v_median)
        num_real = NUM_EXPIRIES - week  # relative indices 0..num_real-1 are real
        prices = price_floating_surface_options(
            surface, current_spot=spot, fixed_cash_strikes=strikes,
            is_call=torch.ones(len(strikes), dtype=torch.bool),
        )
        mean_prices = prices.mean(dim=0)
        for i in range(max(num_real, 0)):
            tau = float(model_expiries_y[i])
            reanchored_row = heston_call_prices(CALIB_LOG_MONEYNESS, reanchored_params, tau=tau)
            for k_idx, k_val in enumerate(strikes_np):
                dlv_price = float(mean_prices[i, k_idx])
                heston_reanchored = float(reanchored_row[k_idx])
                results.append(
                    {
                        "week": week,
                        "relative_expiry_idx": i,
                        "tau": tau,
                        "log_moneyness": float(CALIB_LOG_MONEYNESS[k_idx]),
                        "implied_atm_variance_median": v_median,
                        "implied_atm_variance_mean": v_mean,
                        "dlv_price": dlv_price,
                        "heston_reanchored_price": heston_reanchored,
                        "deviation_abs": abs(dlv_price - heston_reanchored),
                        "deviation_relative_to_price": abs(dlv_price - heston_reanchored) / max(heston_reanchored, 1e-4),
                    }
                )
    return results


def summarize_martingale_results(records):
    dev_abs = torch.tensor([r["deviation_abs"] for r in records])
    dev_rel = torch.tensor([r["deviation_relative_to_price"] for r in records])
    dev_se = torch.tensor([r["deviation_in_std_errors"] for r in records])
    by_week = {}
    for week in sorted({r["week"] for r in records}):
        idx = [i for i, r in enumerate(records) if r["week"] == week]
        by_week[str(week)] = {
            "n": len(idx),
            "abs_price_units": quantiles(f"week{week}_abs", dev_abs[idx]),
            "relative_to_price": quantiles(f"week{week}_rel", dev_rel[idx]),
            "in_std_errors": quantiles(f"week{week}_se", dev_se[idx]),
        }
    return {
        "overall_abs_price_units": quantiles("mart_abs", dev_abs),
        "overall_relative_to_price": quantiles("mart_rel", dev_rel),
        "overall_in_std_errors": quantiles("mart_se", dev_se),
        "by_week": by_week,
    }


def summarize_shape_results(records):
    dev_abs = torch.tensor([r["deviation_abs"] for r in records])
    dev_rel = torch.tensor([r["deviation_relative_to_price"] for r in records])
    by_week = {}
    for week in sorted({r["week"] for r in records}):
        idx = [i for i, r in enumerate(records) if r["week"] == week]
        by_week[str(week)] = {
            "n": len(idx),
            "abs_price_units": quantiles(f"week{week}_abs", dev_abs[idx]),
            "relative_to_price": quantiles(f"week{week}_rel", dev_rel[idx]),
            "implied_atm_variance_median": records[idx[0]]["implied_atm_variance_median"] if idx else None,
        }
    return {
        "overall_abs_price_units": quantiles("shape_abs", dev_abs),
        "overall_relative_to_price": quantiles("shape_rel", dev_rel),
        "by_week": by_week,
    }


def run_levels_0_3_on_calibrated_state(env, geometry, decoder, raw_states, calendar_dt):
    """Levels 0-3 against the initial Heston-calibrated (fixed-grid) state."""

    parameters = bound_native_raw(raw_states, geometry=geometry)
    initial_surface = decoder.forward_batch(
        dlvsqs=parameters.dlvsqs, forward_vols=parameters.forward_vols, eta=parameters.eta
    )
    initial_surface_stripped = strip_backbone(initial_surface)

    loadings = smooth_lvsq_log_loadings(
        initial_surface.support_strikes[0, 0],
        num_model_expiries=NUM_EXPIRIES,
        annualized_log_volatility=DLVSQ_ANNUALIZED_LOG_VOLATILITY,
    )

    level0 = {}
    density = initial_surface.densities
    support = initial_surface.support_strikes
    level0["positivity_violation"] = quantiles("positivity", torch.clamp_min(-density, 0.0))
    level0["unit_mass_residual"] = abs_quantiles("mass", density.sum(dim=-1) - 1.0)
    level0["first_moment_residual"] = abs_quantiles("moment", (density * support).sum(dim=-1) - 1.0)

    finite_step = density_martingale_lvsq_step(
        decoder, raw_states, raw_log_loadings=loadings, calendar_time_increment_y=calendar_dt
    )
    density_mean = torch.einsum(
        "r,rte->te", finite_step.branch_probabilities, finite_step.densities_by_branch[0]
    )
    level0["dlv_recursion_residual"] = abs_quantiles(
        "recursion", density_mean - initial_surface.densities[0]
    )
    decoded = _decode_lvsq_branch_densities(decoder, finite_step.raw_states_by_branch)
    level0["decoder_residual"] = abs_quantiles(
        "decoder", decoded - finite_step.densities_by_branch
    )
    dlvsq_margin_low = parameters.dlvsqs - geometry.min_dlvsq
    dlvsq_margin_high = geometry.max_dlvsq - parameters.dlvsqs
    level0["dlvsq_bound_margin_min"] = float(torch.minimum(dlvsq_margin_low, dlvsq_margin_high).min())

    drift = fixed_contract_lvsq_drift(decoder, raw_states, raw_log_loadings=loadings)
    drift_terms = []
    for expiry_index in range(1, NUM_EXPIRIES):
        density_interior = drift.densities[:, expiry_index, 1:-1]
        physical_drift = drift.dlvsq_drift[:, expiry_index]
        physical_diffusion = drift.dlvsq_diffusion[:, expiry_index]
        current_dd_interior = drift.density_diffusion[:, expiry_index, 1:-1, :]
        term = density_interior * physical_drift + torch.sum(
            current_dd_interior * physical_diffusion, dim=-1
        )
        drift_terms.append(term)
    drift_equation_residual = torch.stack(drift_terms, dim=1)
    level1 = {
        "drift_equation_residual": abs_quantiles("drift_eq", drift_equation_residual),
        "maximum_volatility_equation_residual (production scalar)": float(
            drift.maximum_volatility_equation_residual
        ),
        "maximum_drift_equation_residual (production scalar)": float(drift.maximum_drift_equation_residual),
    }

    # Level 2: literal Ito residual at the mid tenor / ATM strike (same
    # methodology and caveat as level2_ito_drift_residual.py).
    mu = drift.raw_drift.detach()
    diffusion = drift.raw_diffusion.detach()
    num_factors = diffusion.shape[-1]
    tenor_idx = NUM_EXPIRIES // 2
    node = float(decoder.model_expiries_y[tenor_idx])
    prev_node = float(decoder.model_expiries_y[tenor_idx - 1])
    tau_value = prev_node + 0.5 * (node - prev_node)

    def price_fn(z, tau, strikes_):
        p = bound_native_raw(z, geometry=geometry)
        s = decoder.forward_batch(dlvsqs=p.dlvsqs, forward_vols=p.forward_vols, eta=p.eta)
        return decoder.price_calls_batch(s, expiries_y=tau, strikes=strikes_)

    z = raw_states.detach().clone().requires_grad_(True)
    tau_t = torch.full((1, 1), tau_value, dtype=env.fdtype, requires_grad=True)
    strikes_t = torch.full((1, 1), 1.0, dtype=env.fdtype)  # ATM
    price = price_fn(z, tau_t, strikes_t)[:, 0]
    dF_dz, dF_dtau = torch.autograd.grad(price.sum(), [z, tau_t], create_graph=True, retain_graph=True)
    theta = -dF_dtau.squeeze(-1)
    drift_term = (dF_dz * mu).sum(dim=-1)
    ito_term = torch.zeros(1, dtype=env.fdtype)
    for f in range(num_factors):
        v = diffusion[:, :, f]
        dir_grad = (dF_dz * v).sum(dim=-1)
        hvp_z, = torch.autograd.grad(dir_grad.sum(), z, retain_graph=True)
        ito_term = ito_term + (hvp_z * v).sum(dim=-1)
    ito_term = 0.5 * ito_term
    level2 = {
        "price": float(price.detach()[0]),
        "theta": float(theta.detach()[0]),
        "drift_term": float(drift_term.detach()[0]),
        "ito_term": float(ito_term.detach()[0]),
        "residual_abs": float((theta + drift_term + ito_term).detach().abs()[0]),
        "note": "See level2_ito_drift_residual.py: large by design (time-scale mismatch, not structural arbitrage).",
    }

    exact_diag = exact_fixed_grid_dlv_diagnostics(
        strip_fixed_grid_black_backbone(
            build_fixed_grid_dlv_kernel(
                decoder, raw_states, raw_log_loadings=loadings, calendar_time_increment_y=calendar_dt
            )
        ),
        fixed_cash_strikes=torch.as_tensor(np.exp(CALIB_LOG_MONEYNESS), dtype=env.fdtype),
    )
    level3 = {
        "maximum_density_tower_residual": float(exact_diag.maximum_density_tower_residual),
        "maximum_option_tower_residual": float(exact_diag.maximum_option_tower_residual),
        "maximum_spot_mean_residual": float(exact_diag.maximum_spot_mean_residual),
    }

    return {"level0": level0, "level1": level1, "level2": level2, "level3": level3}


def time_step_sweep(env, geometry, decoder, raw_states, *, total_dt, sub_step_counts, num_paths, seed):
    """Level-4-style: refine the first weekly step into K sub-steps (holding
    total elapsed time fixed) using density_martingale_lvsq_step chained, and
    compare the resulting week-1 surface's prices against Heston at total_dt."""

    parameters = bound_native_raw(raw_states, geometry=geometry)
    initial_surface = decoder.forward_batch(
        dlvsqs=parameters.dlvsqs, forward_vols=parameters.forward_vols, eta=parameters.eta
    )
    loadings = smooth_lvsq_log_loadings(
        initial_surface.support_strikes[0, 0],
        num_model_expiries=NUM_EXPIRIES,
        annualized_log_volatility=DLVSQ_ANNUALIZED_LOG_VOLATILITY,
    )
    strikes_np = np.exp(CALIB_LOG_MONEYNESS)
    strikes = torch.as_tensor(strikes_np, dtype=env.fdtype)
    # Target: Heston price at t=total_dt for the option originally at model
    # expiry index 2 (tau_remaining = model_expiries_y[2] - total_dt =
    # model_expiries_y[1], since total_dt equals exactly one expiry spacing).
    # IMPORTANT: this must NOT land on expiry index 0 -- density_martingale_
    # lvsq_step freezes expiry-0's density/DLVsq entirely by construction
    # (its loading row is exactly zero), so a target that resolves to expiry
    # index 0 would be identical across every sub-step count by construction,
    # not because of any genuine convergence. Expiry index >= 1 is dynamic.
    target_original_idx = 2
    tau_remaining = float(decoder.model_expiries_y[target_original_idx]) - total_dt
    if tau_remaining <= float(decoder.model_expiries_y[0]) + 1e-9:
        raise ValueError(
            "time_step_sweep target resolves to the frozen expiry-0 slice; "
            "increase target_original_idx"
        )
    heston_target_row = heston_call_prices(CALIB_LOG_MONEYNESS, HESTON_PARAMS, tau=tau_remaining)

    results = []
    for k_substeps in sub_step_counts:
        sub_dt = total_dt / k_substeps
        raw_states_k = raw_states.detach().clone().expand(num_paths, -1).clone()
        gen = torch.Generator().manual_seed(seed + k_substeps)
        try:
            for _ in range(k_substeps):
                step = density_martingale_lvsq_step(
                    decoder, raw_states_k, raw_log_loadings=loadings, calendar_time_increment_y=sub_dt
                )
                num_branches = len(step.branch_probabilities)
                u = torch.rand(len(raw_states_k), dtype=env.fdtype, generator=gen)
                branch_idx = torch.sum(
                    u[:, None] > torch.cumsum(step.branch_probabilities, dim=0)[None, :-1], dim=-1
                )
                raw_states_k = step.raw_states_by_branch[torch.arange(len(raw_states_k)), branch_idx]
        except RuntimeError as exc:
            # density_martingale_lvsq_step raises if a recovered branch DLV
            # falls outside its open bounds. With many independent paths
            # chained across many sub-steps, the chance that SOME path/branch
            # combination hits this boundary rises -- this is a genuine
            # numerical-stability observation about naive plain-random-walk
            # sub-stepping (not the production code's own weekly-step usage,
            # which does not chain this many independent draws), reported
            # honestly rather than hidden or worked around by clamping.
            results.append(
                {
                    "sub_steps": k_substeps,
                    "sub_step_size_business_days": sub_dt * DAYS_PER_YEAR,
                    "error": f"boundary breach during sub-stepping: {exc}",
                }
            )
            continue
        # Strip backbone and price the (still fixed-grid) evolved states.
        final_params = bound_native_raw(raw_states_k, geometry=geometry)
        final_surface = decoder.forward_batch(
            dlvsqs=final_params.dlvsqs, forward_vols=final_params.forward_vols, eta=final_params.eta
        )
        final_surface = strip_backbone(final_surface)
        tau_query = torch.full(
            (len(raw_states_k), len(strikes)), tau_remaining, dtype=env.fdtype
        )
        strikes_query = strikes[None, :].expand(len(raw_states_k), -1)
        prices = decoder.price_calls_batch(final_surface, expiries_y=tau_query, strikes=strikes_query)
        mean_prices = prices.mean(dim=0).detach().numpy()
        deviation = np.abs(mean_prices - heston_target_row)
        results.append(
            {
                "sub_steps": k_substeps,
                "sub_step_size_business_days": sub_dt * DAYS_PER_YEAR,
                "max_abs_deviation": float(deviation.max()),
                "mean_abs_deviation": float(deviation.mean()),
                "median_abs_deviation": float(np.median(deviation)),
            }
        )
    return results


def run(*, report_path: str | None = None) -> dict[str, object]:
    t0 = time.perf_counter()
    env, geometry, decoder = build_geometry_and_decoder()
    calendar_dt = 5.0 / DAYS_PER_YEAR

    calib = calibrate_initial_state(env, geometry, decoder)
    print(f"[{time.perf_counter()-t0:.1f}s] calibration done", file=sys.stderr)

    weekly_states, level3_roll_records = evolve_paths(
        env, geometry, decoder, calib["raw_states"],
        num_paths=NUM_PATHS, num_weeks=NUM_WEEKS, calendar_dt=calendar_dt, seed=SEED,
    )
    print(f"[{time.perf_counter()-t0:.1f}s] evolution done ({NUM_WEEKS} weeks, {NUM_PATHS} paths)", file=sys.stderr)

    martingale_records = fixed_contract_martingale_test(weekly_states, calib["target_surface"], calendar_dt)
    shape_records = reanchored_shape_test(weekly_states, decoder)
    print(f"[{time.perf_counter()-t0:.1f}s] comparisons done", file=sys.stderr)

    levels_report = run_levels_0_3_on_calibrated_state(env, geometry, decoder, calib["raw_states"], calendar_dt)
    print(f"[{time.perf_counter()-t0:.1f}s] levels 0-3 done", file=sys.stderr)

    sweep = time_step_sweep(
        env, geometry, decoder, calib["raw_states"],
        total_dt=calendar_dt, sub_step_counts=(1, 2, 4, 8), num_paths=4000, seed=SEED,
    )
    print(f"[{time.perf_counter()-t0:.1f}s] time-step sweep done", file=sys.stderr)

    report = {
        "config": {
            "heston_parameters": dataclasses.asdict(HESTON_PARAMS),
            "feller_ratio": HESTON_PARAMS.feller_ratio,
            "num_inner_strikes": NUM_INNER,
            "num_model_expiries": NUM_EXPIRIES,
            "num_paths": NUM_PATHS,
            "num_weeks": NUM_WEEKS,
            "calib_log_moneyness": CALIB_LOG_MONEYNESS.tolist(),
            "dlvsq_annualized_log_volatility": DLVSQ_ANNUALIZED_LOG_VOLATILITY,
            "seed": SEED,
        },
        "calibration": {
            "calibration_price_error_abs": calib["calibration_price_error_abs"],
            "calibration_target_price_range": calib["calibration_target_price_range"],
        },
        "fixed_contract_martingale_test": summarize_martingale_results(martingale_records),
        "reanchored_shape_test": summarize_shape_results(shape_records),
        "levels_0_3_on_calibrated_state": levels_report,
        "level3_roll_diagnostics": level3_roll_records,
        "time_step_sweep": sweep,
        "runtime_seconds": time.perf_counter() - t0,
    }

    if report_path:
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2, default=str)

    return report


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, default=str))
