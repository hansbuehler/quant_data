"""Closed-form (non-Monte-Carlo) Heston pricer, for a static-Heston control
experiment isolating DLV/regrid implementation/discretization issues from
model-misspecification or real-data noise.

No Heston-specific pricer exists elsewhere in this repo (checked: no hits for
"heston" anywhere under ``quantdata/``). The repo does have a generic
Carr-Madan-style Fourier pricer for an arbitrary characteristic function --
``quantdata.dysanos.tangent_levy.pricing.fourier_call_prices`` -- so this
module reuses that production integration machinery and supplies Heston's
closed-form characteristic function ("Little Trap" formulation, Albrecher et
al. 2007 / Gatheral), rather than reimplementing Fourier integration.

Convention matches ``fourier_call_prices``: spot normalized to 1, so a
correctly risk-neutral Heston requires r=q=0 for the quoted normalized calls
to be genuinely driftless (matching the DLV/regrid simulator's own
zero-rate/unit-forward convention throughout this test suite).

Validated (see git history / dev notes) against closed-form Black-Scholes in
the xi->0, v0=theta degenerate limit: matches to the underlying Fourier
pricer's own ~3e-6 quadrature precision.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from quantdata.dysanos.tangent_levy.pricing import CharacteristicFunction, fourier_call_prices


@dataclass(frozen=True)
class HestonParameters:
    """One static (no term structure) Heston parameter set."""

    kappa: float  # mean-reversion speed of variance
    theta: float  # long-run variance level
    xi: float  # volatility of variance ("vol of vol")
    rho: float  # correlation between spot and variance Brownian motions
    v0: float  # initial instantaneous variance
    r: float = 0.0  # risk-free rate (must be 0 to match this convention)
    q: float = 0.0  # dividend yield (must be 0 to match this convention)

    def __post_init__(self) -> None:
        if self.kappa <= 0.0 or self.theta <= 0.0 or self.xi <= 0.0 or self.v0 <= 0.0:
            raise ValueError("kappa, theta, xi, v0 must all be strictly positive")
        if not -1.0 < self.rho < 1.0:
            raise ValueError("rho must lie strictly in (-1, 1)")
        if self.r != 0.0 or self.q != 0.0:
            raise ValueError(
                "r and q must be exactly 0 to match fourier_call_prices' "
                "unit-forward normalization used throughout this test suite"
            )

    @property
    def feller_ratio(self) -> float:
        """2*kappa*theta / xi^2; >= 1 means the Feller condition holds."""
        return 2.0 * self.kappa * self.theta / (self.xi * self.xi)

    def with_v0(self, v0: float) -> "HestonParameters":
        """Return the same parameters re-anchored at a different variance level."""
        return HestonParameters(
            kappa=self.kappa, theta=self.theta, xi=self.xi, rho=self.rho,
            v0=v0, r=self.r, q=self.q,
        )


def heston_characteristic_function(params: HestonParameters, *, tau: float) -> CharacteristicFunction:
    """Heston characteristic function of log(S_tau/S_0), Little Trap formulation."""
    if tau < 0.0:
        raise ValueError("tau must be non-negative")
    kappa, theta, xi, rho, v0, r, q = (
        params.kappa, params.theta, params.xi, params.rho, params.v0, params.r, params.q
    )
    xi2 = xi * xi

    def characteristic(u: np.ndarray) -> np.ndarray:
        u = np.asarray(u, dtype=np.complex128)
        if tau == 0.0:
            return np.ones_like(u)
        b = kappa - rho * xi * 1j * u
        d = np.sqrt(b * b + xi2 * (1j * u + u * u))
        g = (b - d) / (b + d)
        exp_neg_d_tau = np.exp(-d * tau)
        c = (r - q) * 1j * u * tau + (kappa * theta / xi2) * (
            (b - d) * tau - 2.0 * np.log((1.0 - g * exp_neg_d_tau) / (1.0 - g))
        )
        dd = ((b - d) / xi2) * (1.0 - exp_neg_d_tau) / (1.0 - g * exp_neg_d_tau)
        return np.exp(c + dd * v0)

    return characteristic


def heston_call_prices(
    log_strikes: np.ndarray | float,
    params: HestonParameters,
    *,
    tau: float,
) -> np.ndarray:
    """Exact (closed-form Fourier) normalized Heston call prices at one maturity."""
    if tau == 0.0:
        strikes = np.exp(np.asarray(log_strikes, dtype=np.float64))
        return np.clip(1.0 - strikes, 0.0, None)
    char = heston_characteristic_function(params, tau=tau)
    return fourier_call_prices(log_strikes, char)


def heston_surface(
    log_strikes: np.ndarray,
    taus: np.ndarray,
    params: HestonParameters,
) -> np.ndarray:
    """Exact Heston call-price surface, shape (len(taus), len(log_strikes))."""
    return np.stack(
        [heston_call_prices(log_strikes, params, tau=float(tau)) for tau in taus],
        axis=0,
    )


__all__ = [
    "HestonParameters",
    "heston_call_prices",
    "heston_characteristic_function",
    "heston_surface",
]
