"""Shared setup for the DLV/regrid no-arbitrage test hierarchy (Levels 0-7).

No trained checkpoint or certified historical-state report exists in this repo
copy -- see ``paper/DLV_REGRID_MARTINGALE_SUMMARY.md``'s "Reproducibility
pointers", which documents that these large artifacts are intentionally kept
outside Git. Every level in this test hierarchy therefore builds a population
of synthetic initial states directly through the real production classes in
``quantdata/dysanos/flex`` (``FlexSanosDecoder``, ``bound_native_raw``,
``fixed_contract_lvsq_drift``, ``density_martingale_lvsq_step``, ...), so the
tests exercise the actual DLV/regrid numerics -- just not calibrated to real
market history.
"""

from __future__ import annotations

import os

os.environ.setdefault("QUANTDATA_TEST_MODE", "1")

from dataclasses import dataclass

import numpy as np
import torch

from quantdata.biz_calendar import DAYS_PER_YEAR
from quantdata.dysanos.flex.config import (
    FixedRelativeStrikeCappedUnboundedDlvFlexGeometryConfig,
)
from quantdata.dysanos.flex.lvsq_drift import smooth_lvsq_log_loadings
from quantdata.dysanos.flex.model import (
    NativeParameters,
    bound_native_raw,
    raw_from_native_parameters,
)
from quantdata.dysanos.flex.sanos import FlexSanosDecoder, SanosSurface, make_inner_nms_nodes
from quantdata.torch import BaseEnvironment

DEFAULT_NUM_STATES = 256
DEFAULT_NUM_INNER_STRIKES = 61
DEFAULT_NUM_MODEL_EXPIRIES = 10
DEFAULT_SEED = 20260915
DEFAULT_CALENDAR_BUSINESS_DAYS = 5.0
DEFAULT_DLVSQ_ANNUALIZED_LOG_VOLATILITY = 0.10


@dataclass(frozen=True)
class SyntheticPopulation:
    """A batch of synthetic, structurally valid initial FLEX/SANOS states."""

    env: BaseEnvironment
    geometry: FixedRelativeStrikeCappedUnboundedDlvFlexGeometryConfig
    decoder: FlexSanosDecoder
    raw_states: torch.Tensor
    parameters: NativeParameters
    initial_surface: SanosSurface
    loadings: torch.Tensor
    calendar_time_increment_y: float
    num_states: int
    num_inner_strikes: int
    num_model_expiries: int
    seed: int


def build_synthetic_population(
    *,
    num_states: int = DEFAULT_NUM_STATES,
    num_inner_strikes: int = DEFAULT_NUM_INNER_STRIKES,
    num_model_expiries: int = DEFAULT_NUM_MODEL_EXPIRIES,
    seed: int = DEFAULT_SEED,
    calendar_business_days: float = DEFAULT_CALENDAR_BUSINESS_DAYS,
    dlvsq_annualized_log_volatility: float = DEFAULT_DLVSQ_ANNUALIZED_LOG_VOLATILITY,
) -> SyntheticPopulation:
    """Build a diverse population of synthetic states via the real production classes.

    ``num_inner_strikes``/``num_model_expiries`` default smaller than
    production (200/14): the SANOS tridiagonal solve is a Python-level loop
    over the strike axis, so this keeps CPU runtime reasonable while still
    exercising the full numerics non-trivially.
    """

    env = BaseEnvironment(precision=64, device="cpu", debug=False)

    inner_nodes = make_inner_nms_nodes(
        num_inner_strikes=num_inner_strikes, nms_range=(-3.0, 2.0)
    )
    # exp(0) == 1.0 exactly at the single ATM node inner_nodes==0, satisfying
    # the geometry's "exactly one exact ATM node" requirement.
    inner_relative_strikes = tuple(np.exp(0.35 * inner_nodes).tolist())
    geometry = FixedRelativeStrikeCappedUnboundedDlvFlexGeometryConfig(
        num_inner_strikes=num_inner_strikes,
        num_model_expiries=num_model_expiries,
        inner_relative_strikes=inner_relative_strikes,
    )
    decoder = FlexSanosDecoder(env, geometry=geometry)

    rng = np.random.default_rng(seed)
    log_strike = np.log(np.array(inner_relative_strikes))[None, None, :]

    # Vol level 15%-60%, mild skew, small per-expiry term-structure noise.
    dlvsq_level = (rng.uniform(0.15, 0.60, size=(num_states, 1, 1))) ** 2
    skew = rng.uniform(-0.3, 0.3, size=(num_states, 1, 1))
    term_noise = rng.normal(0.0, 0.01, size=(num_states, num_model_expiries, 1))
    dlvsqs_np = dlvsq_level * (1.0 + skew * log_strike) + term_noise
    dlvsqs_np = np.broadcast_to(
        dlvsqs_np, (num_states, num_model_expiries, num_inner_strikes)
    ).copy()
    # Tiny absolute floor only to stay strictly inside the open bound interval
    # (min_dlvsq, max_dlvsq); intentionally NOT a fraction of the full
    # [0.0001, 9.0] range, which would swamp the intended 15%-60% vol spread.
    margin = 1.0e-4
    dlvsqs_np = np.clip(
        dlvsqs_np, geometry.min_dlvsq + margin, geometry.max_dlvsq - margin
    )

    forward_vols_np = rng.uniform(0.15, 0.35, size=(num_states, num_model_expiries))
    eta_np = rng.uniform(0.15, 0.45, size=(num_states, num_model_expiries))

    parameters0 = NativeParameters(
        dlvsqs=torch.as_tensor(dlvsqs_np, dtype=env.fdtype),
        forward_vols=torch.as_tensor(forward_vols_np, dtype=env.fdtype),
        eta=torch.as_tensor(eta_np, dtype=env.fdtype),
    )
    # Round trip through the real bound_native_raw / raw_from_native_parameters
    # pair, so raw_states are genuine native FLEX coordinates, not hand-crafted
    # tensors that happen to look right.
    raw_states = raw_from_native_parameters(parameters0, geometry=geometry)
    parameters = bound_native_raw(raw_states, geometry=geometry)
    initial_surface = decoder.forward_batch(
        dlvsqs=parameters.dlvsqs,
        forward_vols=parameters.forward_vols,
        eta=parameters.eta,
    )
    loadings = smooth_lvsq_log_loadings(
        initial_surface.support_strikes[0, 0],
        num_model_expiries=num_model_expiries,
        annualized_log_volatility=dlvsq_annualized_log_volatility,
    )
    calendar_dt = calendar_business_days / DAYS_PER_YEAR

    return SyntheticPopulation(
        env=env,
        geometry=geometry,
        decoder=decoder,
        raw_states=raw_states,
        parameters=parameters,
        initial_surface=initial_surface,
        loadings=loadings,
        calendar_time_increment_y=calendar_dt,
        num_states=num_states,
        num_inner_strikes=num_inner_strikes,
        num_model_expiries=num_model_expiries,
        seed=seed,
    )


def quantiles(name: str, value: torch.Tensor) -> dict[str, object]:
    """Max / median / high-quantile (p99, p99.9) report, plus n and mean for context."""
    flat = value.detach().cpu().double().reshape(-1).numpy()
    flat = flat[np.isfinite(flat)]
    return {
        "name": name,
        "n": int(flat.size),
        "mean": float(np.mean(flat)) if flat.size else None,
        "median": float(np.median(flat)) if flat.size else None,
        "p99": float(np.quantile(flat, 0.99)) if flat.size else None,
        "p99_9": float(np.quantile(flat, 0.999)) if flat.size else None,
        "maximum": float(np.max(flat)) if flat.size else None,
    }


def abs_quantiles(name: str, value: torch.Tensor) -> dict[str, object]:
    """``quantiles`` applied to ``value.abs()``."""
    return quantiles(name, value.abs())


__all__ = [
    "SyntheticPopulation",
    "abs_quantiles",
    "build_synthetic_population",
    "quantiles",
]
