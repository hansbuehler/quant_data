"""Test hierarchy for dynamic no-arbitrage in the DLV/regrid simulator.

Implements the levels described in ``TASK_SPEC.tex`` (Section 3: "Required
testing hierarchy") against ``quantdata/dysanos/flex``'s DLV/regrid simulator.
"""
