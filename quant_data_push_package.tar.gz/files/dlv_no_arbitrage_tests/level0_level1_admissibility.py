"""Level 0 (static admissibility) and Level 1 (structural dynamic compatibility)
tests for the DLV/regrid simulator in ``quantdata/dysanos/flex``.

Per ``TASK_SPEC.tex`` Section 3:

  Level 0 (static admissibility) - verify at every simulated state:
    - positivity/non-negativity of the density variables
    - unit mass
    - correct forward/spot first moment
    - static strike and calendar no-arbitrage on the declared grid
    - decoder and DLV recursion residuals
    - configured state and DLV bounds
    Report maximum, median and high-quantile residuals, not only pass/fail.

  Level 1 (structural dynamic compatibility) - for the special full-grid DLV
    formulation, test the corresponding pointwise Magnus/Wiese drift equations
    directly and report the maximum equation residual.

See ``dlv_no_arbitrage_tests/common.py`` for why the tested states are
synthetic rather than the real certified historical states.

Every residual below is either a genuine public dataclass field already
computed by the production code, or is reconstructed algebraically from public
fields/functions using the exact same formulas as the source (see comments) --
nothing here reimplements new numerics; it only defers the final ``.max()``
reduction so the full per-node/per-expiry/per-state residual population can be
reported as max/median/p99 rather than a single collapsed number. Each
reconstruction is cross-checked against the production code's own
already-reduced scalar (see the "cross_check_*" entries in Level 1).

Usage::

    QUANTDATA_TEST_MODE=1 PYTHONPATH=. python -m dlv_no_arbitrage_tests.level0_level1_admissibility
"""

from __future__ import annotations

import json

import torch

from quantdata.dysanos.flex.lvsq_drift import (
    _decode_lvsq_branch_densities,
    density_martingale_lvsq_step,
    discrete_lvsq_grid_operator_product,
    fixed_contract_lvsq_drift,
)
from quantdata.dysanos.flex.model import bound_native_raw

from dlv_no_arbitrage_tests.common import abs_quantiles, build_synthetic_population, quantiles


def run(*, report_path: str | None = None) -> dict[str, object]:
    population = build_synthetic_population()
    geometry = population.geometry
    decoder = population.decoder
    raw_states = population.raw_states
    parameters = population.parameters
    initial_surface = population.initial_surface
    loadings = population.loadings
    num_expiries = population.num_model_expiries

    # Round-trip check: bound_native_raw(raw_from_native_parameters(p)) should
    # reproduce p up to the sigmoid/exp inversion's floating-point precision.
    roundtrip_check = abs_quantiles(
        "roundtrip|dlvsq(raw)-dlvsq(target)|",
        parameters.dlvsqs - bound_native_raw(raw_states, geometry=geometry).dlvsqs,
    )

    # -----------------------------------------------------------------
    # LEVEL 0: static admissibility
    # -----------------------------------------------------------------
    level0: dict[str, object] = {}

    level0["positivity_violation (max(0,-density))"] = quantiles(
        "positivity_violation", torch.clamp_min(-initial_surface.densities, 0.0)
    )
    level0["density_minimum_value"] = quantiles(
        "density_minimum_value_by_(state,expiry)", initial_surface.densities.amin(dim=-1)
    )

    mass_residual0 = initial_surface.densities.sum(dim=-1) - 1.0
    level0["unit_mass_residual |sum(density)-1|"] = abs_quantiles(
        "unit_mass_residual", mass_residual0
    )

    forward_residual0 = (
        initial_surface.densities * initial_surface.support_strikes
    ).sum(dim=-1) - 1.0
    level0["first_moment_residual |sum(density*support)-1|"] = abs_quantiles(
        "first_moment_residual", forward_residual0
    )

    # Static calendar no-arbitrage: call(K,T) must be non-decreasing in T. The
    # fixed-relative-strike geometry uses one common cash support at every
    # expiry (build_fixed_grid_dlv_kernel enforces this same invariant), so
    # calls on the SAME strike grid at every expiry can be compared directly.
    support0 = initial_surface.support_strikes[:, 0]  # (B, N+2), same across T
    payoff = torch.clamp_min(support0[:, None, :] - support0[:, :, None], 0.0)
    calls_by_expiry = torch.einsum("bte,bie->bti", initial_surface.densities, payoff)
    calendar_violation = torch.clamp_min(
        calls_by_expiry[:, :-1] - calls_by_expiry[:, 1:], 0.0
    )
    level0["calendar_arbitrage_violation (call(K,T) decreasing in T)"] = quantiles(
        "calendar_arbitrage_violation", calendar_violation
    )
    level0["calendar_arbitrage_note"] = (
        "Static strike no-arbitrage (call convexity in K) is not re-checked "
        "independently: density is constructed as the discrete second "
        "difference of the call curve (sanos.py:_density_from_calls), so "
        "density>=0 IS discrete strike-convexity by construction; re-deriving "
        "it in price space would be a tautological restatement of the "
        "positivity check above, not an independent test."
    )

    level0["dlvsq_lower_bound_margin"] = quantiles(
        "dlvsq_lower_bound_margin", parameters.dlvsqs - geometry.min_dlvsq
    )
    level0["dlvsq_upper_bound_margin"] = quantiles(
        "dlvsq_upper_bound_margin", geometry.max_dlvsq - parameters.dlvsqs
    )
    level0["forward_vol_lower_bound_margin"] = quantiles(
        "forward_vol_lower_bound_margin", parameters.forward_vols - geometry.min_forward_vol
    )
    level0["forward_vol_upper_bound_margin"] = quantiles(
        "forward_vol_upper_bound_margin", geometry.max_forward_vol - parameters.forward_vols
    )
    level0["eta_lower_bound_margin"] = quantiles(
        "eta_lower_bound_margin", parameters.eta - geometry.min_eta
    )
    level0["eta_upper_bound_margin"] = quantiles(
        "eta_upper_bound_margin", geometry.max_eta - parameters.eta
    )

    # Decoder and DLV recursion residuals (density_martingale_lvsq_step).
    finite_step = density_martingale_lvsq_step(
        decoder,
        raw_states,
        raw_log_loadings=loadings,
        calendar_time_increment_y=population.calendar_time_increment_y,
    )

    branch_mass_residual = finite_step.densities_by_branch.sum(dim=-1) - 1.0
    level0["branch_unit_mass_residual"] = abs_quantiles(
        "branch_unit_mass_residual", branch_mass_residual
    )
    branch_forward_residual = (
        finite_step.densities_by_branch * initial_surface.support_strikes[:, None]
    ).sum(dim=-1) - 1.0
    level0["branch_first_moment_residual"] = abs_quantiles(
        "branch_first_moment_residual", branch_forward_residual
    )

    # DLV recursion residual: branch-probability-weighted mean density must
    # equal the pre-step (unconditional) density -- the density tower identity.
    density_mean = torch.einsum(
        "r,brte->bte", finite_step.branch_probabilities, finite_step.densities_by_branch
    )
    dlv_recursion_residual = density_mean - initial_surface.densities
    level0["dlv_recursion_residual |E_branch[density]-density|"] = abs_quantiles(
        "dlv_recursion_residual", dlv_recursion_residual
    )

    # Decoder residual: re-decoding each branch's recovered raw DLV state
    # through the actual SANOS decoder must reproduce the branch density that
    # was used to construct it algebraically.
    decoded_branch_densities = _decode_lvsq_branch_densities(
        decoder, finite_step.raw_states_by_branch
    )
    decoder_residual = decoded_branch_densities - finite_step.densities_by_branch
    level0["decoder_residual |decode(raw_branch)-density_branch|"] = abs_quantiles(
        "decoder_residual", decoder_residual
    )

    level0["branch_dlvsq_lower_bound_margin"] = quantiles(
        "branch_dlvsq_lower_bound_margin",
        finite_step.dlvsqs_by_branch[:, :, 1:] - geometry.min_dlvsq,
    )
    level0["branch_dlvsq_upper_bound_margin"] = quantiles(
        "branch_dlvsq_upper_bound_margin",
        geometry.max_dlvsq - finite_step.dlvsqs_by_branch[:, :, 1:],
    )
    level0["fallback_coordinate_fraction (already-reduced production scalar)"] = float(
        finite_step.fallback_coordinate_fraction.detach().cpu()
    )
    level0["minimum_raw_cap_margin (already-reduced production scalar)"] = float(
        finite_step.minimum_raw_cap_margin.detach().cpu()
    )

    # -----------------------------------------------------------------
    # LEVEL 1: structural dynamic compatibility (pointwise Magnus/Wiese drift
    # equations for the special full-grid DLV formulation, per the task
    # spec's own carve-out for this simulator class).
    # -----------------------------------------------------------------
    level1: dict[str, object] = {}

    drift = fixed_contract_lvsq_drift(decoder, raw_states, raw_log_loadings=loadings)

    # Drift equation residual: exact per-node reconstruction of
    # lvsq_drift.py's per-expiry expression, kept unreduced.
    drift_terms = []
    for expiry_index in range(1, num_expiries):
        density_interior = drift.densities[:, expiry_index, 1:-1]
        physical_drift = drift.dlvsq_drift[:, expiry_index]
        physical_diffusion = drift.dlvsq_diffusion[:, expiry_index]
        current_dd_interior = drift.density_diffusion[:, expiry_index, 1:-1, :]
        term = density_interior * physical_drift + torch.sum(
            current_dd_interior * physical_diffusion, dim=-1
        )
        drift_terms.append(term)
    drift_equation_residual = torch.stack(drift_terms, dim=1)  # (B, T-1, N)
    level1["drift_equation_residual (pointwise Magnus/Wiese drift equation)"] = (
        abs_quantiles("drift_equation_residual", drift_equation_residual)
    )

    # Volatility/diffusion equation residual: exact per-node reconstruction,
    # kept unreduced.
    support = initial_surface.support_strikes
    vol_terms = []
    for expiry_index in range(1, num_expiries):
        dt = decoder.model_dts_y[expiry_index]
        support_e = support[:, expiry_index]
        density_e = drift.densities[:, expiry_index]
        dlvsq_e = parameters.dlvsqs[:, expiry_index]
        physical_diffusion_e = drift.dlvsq_diffusion[:, expiry_index]
        current_dd_e = drift.density_diffusion[:, expiry_index]
        previous_dd = drift.density_diffusion[:, expiry_index - 1]

        source = discrete_lvsq_grid_operator_product(
            support_e,
            density_e[:, 1:-1].unsqueeze(-1) * physical_diffusion_e,
            expiry_time_increment_y=dt,
        )
        rhs = previous_dd - source
        lhs = current_dd_e + discrete_lvsq_grid_operator_product(
            support_e,
            current_dd_e[:, 1:-1] * dlvsq_e.unsqueeze(-1),
            expiry_time_increment_y=dt,
        )
        vol_terms.append(lhs - rhs)
    volatility_equation_residual = torch.stack(vol_terms, dim=1)  # (B, T-1, N+2, F)
    level1["volatility_equation_residual (diffusion-consistency equation)"] = (
        abs_quantiles("volatility_equation_residual", volatility_equation_residual)
    )

    # Cross-check: the full reconstructions must be consistent with the
    # production code's own already-reduced scalars (sanity check on the
    # reconstruction itself, not a new simulator property).
    level1["cross_check_production_maximum_drift_equation_residual"] = float(
        drift.maximum_drift_equation_residual.detach().cpu()
    )
    level1["cross_check_reconstructed_maximum_drift_equation_residual"] = float(
        drift_equation_residual.abs().max().detach().cpu()
    )
    level1["cross_check_production_maximum_volatility_equation_residual"] = float(
        drift.maximum_volatility_equation_residual.detach().cpu()
    )
    level1["cross_check_reconstructed_maximum_volatility_equation_residual"] = float(
        volatility_equation_residual.abs().max().detach().cpu()
    )

    level1["density_diffusion_mass_residual (already-reduced production scalar)"] = float(
        drift.maximum_density_diffusion_mass_residual.detach().cpu()
    )
    level1["density_diffusion_forward_residual (already-reduced production scalar)"] = float(
        drift.maximum_density_diffusion_forward_residual.detach().cpu()
    )
    level1["minimum_raw_cap_margin (already-reduced production scalar)"] = float(
        drift.minimum_raw_cap_margin.detach().cpu()
    )

    report = {
        "config": {
            "num_states": population.num_states,
            "num_inner_strikes": population.num_inner_strikes,
            "num_model_expiries": population.num_model_expiries,
            "num_branches": int(len(finite_step.branch_probabilities)),
            "calendar_time_increment_business_days": 5.0,
            "seed": population.seed,
            "note": (
                "Synthetic initial states (not calibrated to real market "
                "history); see dlv_no_arbitrage_tests/common.py."
            ),
        },
        "roundtrip_sanity_check": roundtrip_check,
        "level0_static_admissibility": level0,
        "level1_structural_dynamic_compatibility": level1,
    }

    if report_path:
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2, default=str)

    return report


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, default=str))
