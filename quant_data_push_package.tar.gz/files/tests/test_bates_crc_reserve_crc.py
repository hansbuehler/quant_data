"""Tests for quantdata.dysanos.bates_crc.reserve_crc, including an exact
reproduction of the DYSANOS II manuscript's own synthetic reset sequence
(Section 12, "A fully specified synthetic reset sequence")."""

from __future__ import annotations

import pytest

from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.reserve_crc import (
    BcrcState,
    JumpBox,
    ReserveSchedule,
    apply_reset,
    branching_lemma_sanity_check,
    dominating_envelope_params,
    dominating_R_star,
    initial_state,
    integrated_reserve,
    reserve_ell,
    verify_envelope_dominates,
)

HESTON = HestonParams(kappa=2.0, theta=0.040, xi=0.30, rho=-0.70)
BOX = JumpBox(Lambda=0.5, M=0.05, delta_min=0.08, delta_max=0.15, s_star=0.25)
SCHEDULE = ReserveSchedule(
    reset_times=(2 / 252, 7 / 252, 12 / 252), reserve_sizes=(0.006, 0.006, 0.006),
    theta_min=0.025, theta_max=0.055,
)
JUMPS_PATH = (
    GaussianJumpParams(lambda_J=0.20, m_J=-0.03, delta_J=0.10),
    GaussianJumpParams(lambda_J=0.35, m_J=-0.02, delta_J=0.12),
    GaussianJumpParams(lambda_J=0.15, m_J=0.01, delta_J=0.09),
    GaussianJumpParams(lambda_J=0.40, m_J=-0.04, delta_J=0.14),
)
DELTAS = (0.004, -0.007, 0.005)


def _run_full_sequence() -> BcrcState:
    state = initial_state(theta_0=0.040, jumps_0=JUMPS_PATH[0], schedule=SCHEDULE)
    for k in range(3):
        state, _ = apply_reset(
            state, proposed_delta_n=DELTAS[k], proposed_jumps_n=JUMPS_PATH[k + 1],
            box=BOX, schedule=SCHEDULE,
        )
    return state


def test_reproduces_manuscript_theta_path_exactly():
    state = _run_full_sequence()
    expected = (0.040, 0.044, 0.037, 0.042)
    for got, want in zip(state.theta_path, expected, strict=True):
        assert abs(got - want) < 1.0e-12


def test_reproduces_manuscript_used_reserve_column_exactly():
    state = _run_full_sequence()
    expected_b_used = (0.002, 0.013, 0.001)
    for got, want in zip(state.b_used, expected_b_used, strict=True):
        assert abs(got - want) < 1.0e-12


def test_dominating_R_star_bounds_every_box_member_density_ratio():
    corners = [
        GaussianJumpParams(lambda_J=0.5, m_J=m, delta_J=d)
        for m in (-BOX.M, 0.0, BOX.M) for d in (BOX.delta_min, BOX.delta_max)
    ]
    for jumps in corners:
        report = verify_envelope_dominates(BOX, jumps)
        assert report["dominated_on_grid"]
        assert report["closed_form_bound_within_R_star"]


def test_envelope_rejects_out_of_box_jumps():
    outside = GaussianJumpParams(lambda_J=0.5, m_J=0.0, delta_J=0.5)  # delta_J > s_star region
    with pytest.raises(ValueError):
        verify_envelope_dominates(BOX, outside)


def test_apply_reset_rejects_infeasible_delta_by_projecting_not_silently_accepting():
    state = initial_state(theta_0=0.040, jumps_0=JUMPS_PATH[0], schedule=SCHEDULE)
    # propose a delta far outside the admissible interval
    new_state, diag = apply_reset(
        state, proposed_delta_n=10.0, proposed_jumps_n=JUMPS_PATH[1], box=BOX, schedule=SCHEDULE,
    )
    assert diag["projected"]
    assert new_state.theta_path[-1] <= SCHEDULE.theta_max + 1.0e-12
    assert new_state.b_used[0] >= -1.0e-12


def test_apply_reset_rejects_jump_params_outside_box():
    state = initial_state(theta_0=0.040, jumps_0=JUMPS_PATH[0], schedule=SCHEDULE)
    bad_jumps = GaussianJumpParams(lambda_J=100.0, m_J=0.0, delta_J=0.1)
    with pytest.raises(ValueError):
        apply_reset(state, proposed_delta_n=0.001, proposed_jumps_n=bad_jumps, box=BOX, schedule=SCHEDULE)


def test_branching_lemma_sanity_check_finds_no_violations_and_is_labelled_supplementary():
    report = branching_lemma_sanity_check((0.5, 1.0, 2.0, 5.0, 10.0), (0.005, 0.02, 20 / 252), HESTON)
    assert report["n_violations"] == 0
    assert "not" in report["note"].lower() and "proof" in report["note"].lower()


def test_reserve_ell_vanishes_at_u_equals_minus_i():
    """The full reset-corrected reserve exponent should inherit the
    martingale normalisation (each of its D(.,r) and jump-exponent pieces
    vanishes at u=-i individually, per heston_riccati's own tests)."""
    state = _run_full_sequence()
    envelope = dominating_envelope_params(BOX)
    for s in (0.0, 3 / 252, 8 / 252, 13 / 252, 18 / 252):
        value = reserve_ell(-1j, s, state, SCHEDULE, HESTON, envelope)
        assert abs(value) < 1.0e-10, (s, value)


def test_integrated_reserve_vanishes_at_u_equals_minus_i():
    state = _run_full_sequence()
    envelope = dominating_envelope_params(BOX)
    value = integrated_reserve(-1j, 13 / 252, 20 / 252, state, SCHEDULE, HESTON, envelope)
    assert abs(value) < 1.0e-9
