"""Tests for quantdata.dysanos.bates_crc.verification: the Task 4/Section 5
verification battery (chain composition, off-grid generator residual,
protected-option sweep, and the compensated-vs-uncompensated negative
control)."""

from __future__ import annotations

import pytest

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.reserve_crc import (
    JumpBox,
    ReserveSchedule,
    apply_reset,
    dominating_envelope_params,
    initial_state,
)
from quantdata.dysanos.bates_crc.verification import (
    chain_composition_residual,
    protected_option_sweep,
    quadrature_refinement_convergence,
    verify_negative_control,
    y_factor_generator_residual,
)

HESTON = HestonParams(kappa=2.0, theta=0.040, xi=0.30, rho=-0.70)
BOX = JumpBox(Lambda=0.5, M=0.05, delta_min=0.08, delta_max=0.15, s_star=0.25)
SCHEDULE = ReserveSchedule(
    reset_times=(2 / 252, 7 / 252, 12 / 252), reserve_sizes=(0.006, 0.006, 0.006),
    theta_min=0.025, theta_max=0.055,
)
JUMPS_PATH = (
    GaussianJumpParams(lambda_J=0.20, m_J=-0.03, delta_J=0.10),
    GaussianJumpParams(lambda_J=0.35, m_J=-0.02, delta_J=0.12),
    GaussianJumpParams(lambda_J=0.15, m_J=0.01, delta_J=0.09),
    GaussianJumpParams(lambda_J=0.40, m_J=-0.04, delta_J=0.14),
)
DELTAS = (0.004, -0.007, 0.005)
V_0 = 0.04
CHAIN_CONFIG = ChainGeneratorConfig(anchors=(0.7, 0.85, 1.0, 1.15, 1.3), initial_index=2, kappa=8.0, sigma_y=0.0)


def _states():
    states = [initial_state(theta_0=0.040, jumps_0=JUMPS_PATH[0], schedule=SCHEDULE)]
    for k in range(3):
        new_state, _ = apply_reset(
            states[-1], proposed_delta_n=DELTAS[k], proposed_jumps_n=JUMPS_PATH[k + 1],
            box=BOX, schedule=SCHEDULE,
        )
        states.append(new_state)
    return states


def test_chain_transition_matrix_satisfies_chapman_kolmogorov():
    for tau1, tau2 in ((3 / 252, 4 / 252), (1 / 252, 15 / 252)):
        residual = chain_composition_residual(CHAIN_CONFIG, tau1, tau2)
        assert residual < 1.0e-8, (tau1, tau2, residual)


def test_off_grid_generator_residual_vanishes_pre_and_post_reset():
    """Checked at OFF-GRID maturities that coincide with neither a reset
    time nor a scheduled model expiry."""
    states = _states()
    envelope = dominating_envelope_params(BOX)
    off_grid_Ts = (3.3 / 252, 9.1 / 252, 17.7 / 252)
    for state in states:
        for T in off_grid_Ts:
            report = y_factor_generator_residual(0.6 + 0.2j, 0.0, T, V_0, HESTON, state, SCHEDULE, envelope,
                                                   n_quad=400)
            assert report["abs_residual"] < 5.0e-4, report


def test_protected_option_sweep_all_resets_all_strikes_exact_invariance():
    states = _states()
    envelope = dominating_envelope_params(BOX)
    u_mesh = (0.3, 0.7 + 0.1j, 1.5 - 0.4j, -0.9 + 0.2j)
    results = protected_option_sweep(states, SCHEDULE, HESTON, V_0, envelope, u_mesh, n_quad=400)
    assert len(results) == 3 * 4 * len(u_mesh)  # 3 resets x 4 maturity fractions x |u_mesh|
    for r in results:
        assert r.abs_phi_difference < 1.0e-8, r


def test_quadrature_refinement_converges_monotonically():
    envelope = dominating_envelope_params(BOX)
    state = _states()[2]
    report = quadrature_refinement_convergence(0.7 + 0.1j, 0.0, 20 / 252, V_0, HESTON, state, SCHEDULE, envelope)
    assert report["monotone_decreasing"], report
    assert report["errors"][0]["abs_error_vs_reference"] > report["errors"][-1]["abs_error_vs_reference"]
    assert report["errors"][-1]["abs_error_vs_reference"] < 1.0e-8


def test_negative_control_uncompensated_transform_violates_invariance():
    """The uncompensated transform must FAIL protected-option invariance --
    otherwise the numerical test has no power and the positive result on
    the real construction would be uninformative."""
    states = _states()
    report = verify_negative_control(states, SCHEDULE, HESTON, V_0)
    assert report["control_fails_as_expected"]
    assert report["max_abs_phi_difference"] > 1.0e-5
