"""Tests for quantdata.dysanos.bates_crc.comparison_interface."""

from __future__ import annotations

from datetime import date

import numpy as np
import pytest

from quantdata.dysanos.bates_crc.comparison_interface import (
    ChainGeneratorConfig,
    ChronologicalSplitConfig,
    CoherentChainBlackAdapter,
    ContractSpec,
    DEFAULT_SPLIT,
    NotImplementedAdapter,
    run_comparison,
)


def _model() -> CoherentChainBlackAdapter:
    cfg = ChainGeneratorConfig(anchors=(80.0, 100.0, 120.0), initial_index=1, kappa=2.0, sigma_y=0.2)
    return CoherentChainBlackAdapter(cfg)


def test_price_is_positive_and_monotone_decreasing_in_strike():
    model = _model()
    contracts = [ContractSpec(f"c{i}", "SYN", date(2024, 7, 1), k) for i, k in enumerate([90.0, 100.0, 110.0])]
    prices = model.price(date(2024, 1, 1), contracts)
    assert np.all(prices > 0.0)
    assert prices[0] > prices[1] > prices[2]


def test_generator_residual_is_at_finite_difference_floor():
    model = _model()
    for tau in (0.1, 0.5, 1.0):
        for k in (90.0, 100.0, 110.0):
            for y in (0.9, 1.0, 1.1):
                r = model.verify_zero_generator_residual(tau, k, y=y)
                assert abs(r["residual"]) < 1.0e-3, r


def test_terminal_payoff_matches_intrinsic_value():
    model = _model()
    row = model._H_row(0.0, 1.05, 100.0)
    x = np.asarray(model.config.anchors)
    np.testing.assert_allclose(row, np.maximum(x * 1.05 - 100.0, 0.0))


def test_transition_matrix_is_a_valid_markov_generator_exponential():
    model = _model()
    P = model.transition_matrix(0.5)
    np.testing.assert_allclose(P.sum(axis=1), 1.0, atol=1.0e-10)
    assert np.all(P >= -1.0e-12)


def test_run_comparison_records_not_implemented_reasons_per_contract():
    contracts = [ContractSpec("c0", "SYN", date(2024, 7, 1), 100.0)]
    stub = NotImplementedAdapter("stub_model", "missing reason text")
    rows = run_comparison(date(2024, 1, 1), contracts, [_model(), stub])
    implemented_rows = [r for r in rows if r.model_name == "coherent_dlv_x_black_chain"]
    stub_rows = [r for r in rows if r.model_name == "stub_model"]
    assert implemented_rows[0].price is not None and implemented_rows[0].error is None
    assert stub_rows[0].price is None and stub_rows[0].error == "missing reason text"


def test_chronological_split_rejects_out_of_order_dates():
    with pytest.raises(ValueError):
        ChronologicalSplitConfig(
            train_start=date(2024, 1, 1), train_end=date(2023, 1, 1),
            validation_start=date(2025, 1, 1), validation_end=date(2025, 6, 1),
        )


def test_dy2_flex_adapter_prices_a_real_decoder():
    import torch

    from quantdata.dysanos.flex.crc_extension.section2_pricing_identity import BaseEnvironment, build_simulator
    from quantdata.dysanos.bates_crc.comparison_interface import Dy2FlexAdapter

    env = BaseEnvironment(precision=64, device="cpu", debug=True)
    sim = build_simulator(env)
    state = torch.zeros(sim.dynamics.reduced_state_size, dtype=torch.float64)
    adapter = Dy2FlexAdapter(sim, state, spot=1.0)
    contracts = [ContractSpec(f"c{i}", "SYN", date(2024, 7, 1), k) for i, k in enumerate([0.9, 1.0, 1.1])]
    prices = adapter.price(date(2024, 1, 1), contracts)
    assert adapter.is_implemented()
    assert np.all(prices > 0.0)
    assert prices[0] > prices[1] > prices[2]


def test_default_split_matches_weekly_dynamics_phase3_constants():
    from quantdata.dysanos.flex.weekly_dynamics import (
        PHASE3_TRAIN_END, PHASE3_TRAIN_START, PHASE3_VALIDATION_END, PHASE3_VALIDATION_START,
    )
    assert DEFAULT_SPLIT.train_start == PHASE3_TRAIN_START
    assert DEFAULT_SPLIT.train_end == PHASE3_TRAIN_END
    assert DEFAULT_SPLIT.validation_start == PHASE3_VALIDATION_START
    assert DEFAULT_SPLIT.validation_end == PHASE3_VALIDATION_END
