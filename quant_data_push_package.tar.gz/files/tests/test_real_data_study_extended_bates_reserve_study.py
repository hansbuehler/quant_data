"""Synthetic tests for real_data_study.extended_bates_reserve_study --
does not require real market data."""

from __future__ import annotations

import numpy as np
import pytest

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study import config as cfg
from quantdata.dysanos.bates_crc.real_data_study.chain_bates_calibration import ChainBatesCalibrationResult
from quantdata.dysanos.bates_crc.real_data_study.extended_bates_reserve_study import (
    admissible_theta_interval,
    build_reserve_setup,
    reserve_price_shift,
    reset_surface_change,
)


def _fake_calib() -> ChainBatesCalibrationResult:
    anchors, i0 = cfg.build_anchors(5, 0.2)
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=i0, kappa=10.0, sigma_y=0.0)
    heston = HestonParams(kappa=2.0, theta=0.04, xi=0.3, rho=-0.6)
    jumps = GaussianJumpParams(lambda_J=0.2, m_J=-0.02, delta_J=0.08)
    return ChainBatesCalibrationResult(chain_config=chain_config, heston=heston, jumps=jumps, V_t=0.04)


def test_build_reserve_setup_none_for_zero_budget():
    calib = _fake_calib()
    assert build_reserve_setup(calib, 0.0) is None


def test_build_reserve_setup_produces_dominated_envelope():
    calib = _fake_calib()
    setup = build_reserve_setup(calib, 0.01)
    assert setup is not None
    assert setup.box.contains(calib.jumps)


def test_reserve_price_shift_is_nonzero_for_positive_budget_and_zero_for_zero_budget():
    calib = _fake_calib()
    strikes = np.array([0.9, 1.0, 1.1])
    expiries = np.array([0.05, 0.2, 0.5])

    zero = reserve_price_shift(calib, 0.0, strikes, expiries)
    assert np.allclose(zero["shift"], 0.0)

    nonzero = reserve_price_shift(calib, 0.02, strikes, expiries)
    assert np.any(np.abs(nonzero["shift"]) > 1e-8)


def test_admissible_theta_interval_respects_bounds():
    calib = _fake_calib()
    lo, hi = admissible_theta_interval(calib, 0.01)
    assert lo <= 0.0 <= hi or lo <= hi  # interval must be well-formed
    assert lo <= hi


def test_reset_surface_change_only_repriced_beyond_reset_time():
    calib = _fake_calib()
    reserve_size = 0.02
    strikes = np.array([0.9, 1.0, 1.1, 0.95])
    expiries = np.array([0.02, 0.3, 0.5, cfg.RESERVE_RESET_HORIZON_YEARS * 0.5])  # last one before reset -> excluded
    result = reset_surface_change(calib, reserve_size, delta_fraction=1.0, strikes=strikes, expiries=expiries)
    assert len(result["strikes"]) == 2  # only the two expiries > reset horizon
    lo, hi = result["admissible_interval"]
    assert lo - 1e-9 <= result["delta_applied"] <= hi + 1e-9


def test_reset_surface_change_raises_if_nothing_beyond_reset():
    calib = _fake_calib()
    strikes = np.array([1.0])
    expiries = np.array([0.001])
    with pytest.raises(ValueError):
        reset_surface_change(calib, 0.02, delta_fraction=0.5, strikes=strikes, expiries=expiries)
