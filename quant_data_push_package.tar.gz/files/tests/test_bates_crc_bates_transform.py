"""Tests for quantdata.dysanos.bates_crc.bates_transform: the combined
continuation transform, its martingale normalisation, Fourier pricing, and
an independent Monte Carlo cross-check.

Includes a regression test for a non-obvious analytic fact discovered while
building this module and recorded in AUDIT.md: the "current" jump
parameters p_n = state.jump_params_path[-1] cancel EXACTLY out of
Phi_t(u,T) against the "j-bar(u) - j_{p_n}(u)" term inside the reserve
integral, for every t,T (not only before the first reset). The transform
therefore depends on p_n only insofar as p_n constrains which Delta_n were
admissible at past resets (via the feasibility interval) -- p_n itself
never appears in the priced Q-dynamics. The actual driving jump law is
always the fixed dominating envelope nu-bar plus the scheduled branching
corrections kappa*b_used[k]*D(u,s-t_k).
"""

from __future__ import annotations

import numpy as np
import pytest

from quantdata.dysanos.bates_crc.heston_riccati import (
    GaussianJumpParams,
    HestonParams,
    gaussian_bates_jump_exponent,
    riccati_A_closed_form,
    riccati_D_closed_form,
)
from quantdata.dysanos.bates_crc.reserve_crc import (
    JumpBox,
    ReserveSchedule,
    apply_reset,
    dominating_envelope_params,
    initial_state,
)
from quantdata.dysanos.bates_crc.bates_transform import (
    FourierPricingConfig,
    continuation_transform,
    fourier_call_price,
    gauss_hermite_mc_cross_check,
    verify_martingale_normalisation,
)

HESTON = HestonParams(kappa=2.0, theta=0.040, xi=0.30, rho=-0.70)
BOX = JumpBox(Lambda=0.5, M=0.05, delta_min=0.08, delta_max=0.15, s_star=0.25)
SCHEDULE = ReserveSchedule(
    reset_times=(2 / 252, 7 / 252, 12 / 252), reserve_sizes=(0.006, 0.006, 0.006),
    theta_min=0.025, theta_max=0.055,
)
JUMPS_PATH = (
    GaussianJumpParams(lambda_J=0.20, m_J=-0.03, delta_J=0.10),
    GaussianJumpParams(lambda_J=0.35, m_J=-0.02, delta_J=0.12),
    GaussianJumpParams(lambda_J=0.15, m_J=0.01, delta_J=0.09),
    GaussianJumpParams(lambda_J=0.40, m_J=-0.04, delta_J=0.14),
)
DELTAS = (0.004, -0.007, 0.005)
V_0 = 0.04


def _states():
    """Returns [state_0 (pre-reset), state_1, state_2, state_3] along the
    manuscript's own synthetic sequence."""
    states = [initial_state(theta_0=0.040, jumps_0=JUMPS_PATH[0], schedule=SCHEDULE)]
    for k in range(3):
        new_state, _ = apply_reset(
            states[-1], proposed_delta_n=DELTAS[k], proposed_jumps_n=JUMPS_PATH[k + 1],
            box=BOX, schedule=SCHEDULE,
        )
        states.append(new_state)
    return states


def _envelope():
    return dominating_envelope_params(BOX)


def test_martingale_normalisation_full_transform_pre_and_post_reset():
    states = _states()
    envelope = _envelope()
    maturities = (5 / 252, 10 / 252, 15 / 252, 20 / 252)
    for state in states:
        for T in maturities:
            report = verify_martingale_normalisation(0.0, T, V_0, HESTON, state, SCHEDULE, envelope)
            assert report["abs_error_phi_0"] < 1.0e-8, report
            assert report["abs_error_phi_minus_i"] < 1.0e-8, report


def test_jump_parameters_cancel_exactly_from_the_transform():
    """Regression test for the cancellation identity documented in the
    module docstring and AUDIT.md: Phi_t(u,T) depends on the CURRENT jump
    parameters p_n only through feasibility, not through the priced
    dynamics -- replacing p_n with an arbitrary OTHER admissible jump law
    (while leaving b_used, theta_path unchanged) must leave Phi_t(u,T)
    unchanged."""
    state = _states()[2]
    envelope = _envelope()
    T = 20 / 252
    phi_original = continuation_transform(0.7 + 0.1j, 0.0, T, V_0, HESTON, state, SCHEDULE, envelope, n_quad=800)

    from dataclasses import replace
    decoy_jumps = GaussianJumpParams(lambda_J=0.49, m_J=0.049, delta_J=0.14)
    assert BOX.contains(decoy_jumps)
    decoy_state = replace(state, jump_params_path=state.jump_params_path[:-1] + (decoy_jumps,))
    phi_decoy = continuation_transform(0.7 + 0.1j, 0.0, T, V_0, HESTON, decoy_state, SCHEDULE, envelope, n_quad=800)

    assert abs(phi_original - phi_decoy) < 1.0e-9, (phi_original, phi_decoy)


def test_continuation_transform_matches_hand_derived_closed_form():
    """Cross-checks continuation_transform against an independently
    assembled closed form: V_t*D + A + tau*j_bar(u) + kappa*sum_k
    b_used[k]*integral D(u,s-t_k) ds, using a SEPARATE Gauss-Legendre
    quadrature loop written directly in this test (not calling
    reserve_crc.integrated_reserve)."""
    state = _states()[1]
    envelope = _envelope()
    nodes, weights = np.polynomial.legendre.leggauss(400)
    for u in (0.3, 1.0 - 1.0j, 2.0 + 0.2j):
        for T in (7 / 252, 20 / 252):
            tau = T
            D = riccati_D_closed_form(u, tau, HESTON)
            A = riccati_A_closed_form(u, tau, HESTON)
            jbar = gaussian_bates_jump_exponent(u, envelope)
            extra = 0.0
            for k, t_k in enumerate(SCHEDULE.reset_times):
                lo = max(0.0, t_k)
                if lo >= T:
                    continue
                half = 0.5 * (T - lo)
                mid = 0.5 * (T + lo)
                s_nodes = mid + half * nodes
                D_vals = np.array([riccati_D_closed_form(u, s - t_k, HESTON) for s in s_nodes])
                extra += HESTON.kappa * state.b_used[k] * half * np.sum(weights * D_vals)
            candidate = np.exp(V_0 * D + A + tau * jbar + extra)
            phi = continuation_transform(u, 0.0, T, V_0, HESTON, state, SCHEDULE, envelope, n_quad=800)
            assert abs(phi - candidate) < 1.0e-9, (u, T, phi, candidate)


def test_fourier_call_price_matches_independent_monte_carlo_before_first_reset():
    """The decisive independent pricing check for Section 2/eq:bcrc-fourier-price:
    before the first reset (T <= t_1), the reserve sum contributes nothing
    (no t_k <= s for s < t_1), so by the cancellation identity the priced
    dynamics reduce EXACTLY to Heston diffusion + Gaussian jumps under the
    dominating envelope nu-bar alone. A from-scratch Monte Carlo simulation
    (gauss_hermite_mc_cross_check) of exactly that model must therefore
    agree with fourier_call_price to within a few Monte Carlo standard
    errors."""
    state = _states()[0]
    envelope = _envelope()
    T = 2 / 252  # first reset at t_1 = 2/252; price at maturity T = t_1 itself
    strike = 1.0
    config = FourierPricingConfig(n_quad=600, u_max=300.0)
    fourier_price = fourier_call_price(strike, 0.0, T, V_0, HESTON, state, SCHEDULE, envelope, config,
                                        n_reserve_quad=400)
    mc = gauss_hermite_mc_cross_check(strike, 0.0, T, V_0, HESTON, envelope, n_paths=400_000, n_var_substeps=100)
    diff = abs(fourier_price - mc["mc_price"])
    assert diff < 6.0 * mc["mc_standard_error"], (fourier_price, mc)


def test_fourier_call_price_matches_monte_carlo_with_a_second_strike_and_seed():
    state = _states()[0]
    envelope = _envelope()
    T = 2 / 252
    strike = 1.01
    config = FourierPricingConfig(n_quad=600, u_max=300.0)
    fourier_price = fourier_call_price(strike, 0.0, T, V_0, HESTON, state, SCHEDULE, envelope, config,
                                        n_reserve_quad=400)
    mc = gauss_hermite_mc_cross_check(strike, 0.0, T, V_0, HESTON, envelope, n_paths=400_000, n_var_substeps=100,
                                       seed=123)
    diff = abs(fourier_price - mc["mc_price"])
    assert diff < 6.0 * mc["mc_standard_error"], (fourier_price, mc)


def test_fourier_call_price_is_nonnegative_and_below_forward():
    states = _states()
    envelope = _envelope()
    config = FourierPricingConfig(n_quad=400, u_max=200.0)
    for state in states:
        for strike in (0.9, 1.0, 1.1):
            price = fourier_call_price(strike, 0.0, 20 / 252, V_0, HESTON, state, SCHEDULE, envelope, config)
            assert price >= -1.0e-8
            assert price <= 1.0 + 1.0e-6


def test_pre_and_post_reset_prices_agree_for_maturities_before_the_reset():
    """Section 5's pre/post-reset call-equality check, restricted here to
    a single representative maturity that lies BEFORE any scheduled reset
    (T = t_1); the full protected-option-book sweep across every scheduled
    maturity lives in the Task 4 verification module. For T < t_1, the
    reset at t_1 has not yet occurred in EITHER state's pricing horizon, so
    prices computed from state_0 and from state_1 (which additionally
    knows the realised t_1 outcome, but that outcome cannot affect a price
    with T < t_1) must agree exactly."""
    states = _states()
    envelope = _envelope()
    config = FourierPricingConfig(n_quad=400, u_max=200.0)
    T = 2 / 252 - 1.0 / 252  # strictly before t_1
    for strike in (0.95, 1.0, 1.05):
        p0 = fourier_call_price(strike, 0.0, T, V_0, HESTON, states[0], SCHEDULE, envelope, config)
        p1 = fourier_call_price(strike, 0.0, T, V_0, HESTON, states[1], SCHEDULE, envelope, config)
        assert abs(p0 - p1) < 1.0e-6, (strike, p0, p1)
