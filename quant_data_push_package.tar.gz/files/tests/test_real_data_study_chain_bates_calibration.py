"""Tests for quantdata.dysanos.bates_crc.real_data_study.chain_bates_calibration.

With 9 free parameters and a small synthetic grid, exact per-parameter
recovery is not a robust thing to assert (a known feature of Bates
calibration -- parameters can be weakly identified from one day's smile).
These tests instead assert convergence, a small final cost (fitted prices
match the synthetic targets), and that fitted prices reproduce the
TRUE-parameter prices closely on a fresh out-of-sample grid -- a more
robust way to confirm the fit is meaningful than raw parameter recovery.
"""

from __future__ import annotations

from datetime import date

import numpy as np
import pytest

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study import config as cfg
from quantdata.dysanos.bates_crc.real_data_study.chain_bates_calibration import (
    ChainBatesCalibrationError,
    calibrate_chain_bates,
)
from quantdata.dysanos.bates_crc.real_data_study.chain_pricer import price_calls_chain_bates
from quantdata.dysanos.bates_crc.real_data_study.day_loader import EvaluationContract, EvaluationSet

TRUE_CHAIN_KAPPA = 12.0
TRUE_V_T = 0.04
TRUE_HESTON = HestonParams(kappa=2.0, theta=0.045, xi=0.35, rho=-0.6)
TRUE_JUMPS = GaussianJumpParams(lambda_J=0.3, m_J=-0.02, delta_J=0.1)

_N_QUAD, _U_MAX = 80, 150.0  # reduced quadrature for calibration speed in tests


def _true_chain_config():
    anchors, i0 = cfg.build_anchors(cfg.N_ANCHORS)
    return ChainGeneratorConfig(anchors=anchors, initial_index=i0, kappa=TRUE_CHAIN_KAPPA, sigma_y=0.0)


def _synthetic_evaluation_set(spread: float = 0.0008) -> EvaluationSet:
    chain_config = _true_chain_config()
    tenors = [1 / 12, 2 / 12, 3 / 12, 0.5, 1.0]
    moneyness = [0.85, 0.925, 1.0, 1.075, 1.15, 1.2]
    strikes = np.array([m for t in tenors for m in moneyness])
    expiries = np.array([t for t in tenors for _ in moneyness])
    mid = price_calls_chain_bates(chain_config, TRUE_HESTON, TRUE_JUMPS, TRUE_V_T, strikes, expiries,
                                   n_quad=_N_QUAD, u_max=_U_MAX)
    contracts = [
        EvaluationContract(expiry_years=float(t), target_tenor_years=float(t), target_moneyness=float(k),
                            strike=float(k), bid=float(p - spread), ask=float(p + spread), dy2_model_mask=True,
                            log_moneyness_error=0.0)
        for t, k, p in zip(expiries, strikes, mid, strict=True)
    ]
    return EvaluationSet(ticker="SYNTH", d=date(2024, 1, 2), contracts=contracts, excluded=[])


def test_synthetic_recovery_converges_with_small_cost_and_matches_out_of_sample():
    ev = _synthetic_evaluation_set()
    result = calibrate_chain_bates(ev, seed=1, n_quad=_N_QUAD, u_max=_U_MAX)
    assert result.converged, result.starts
    assert result.final_cost < 2.0, result.starts

    oos_strikes = np.array([0.9, 0.95, 1.0, 1.05, 1.1])
    oos_expiries = np.full(5, 0.4)
    true_prices = price_calls_chain_bates(_true_chain_config(), TRUE_HESTON, TRUE_JUMPS, TRUE_V_T, oos_strikes,
                                           oos_expiries, n_quad=_N_QUAD, u_max=_U_MAX)
    fitted_prices = result.price(oos_strikes, oos_expiries, n_quad=_N_QUAD, u_max=_U_MAX)
    max_abs_diff = np.max(np.abs(true_prices - fitted_prices))
    assert max_abs_diff < 0.01, (true_prices, fitted_prices)


def test_martingale_verification_fields_populated_and_tiny():
    ev = _synthetic_evaluation_set()
    result = calibrate_chain_bates(ev, seed=2, n_quad=_N_QUAD, u_max=_U_MAX)
    assert result.chapman_kolmogorov_residual < 1e-6
    assert result.generator_residual < 1e-3


def test_fitted_price_is_sane():
    ev = _synthetic_evaluation_set()
    result = calibrate_chain_bates(ev, seed=3, n_quad=_N_QUAD, u_max=_U_MAX)
    strikes = np.array([0.8, 0.9, 1.0, 1.1, 1.2])
    expiries = np.full(5, 0.5)
    prices = result.price(strikes, expiries, n_quad=_N_QUAD, u_max=_U_MAX)
    assert np.all(prices >= -1e-8)
    assert np.all(prices <= 1.0 + 1e-6)


def test_empty_evaluation_set_raises_clearly():
    ev = EvaluationSet(ticker="EMPTY", d=date(2024, 1, 2), contracts=[], excluded=[])
    with pytest.raises(ChainBatesCalibrationError):
        calibrate_chain_bates(ev)


def test_contradictory_bid_ask_raises_clearly():
    bad_contract = EvaluationContract(expiry_years=0.5, target_tenor_years=0.5, target_moneyness=1.0, strike=1.0,
                                       bid=0.5, ask=0.3, dy2_model_mask=True, log_moneyness_error=0.0)
    ev = EvaluationSet(ticker="BAD", d=date(2024, 1, 2), contracts=[bad_contract], excluded=[])
    with pytest.raises(ChainBatesCalibrationError):
        calibrate_chain_bates(ev)
