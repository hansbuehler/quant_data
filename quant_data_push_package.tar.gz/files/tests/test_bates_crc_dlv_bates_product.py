"""Tests for quantdata.dysanos.bates_crc.dlv_bates_product: the coherent
latent DLV x extended-Bates product construction. Checks positivity, mass,
and the tower/forward-factorisation identity BEFORE any statistical fitting
would be attempted -- per the task's "verify positivity/tower/settlement
... before connecting to Wiese-Wissel" instruction."""

from __future__ import annotations

import numpy as np
import pytest

from datetime import date

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig, ContractSpec, run_comparison
from quantdata.dysanos.bates_crc.dlv_bates_product import DlvBatesCrcAdapter, DlvBatesProductModel
from quantdata.dysanos.bates_crc.bates_transform import FourierPricingConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.reserve_crc import JumpBox, ReserveSchedule, apply_reset, dominating_envelope_params, initial_state

HESTON = HestonParams(kappa=2.0, theta=0.040, xi=0.30, rho=-0.70)
BOX = JumpBox(Lambda=0.5, M=0.05, delta_min=0.08, delta_max=0.15, s_star=0.25)
SCHEDULE = ReserveSchedule(
    reset_times=(2 / 252, 7 / 252, 12 / 252), reserve_sizes=(0.006, 0.006, 0.006),
    theta_min=0.025, theta_max=0.055,
)
JUMPS_PATH = (
    GaussianJumpParams(lambda_J=0.20, m_J=-0.03, delta_J=0.10),
    GaussianJumpParams(lambda_J=0.35, m_J=-0.02, delta_J=0.12),
    GaussianJumpParams(lambda_J=0.15, m_J=0.01, delta_J=0.09),
    GaussianJumpParams(lambda_J=0.40, m_J=-0.04, delta_J=0.14),
)
DELTAS = (0.004, -0.007, 0.005)
V_0 = 0.04
CHAIN_CONFIG = ChainGeneratorConfig(anchors=(0.7, 0.85, 1.0, 1.15, 1.3), initial_index=2, kappa=8.0, sigma_y=0.0)


def _states():
    states = [initial_state(theta_0=0.040, jumps_0=JUMPS_PATH[0], schedule=SCHEDULE)]
    for k in range(3):
        new_state, _ = apply_reset(
            states[-1], proposed_delta_n=DELTAS[k], proposed_jumps_n=JUMPS_PATH[k + 1],
            box=BOX, schedule=SCHEDULE,
        )
        states.append(new_state)
    return states


def _model(state) -> DlvBatesProductModel:
    envelope = dominating_envelope_params(BOX)
    return DlvBatesProductModel(
        chain_config=CHAIN_CONFIG, heston=HESTON, state=state, schedule=SCHEDULE, envelope=envelope,
        V_t=V_0, fourier_config=FourierPricingConfig(n_quad=120, u_max=150.0), n_reserve_quad=80,
    )


def test_background_weights_are_a_probability_vector():
    model = _model(_states()[0])
    for T in (5 / 252, 10 / 252, 20 / 252):
        q = model.background_state_weights(0.0, T)
        assert np.all(q >= -1.0e-12)
        assert abs(q.sum() - 1.0) < 1.0e-10


def test_forward_price_tower_identity_holds_exactly():
    """E[S_T|F_t] = E[X_T|F_t]*E[Y_T|F_t] = S_t, checked at every one of the
    manuscript's four states and every model expiry -- the settlement
    identity required before trusting the mixture pricing formula."""
    x_i0 = CHAIN_CONFIG.anchors[CHAIN_CONFIG.initial_index]
    for state in _states():
        model = _model(state)
        for T in (5 / 252, 10 / 252, 15 / 252, 20 / 252):
            fwd = model.forward_price(0.0, T)
            assert abs(fwd - x_i0) < 1.0e-6, (T, fwd, x_i0)


def test_price_at_zero_maturity_is_intrinsic():
    model = _model(_states()[0])
    x_i0 = CHAIN_CONFIG.anchors[CHAIN_CONFIG.initial_index]
    for K in (0.8, 1.0, 1.2):
        assert model.price(0.3, 0.3, K) == pytest.approx(max(x_i0 - K, 0.0))


def test_price_is_nonnegative_and_monotone_decreasing_in_strike():
    model = _model(_states()[1])
    T = 20 / 252
    strikes = np.array([0.3, 0.5, 0.7, 0.85, 1.0, 1.15, 1.3, 2.0])
    prices = np.array([model.price(0.0, T, float(k)) for k in strikes])
    assert np.all(prices >= -1.0e-8)
    assert np.all(np.diff(prices) <= 1.0e-8)  # monotone non-increasing in strike


def test_deep_itm_price_matches_forward_minus_strike():
    """Deep ITM: P(S_T<K) is negligible, so C(K) ~= E[S_T]-K = fwd-K. Uses
    the FULL-precision Fourier config (not the fast/light test config),
    since deep-ITM Carr-Madan inversion needs a wider u-range to converge."""
    envelope = dominating_envelope_params(BOX)
    model = DlvBatesProductModel(
        chain_config=CHAIN_CONFIG, heston=HESTON, state=_states()[1], schedule=SCHEDULE, envelope=envelope,
        V_t=V_0, fourier_config=FourierPricingConfig(n_quad=400, u_max=250.0), n_reserve_quad=200,
    )
    T = 20 / 252
    K = 0.3
    price = model.price(0.0, T, K)
    fwd = model.forward_price(0.0, T)
    assert abs(price - (fwd - K)) < 5.0e-3


def test_dlv_bates_crc_adapter_satisfies_price_model_adapter_protocol():
    """DlvBatesCrcAdapter must plug into the prior task's comparison
    harness (run_comparison) exactly like any other adapter -- replacing
    the old NotImplementedAdapter stub for this model name."""
    model = _model(_states()[1])
    adapter = DlvBatesCrcAdapter(model)
    assert adapter.is_implemented()
    assert adapter.name == "coherent_dlv_x_extended_bates_crc"

    contracts = [ContractSpec(f"c{i}", "SYN", date(2024, 1, 1 + int(round(t * 365.25))), k)
                 for i, (t, k) in enumerate([(20 / 252, 0.9), (20 / 252, 1.0), (20 / 252, 1.1)])]
    rows = run_comparison(date(2024, 1, 1), contracts, [adapter])
    assert all(r.error is None for r in rows)
    prices = [r.price for r in rows]
    assert prices[0] > prices[1] > prices[2] > 0.0


def test_price_convex_in_strike():
    """No-arbitrage: C(K) must be convex in K. Checked on a strike mesh
    spanning the whole anchor range for a representative state/maturity."""
    model = _model(_states()[2])
    T = 20 / 252
    strikes = np.linspace(0.72, 1.28, 15)
    prices = np.array([model.price(0.0, T, float(k)) for k in strikes])
    second_diff = np.diff(prices, 2)
    assert np.all(second_diff >= -1.0e-6), second_diff
