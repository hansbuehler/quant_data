"""Tests for real_data_study.q_path_simulator -- the Monte Carlo baseline
used to give the held-out OCE/hedge test a model-implied null (not literal
zero), per the discrete-hedging-of-a-jump-diffusion objection."""

from __future__ import annotations

import numpy as np

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.chain_pricer import price_calls_chain_bates
from quantdata.dysanos.bates_crc.real_data_study.fast_bates_pricer import (
    price_calls_ordinary_bates,
    price_calls_ordinary_bates_batched_V,
)
from quantdata.dysanos.bates_crc.real_data_study.q_path_simulator import (
    mc_hedge_baseline,
    simulate_bates_terminal,
    simulate_chain_terminal_index,
    simulate_hedge_pnl_components,
    solve_oce_optimal_delta,
)

HESTON = HestonParams(kappa=4.0, theta=0.03, xi=0.7, rho=-0.85)
JUMPS = GaussianJumpParams(lambda_J=0.4, m_J=-0.15, delta_J=0.2)


def test_batched_V_pricer_matches_scalar_pricer_elementwise():
    tau = 0.25
    V_arr = np.array([0.02, 0.04, 0.08, 0.15])
    K_arr = np.array([0.9, 1.0, 1.05, 1.2])
    batched = price_calls_ordinary_bates_batched_V(HESTON, JUMPS, V_arr, K_arr, tau, n_quad=120, u_max=200.0)
    scalar = np.array([
        price_calls_ordinary_bates(HESTON, JUMPS, float(v), np.array([k]), np.array([tau]),
                                    n_quad=120, u_max=200.0)[0]
        for v, k in zip(V_arr, K_arr)
    ])
    assert np.max(np.abs(batched - scalar)) < 1e-10


def test_simulated_Y_is_an_exact_q_martingale():
    # E_Q[Y_T] = Y_0 = 1 exactly in continuous time, by the jump-compensator
    # construction shared with heston_riccati.py's characteristic function.
    # A fine-enough Euler discretisation of the diffusion part should
    # recover this to within a few Monte Carlo standard errors.
    rng = np.random.default_rng(0)
    for V0 in (0.02, 0.03, 0.08):
        V_T, logY_T = simulate_bates_terminal(rng, V0, HESTON, JUMPS, dt_years=5 / 252, n_paths=200_000,
                                               n_substeps=30)
        Y_T = np.exp(logY_T)
        se = Y_T.std() / np.sqrt(len(Y_T))
        assert abs(Y_T.mean() - 1.0) < 5 * se, (V0, Y_T.mean(), se)


def test_simulated_V_matches_analytic_cir_conditional_mean():
    rng = np.random.default_rng(1)
    V0, dt = 0.08, 5 / 252
    V_T, _ = simulate_bates_terminal(rng, V0, HESTON, JUMPS, dt_years=dt, n_paths=300_000, n_substeps=40)
    analytic_mean = V0 * np.exp(-HESTON.kappa * dt) + HESTON.theta * (1 - np.exp(-HESTON.kappa * dt))
    se = V_T.std() / np.sqrt(len(V_T))
    assert abs(V_T.mean() - analytic_mean) < 5 * se


def test_chain_terminal_index_distribution_matches_transition_row():
    chain_config = ChainGeneratorConfig(anchors=(0.8, 0.9, 1.0, 1.1, 1.2), initial_index=2, kappa=0.2, sigma_y=0.0)
    from quantdata.dysanos.bates_crc.comparison_interface import CoherentChainBlackAdapter
    q_true = CoherentChainBlackAdapter(chain_config).transition_matrix(5 / 252)[2, :]
    rng = np.random.default_rng(2)
    draws = simulate_chain_terminal_index(rng, chain_config, 5 / 252, n_paths=200_000)
    counts = np.bincount(draws, minlength=len(chain_config.anchors)) / len(draws)
    assert np.max(np.abs(counts - q_true)) < 0.01


def test_mc_hedge_baseline_runs_and_gives_a_finite_nonzero_sigma():
    anchors = (0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06)
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=3, kappa=0.18, sigma_y=0.0)
    V0, tau = 0.03, 1 / 12
    price0 = price_calls_chain_bates(chain_config, HESTON, JUMPS, V0, np.array([1.0]), np.array([tau]),
                                      n_quad=100, u_max=150.0)[0]
    p_up = price_calls_chain_bates(chain_config, HESTON, JUMPS, V0, np.array([1.0 / 1.01]), np.array([tau]),
                                    n_quad=100, u_max=150.0)[0]
    model_delta = (p_up - price0) / 0.01
    rng = np.random.default_rng(3)
    res = mc_hedge_baseline(rng, chain_config, HESTON, JUMPS, V0, price0, strike_pure=1.0, tau_orig=tau,
                             dt_years=5 / 252, model_delta=model_delta, n_paths=3000, n_substeps=20)
    assert res.n_paths == 3000
    assert np.isfinite(res.mu_q) and np.isfinite(res.sigma_q)
    assert res.sigma_q > 0.0


def test_mc_hedge_baseline_mu_q_shrinks_toward_zero_with_more_substeps_and_paths():
    # Not claiming mu_q=0 (that's exactly the point being tested against),
    # but it should be a small, stable number relative to sigma_q/sqrt(n) --
    # i.e. consistent with a well-defined discretisation bias, not numerical
    # garbage. Two independent seeds should roughly agree.
    anchors = (0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06)
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=3, kappa=0.18, sigma_y=0.0)
    V0, tau = 0.03, 1 / 12
    price0 = price_calls_chain_bates(chain_config, HESTON, JUMPS, V0, np.array([1.0]), np.array([tau]),
                                      n_quad=100, u_max=150.0)[0]
    model_delta = 0.5
    results = []
    for seed in (10, 11):
        rng = np.random.default_rng(seed)
        res = mc_hedge_baseline(rng, chain_config, HESTON, JUMPS, V0, price0, strike_pure=1.0, tau_orig=tau,
                                 dt_years=5 / 252, model_delta=model_delta, n_paths=8000, n_substeps=25)
        results.append(res)
    mu_diff = abs(results[0].mu_q - results[1].mu_q)
    pooled_se = np.sqrt(results[0].sigma_q ** 2 / results[0].n_paths + results[1].sigma_q ** 2 / results[1].n_paths)
    assert mu_diff < 6 * pooled_se


def test_solve_oce_optimal_delta_recovers_known_delta_under_symmetric_noise():
    # Gaussian (symmetric) noise independent of spot_move: the entropic-OCE
    # optimal hedge should land close to both the true linear coefficient
    # and the classical minimum-variance (OLS) hedge ratio.
    rng = np.random.default_rng(0)
    n = 20_000
    spot_move = rng.normal(0, 0.02, n)
    true_delta = 0.55
    option_pnl = true_delta * spot_move + rng.normal(0, 0.005, n)
    res = solve_oce_optimal_delta(option_pnl, spot_move, delta0=0.3)
    assert res.converged
    assert abs(res.gradient_at_star) < 1e-8
    cov = np.cov(option_pnl, spot_move)[0, 1]
    var = np.var(spot_move, ddof=1)
    ols_delta = cov / var
    assert abs(res.delta_star - true_delta) < 0.01
    assert abs(res.delta_star - ols_delta) < 0.01


def test_solve_oce_optimal_delta_converges_from_different_starting_points():
    rng = np.random.default_rng(1)
    n = 10_000
    spot_move = rng.normal(0, 0.015, n)
    option_pnl = 0.4 * spot_move + rng.normal(0, 0.004, n)
    results = [solve_oce_optimal_delta(option_pnl, spot_move, delta0=d0) for d0 in (-1.0, 0.0, 0.4, 2.0)]
    deltas = [r.delta_star for r in results]
    assert all(r.converged for r in results)
    assert max(deltas) - min(deltas) < 1e-6


def test_solve_oce_optimal_delta_gradient_at_model_delta_is_nonzero_when_suboptimal():
    rng = np.random.default_rng(2)
    n = 10_000
    spot_move = rng.normal(0, 0.02, n)
    option_pnl = 0.6 * spot_move + rng.normal(0, 0.003, n)
    res = solve_oce_optimal_delta(option_pnl, spot_move, delta0=0.1)  # 0.1 is far from optimal (~0.6)
    assert abs(res.gradient_at_delta0) > abs(res.gradient_at_star)
    assert abs(res.delta_star - 0.6) < 0.01


def test_simulate_hedge_pnl_components_matches_mc_hedge_baseline():
    # mc_hedge_baseline must be exactly reproducible from the same raw
    # components (same rng state consumption) -- the refactor must not
    # have changed the simulated distribution itself.
    anchors = (0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06)
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=3, kappa=0.18, sigma_y=0.0)
    V0, tau = 0.03, 1 / 12
    price0 = price_calls_chain_bates(chain_config, HESTON, JUMPS, V0, np.array([1.0]), np.array([tau]),
                                      n_quad=100, u_max=150.0)[0]
    model_delta = 0.5

    rng1 = np.random.default_rng(42)
    option_pnl, spot_move = simulate_hedge_pnl_components(rng1, chain_config, HESTON, JUMPS, V0, price0, 1.0, tau,
                                                            5 / 252, n_paths=2000, n_substeps=20)
    hedged = option_pnl - model_delta * spot_move

    rng2 = np.random.default_rng(42)
    baseline = mc_hedge_baseline(rng2, chain_config, HESTON, JUMPS, V0, price0, 1.0, tau, 5 / 252, model_delta,
                                  n_paths=2000, n_substeps=20)
    assert abs(float(np.mean(hedged)) - baseline.mu_q) < 1e-12
    assert abs(float(np.std(hedged, ddof=1)) - baseline.sigma_q) < 1e-12
