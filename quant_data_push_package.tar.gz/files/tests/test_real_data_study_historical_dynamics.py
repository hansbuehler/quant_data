"""Synthetic tests for real_data_study.historical_dynamics."""

from __future__ import annotations

import numpy as np

from quantdata.dysanos.bates_crc.real_data_study.historical_dynamics import (
    estimate_observation_noise,
    estimate_variance_risk_premium,
    extract_fixed_background,
    extract_series,
    fit_reset_proposal_law,
)


def _synthetic_rows(n=30, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    base_date_ordinal = 738000
    import datetime
    for i in range(n):
        d = (datetime.date.fromordinal(base_date_ordinal + i * 7)).isoformat()
        split = "train" if i < 20 else ("validation" if i < 25 else "held_out")
        rows.append(dict(
            date=d, split=split,
            dlv_bates=dict(
                heston=dict(kappa=2.0 + rng.normal(0, 0.1), theta=0.04 + 0.01 * np.sin(i / 5) + rng.normal(0, 0.003),
                            xi=0.3 + rng.normal(0, 0.02), rho=-0.6 + rng.normal(0, 0.05)),
                jumps=dict(lambda_J=0.2, m_J=-0.02, delta_J=0.08),
                V_t=0.04 + 0.01 * np.sin(i / 5) + rng.normal(0, 0.003),
                chain_kappa=8.0 + rng.normal(0, 1.0),
                anchors=[0.8, 0.9, 1.0, 1.1, 1.2],
                converged=True,
            ),
        ))
    return rows


def test_extract_fixed_background_is_robust_median():
    rows = _synthetic_rows()
    bg = extract_fixed_background(rows, split="train")
    assert 1.5 < bg.heston_kappa < 2.5
    assert bg.n_train_dates == 20


def test_extract_series_shapes_and_dt():
    rows = _synthetic_rows()
    series = extract_series(rows)
    assert len(series["theta"]) == len(rows)
    assert series["dt_years"][0] > 0
    assert np.all(series["dt_years"][1:] > 0)


def test_estimate_observation_noise_nonneg():
    rows = _synthetic_rows()
    series = extract_series(rows)
    train_mask = np.array([s == "train" for s in series["splits"]])
    noise = estimate_observation_noise(series["theta"], series["theta"], series["V"], series["V"], train_mask)
    assert noise.sigma_obs_theta == 0.0  # smoothed == raw here, zero residual
    assert noise.tau_obs_logV == 0.0


def test_estimate_variance_risk_premium_recovers_known_kappa():
    # construct an EXACT deterministic mean-reverting V path with known kappa_P
    kappa_true = 2.5
    theta_path = np.full(40, 0.04)
    dt = np.full(40, 1 / 52)
    V = np.zeros(40)
    V[0] = 0.08
    for t in range(1, 40):
        V[t] = V[t - 1] + kappa_true * (theta_path[t - 1] - V[t - 1]) * dt[t]
    est = estimate_variance_risk_premium(V, theta_path, dt, kappa_Q=3.0)
    assert abs(est.kappa_P - kappa_true) < 0.05
    assert abs(est.eta_V - (3.0 - kappa_true)) < 0.05


def test_fit_reset_proposal_law_on_known_jumps():
    theta = np.concatenate([np.full(10, 0.04), np.full(10, 0.05), np.full(10, 0.03)])
    law = fit_reset_proposal_law(theta, changepoint_indices=[10, 20])
    assert law.n_resets_used == 2
    assert abs(law.delta_values[0] - 0.01) < 1e-9
    assert abs(law.delta_values[1] - (-0.02)) < 1e-9


def test_fit_reset_proposal_law_handles_zero_resets():
    theta = np.full(10, 0.04)
    law = fit_reset_proposal_law(theta, changepoint_indices=[])
    assert law.n_resets_used == 0
