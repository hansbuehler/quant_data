"""Tests for real_data_study.dynamics_comparison."""

from __future__ import annotations

import numpy as np

from quantdata.dysanos.bates_crc.real_data_study.dynamics_comparison import (
    runtime_and_failure_rates,
    skew_and_term_structure,
    surface_pca,
    volatility_clustering,
)


def test_surface_pca_recovers_known_low_rank_structure():
    rng = np.random.default_rng(0)
    n_dates, n_contracts = 100, 20
    true_factor = rng.normal(0, 1, size=n_dates)
    loading = rng.normal(0, 1, size=n_contracts)
    price_matrix = 1.0 + np.outer(true_factor, loading) * 0.01 + rng.normal(0, 0.0005, size=(n_dates, n_contracts))
    pca = surface_pca(price_matrix, n_components=3)
    assert pca.explained_variance_ratio[0] > 0.8  # dominant single factor
    assert pca.n_components_95pct <= 2


def test_volatility_clustering_detects_known_garch_like_clustering():
    # Relative comparison (clustered vs iid), robust to a single synthetic
    # draw's variability, rather than an absolute p-value threshold.
    n = 2000
    rng_clustered = np.random.default_rng(1)
    vol = np.ones(n)
    for t in range(1, n):
        vol[t] = 0.9 * vol[t - 1] + 0.1 * abs(rng_clustered.normal())
    clustered_returns = vol * rng_clustered.normal(0, 1, size=n)
    clustered_report = volatility_clustering(clustered_returns, max_lag=10)

    rng_iid = np.random.default_rng(2)
    iid_returns = rng_iid.normal(0, 1, size=n)
    iid_report = volatility_clustering(iid_returns, max_lag=10)

    assert clustered_report.ljung_box_stat > iid_report.ljung_box_stat
    assert clustered_report.acf_abs_returns[0] > iid_report.acf_abs_returns[0]


def test_volatility_clustering_no_false_positive_on_iid_noise():
    rng = np.random.default_rng(2)
    returns = rng.normal(0, 1, size=500)
    report = volatility_clustering(returns, max_lag=10)
    assert abs(report.acf_abs_returns[0]) < 0.2


def test_skew_and_term_structure_basic_extraction():
    surf = {
        "2024-01-01": {(0.08, 0.9): 0.25, (0.08, 1.1): 0.18, (0.5, 0.9): 0.22, (0.5, 1.1): 0.19},
        "2024-01-08": {(0.08, 0.9): 0.27, (0.08, 1.1): 0.17, (0.5, 0.9): 0.21, (0.5, 1.1): 0.20},
    }
    report = skew_and_term_structure(surf)
    assert len(report.dates) == 2
    assert report.skew_25delta_proxy[0] > 0  # put side (low moneyness) higher IV than call side


def test_runtime_and_failure_rates():
    rows = [
        dict(date="2024-01-01", wall_clock_seconds=10.0, dlv_bates=dict(converged=True)),
        dict(date="2024-01-08", wall_clock_seconds=15.0, dlv_bates=dict(converged=True)),
        dict(date="2024-01-15", wall_clock_seconds=5.0, dlv_bates_error="failed"),
    ]
    report = runtime_and_failure_rates(rows)
    assert report.n_dates == 3
    assert report.n_converged == 2
    assert report.n_failed == 1
    assert abs(report.failure_rate - 1 / 3) < 1e-9
