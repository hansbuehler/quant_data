"""Tests for quantdata.dysanos.bates_crc.real_data_study.chain_black_calibration."""

from __future__ import annotations

from datetime import date

import numpy as np
import pytest

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.real_data_study import config as cfg
from quantdata.dysanos.bates_crc.real_data_study.chain_black_calibration import (
    ChainBlackCalibrationError,
    calibrate_chain_black,
)
from quantdata.dysanos.bates_crc.real_data_study.chain_pricer import price_calls_chain_black
from quantdata.dysanos.bates_crc.real_data_study.day_loader import EvaluationContract, EvaluationSet

TRUE_KAPPA = 12.0
TRUE_SIGMA_Y = 0.22


def _synthetic_evaluation_set(spread: float = 0.0008) -> EvaluationSet:
    anchors, i0 = cfg.build_anchors(cfg.N_ANCHORS)
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=i0, kappa=TRUE_KAPPA, sigma_y=TRUE_SIGMA_Y)
    tenors = [1 / 12, 3 / 12, 0.5, 1.0]
    moneyness = [0.9, 0.95, 1.0, 1.05, 1.1]
    strikes = np.array([m for t in tenors for m in moneyness])
    expiries = np.array([t for t in tenors for _ in moneyness])
    mid = price_calls_chain_black(chain_config, TRUE_SIGMA_Y, strikes, expiries)

    contracts = [
        EvaluationContract(expiry_years=float(t), target_tenor_years=float(t), target_moneyness=float(k),
                            strike=float(k), bid=float(p - spread), ask=float(p + spread), dy2_model_mask=True,
                            log_moneyness_error=0.0)
        for t, k, p in zip(expiries, strikes, mid, strict=True)
    ]
    return EvaluationSet(ticker="SYNTH", d=date(2024, 1, 2), contracts=contracts, excluded=[])


def test_synthetic_recovery_converges_and_recovers_true_parameters():
    ev = _synthetic_evaluation_set()
    result = calibrate_chain_black(ev, seed=1)
    assert result.converged
    assert result.final_cost < 1.0
    assert abs(result.chain_config.kappa - TRUE_KAPPA) / TRUE_KAPPA < 0.20
    assert abs(result.sigma_Y - TRUE_SIGMA_Y) / TRUE_SIGMA_Y < 0.20


def test_martingale_verification_fields_populated_and_tiny():
    ev = _synthetic_evaluation_set()
    result = calibrate_chain_black(ev, seed=2)
    assert result.chapman_kolmogorov_residual < 1e-6
    assert result.generator_residual < 1e-3


def test_fitted_price_is_sane():
    ev = _synthetic_evaluation_set()
    result = calibrate_chain_black(ev, seed=3)
    strikes = np.array([0.8, 0.9, 1.0, 1.1, 1.2])
    expiries = np.full(5, 0.5)
    prices = result.price(strikes, expiries)
    assert np.all(prices >= -1e-10)
    assert np.all(prices <= 1.0 + 1e-8)
    assert np.all(np.diff(prices) <= 1e-10)


def test_empty_evaluation_set_raises_clearly():
    ev = EvaluationSet(ticker="EMPTY", d=date(2024, 1, 2), contracts=[], excluded=[])
    with pytest.raises(ChainBlackCalibrationError):
        calibrate_chain_black(ev)


def test_contradictory_bid_ask_raises_clearly():
    bad_contract = EvaluationContract(expiry_years=0.5, target_tenor_years=0.5, target_moneyness=1.0, strike=1.0,
                                       bid=0.5, ask=0.3, dy2_model_mask=True, log_moneyness_error=0.0)
    ev = EvaluationSet(ticker="BAD", d=date(2024, 1, 2), contracts=[bad_contract], excluded=[])
    with pytest.raises(ChainBlackCalibrationError):
        calibrate_chain_black(ev)
