"""Cross-checks quantdata.dysanos.bates_crc.real_data_study.fast_bates_pricer
against the already-verified, slower bates_transform machinery from the
prior task -- this module is a speed optimisation, not a new model, so its
outputs must agree to near machine precision."""

from __future__ import annotations

import numpy as np

from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.reserve_crc import (
    BcrcState,
    JumpBox,
    ReserveSchedule,
    apply_reset,
    dominating_envelope_params,
    initial_state,
)
from quantdata.dysanos.bates_crc.bates_transform import FourierPricingConfig, fourier_call_price
from quantdata.dysanos.bates_crc.real_data_study.fast_bates_pricer import (
    price_calls_extended_bates,
    price_calls_ordinary_bates,
)

HESTON = HestonParams(kappa=2.0, theta=0.040, xi=0.30, rho=-0.70)
JUMPS = GaussianJumpParams(lambda_J=0.25, m_J=-0.02, delta_J=0.11)
V_0 = 0.045


def test_ordinary_bates_matches_bates_transform_uncompensated_style():
    """Ordinary Bates (no reserve) must match fourier_call_price computed
    with a degenerate schedule whose envelope equals the current jump
    params (forces the reserve term to vanish, per AUDIT.md Sec. 8's
    cancellation identity) -- an independent route to the same number."""
    box = JumpBox(Lambda=0.01, M=0.001, delta_min=JUMPS.delta_J - 1e-6, delta_max=JUMPS.delta_J, s_star=JUMPS.delta_J + 0.001)
    schedule = ReserveSchedule(reset_times=(100.0,), reserve_sizes=(1e-9,), theta_min=0.0, theta_max=1.0)
    state = initial_state(theta_0=0.040, jumps_0=JUMPS, schedule=schedule)
    envelope = JUMPS  # degenerate: envelope == current jumps forces l_s(u) reserve-sum term only

    strikes = np.array([0.85, 0.95, 1.0, 1.05, 1.15])
    expiries = np.array([0.1] * len(strikes))
    fast = price_calls_ordinary_bates(HESTON, JUMPS, V_0, strikes, expiries, n_quad=400, u_max=300.0)

    config = FourierPricingConfig(n_quad=400, u_max=300.0)
    slow = np.array([
        fourier_call_price(k, 0.0, 0.1, V_0, HESTON, state, schedule, envelope, config, n_reserve_quad=300)
        for k in strikes
    ])
    np.testing.assert_allclose(fast, slow, atol=2e-6)


def test_extended_bates_matches_bates_transform_continuation_transform():
    box = JumpBox(Lambda=0.5, M=0.05, delta_min=0.08, delta_max=0.15, s_star=0.25)
    schedule = ReserveSchedule(reset_times=(2 / 252, 7 / 252, 12 / 252), reserve_sizes=(0.006, 0.006, 0.006),
                                theta_min=0.025, theta_max=0.055)
    jumps_path = (
        GaussianJumpParams(lambda_J=0.20, m_J=-0.03, delta_J=0.10),
        GaussianJumpParams(lambda_J=0.35, m_J=-0.02, delta_J=0.12),
    )
    state = initial_state(theta_0=0.040, jumps_0=jumps_path[0], schedule=schedule)
    state, _ = apply_reset(state, proposed_delta_n=0.004, proposed_jumps_n=jumps_path[1], box=box, schedule=schedule)
    envelope = dominating_envelope_params(box)
    heston = HestonParams(kappa=2.0, theta=0.040, xi=0.30, rho=-0.70)

    strikes = np.array([0.9, 1.0, 1.1])
    T = 20 / 252
    expiries = np.full_like(strikes, T)
    fast = price_calls_extended_bates(heston, jumps_path[-1], envelope, 0.04, strikes, expiries,
                                       schedule.reset_times, state.b_used, t=0.0, n_quad=400, u_max=300.0,
                                       n_reserve_quad=300)

    config = FourierPricingConfig(n_quad=400, u_max=300.0)
    slow = np.array([
        fourier_call_price(k, 0.0, T, 0.04, heston, state, schedule, envelope, config, n_reserve_quad=300)
        for k in strikes
    ])
    np.testing.assert_allclose(fast, slow, atol=2e-6)
