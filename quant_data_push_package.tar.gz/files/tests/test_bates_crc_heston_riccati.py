"""Tests for quantdata.dysanos.bates_crc.heston_riccati."""

from __future__ import annotations

import numpy as np
import pytest

from quantdata.dysanos.bates_crc.heston_riccati import (
    GaussianJumpParams,
    HestonParams,
    gaussian_bates_jump_exponent,
    moment_explosion_time,
    moment_strip_report,
    riccati_A_closed_form,
    riccati_D_closed_form,
    riccati_D_ode_integration,
)

TASK_HESTON = HestonParams(kappa=2.0, theta=0.040, xi=0.30, rho=-0.70)


def test_riccati_D_zero_at_tau_zero():
    for u in (0.3, 1.0 - 1.0j, -2.0 + 0.5j):
        assert riccati_D_closed_form(u, 0.0, TASK_HESTON) == 0.0


def test_closed_form_matches_independent_ode_integration():
    for u in (0.5, 1.0 - 1.0j, 2.3 + 0.1j, 5.0):
        for tau in (0.01, 5 / 252, 20 / 252):
            closed = riccati_D_closed_form(u, tau, TASK_HESTON)
            ode = riccati_D_ode_integration(complex(u), tau, TASK_HESTON, n_steps=5000)
            assert abs(closed - ode) < 1.0e-10, (u, tau, closed, ode)


def test_martingale_normalisation_D_and_A_vanish_at_minus_i():
    for tau in (0.001, 5 / 252, 20 / 252, 1.0, 5.0):
        assert abs(riccati_D_closed_form(-1j, tau, TASK_HESTON)) < 1.0e-13
        assert abs(riccati_A_closed_form(-1j, tau, TASK_HESTON)) < 1.0e-13


def test_moment_explosion_time_matches_prior_verified_value():
    reference = HestonParams(kappa=2.0, theta=0.04, xi=0.35, rho=-0.7)
    assert abs(moment_explosion_time(100.0, reference) - 0.21559324) < 1.0e-6


def test_moment_strip_report_shrinks_with_maturity():
    short = moment_strip_report(TASK_HESTON, tau=5 / 252, p_max=200.0, n_grid=400)
    long = moment_strip_report(TASK_HESTON, tau=1.0, p_max=200.0, n_grid=400)
    assert short["largest_finite_moment_order"] > long["largest_finite_moment_order"]


def test_gaussian_jump_exponent_martingale_normalisation():
    jumps = GaussianJumpParams(lambda_J=0.20, m_J=-0.03, delta_J=0.10)
    assert abs(gaussian_bates_jump_exponent(0.0, jumps)) < 1.0e-13
    assert abs(gaussian_bates_jump_exponent(-1j, jumps)) < 1.0e-13


def test_gaussian_jump_exponent_matches_direct_expectation_integral():
    """Independent cross-check: j_p(u) should equal
    lambda*(E[e^{iuZ}] - 1 - iu*E[e^Z - 1]) computed by direct Gauss-Hermite
    quadrature over the Gaussian jump-size law, not just algebraic identity
    with itself."""
    jumps = GaussianJumpParams(lambda_J=0.20, m_J=-0.03, delta_J=0.10)
    nodes, weights = np.polynomial.hermite.hermgauss(80)
    z = jumps.m_J + jumps.delta_J * np.sqrt(2.0) * nodes
    quad_weight = weights / np.sqrt(np.pi)
    kappa_J = np.exp(jumps.m_J + 0.5 * jumps.delta_J ** 2) - 1.0
    for u in (0.5, 2.0, -1.3):
        direct = jumps.lambda_J * (
            np.sum(quad_weight * np.exp(1j * u * z)) - 1.0 - 1j * u * kappa_J
        )
        formula = gaussian_bates_jump_exponent(u, jumps)
        assert abs(direct - formula) < 1.0e-9, (u, direct, formula)


def test_invalid_parameters_raise():
    with pytest.raises(ValueError):
        HestonParams(kappa=-1.0, theta=0.04, xi=0.3, rho=-0.7)
    with pytest.raises(ValueError):
        HestonParams(kappa=2.0, theta=0.04, xi=0.3, rho=1.5)
    with pytest.raises(ValueError):
        GaussianJumpParams(lambda_J=-0.1, m_J=0.0, delta_J=0.1)
