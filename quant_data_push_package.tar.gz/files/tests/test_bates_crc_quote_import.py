"""Tests for quantdata.dysanos.bates_crc.quote_import -- synthetic,
explicitly-labelled fixtures only (no real data is available in this
environment, see DATA_STATUS.md)."""

from __future__ import annotations

import pandas as pd
import pytest

from quantdata.dysanos.bates_crc.quote_import import import_quotes


def _synthetic_table(carry="discount_factor_forward") -> pd.DataFrame:
    base = dict(
        underlying=["SYN", "SYN", "SYN", "SYN"],
        valuation_date=["2024-01-02"] * 4,
        expiry=["2024-02-02", "2024-02-02", "2024-02-02", "2024-01-02"],
        strike=[95.0, 100.0, 105.0, 100.0],
        is_call=[True, True, True, True],
        bid=[6.0, 3.0, 1.0, 2.0],
        ask=[6.5, 3.5, 1.5, 2.0],  # last row: zero spread, should be dropped
    )
    if carry == "discount_factor_forward":
        base["discount_factor"] = [0.99, 0.99, 0.99, 1.0]
        base["forward"] = [101.0, 101.0, 101.0, 100.0]
    else:
        base["zero_rate"] = [0.04, 0.04, 0.04, 0.04]
        base["dividend_yield"] = [0.01, 0.01, 0.01, 0.01]
        base["spot"] = [100.0, 100.0, 100.0, 100.0]
    return pd.DataFrame(base)


def test_missing_required_column_raises_with_exact_name():
    df = _synthetic_table().drop(columns=["bid"])
    with pytest.raises(ValueError, match="bid"):
        import_quotes(df)


def test_missing_carry_information_raises():
    df = _synthetic_table().drop(columns=["discount_factor", "forward"])
    with pytest.raises(ValueError, match="carry"):
        import_quotes(df)


def test_import_with_explicit_discount_and_forward():
    df = _synthetic_table(carry="discount_factor_forward")
    out, report = import_quotes(df)
    assert report.n_input_rows == 4
    assert report.dropped_non_positive_spread == 1  # the zero-spread row
    assert report.n_output_rows == 3
    assert report.carry_source == "discount_factor+forward"
    assert (out["pure_ask_price"] > out["pure_bid_price"]).all()
    assert (out["tte_y"] > 0.0).all()


def test_import_with_zero_rate_dividend_yield_spot():
    df = _synthetic_table(carry="zero_rate_dividend_spot")
    out, report = import_quotes(df)
    assert report.carry_source == "zero_rate+dividend_yield+spot"
    assert report.n_output_rows == 3
    assert (out["forward"] > 0.0).all()
    assert (out["discount_factor"] > 0.0).all() and (out["discount_factor"] <= 1.0).all()


def test_missing_bid_values_are_dropped_and_reported():
    df = _synthetic_table()
    df.loc[0, "bid"] = None
    out, report = import_quotes(df)
    assert report.dropped_missing_bid_ask == 1
    assert len(out) == report.n_output_rows


def test_ticker_filter_selects_subset():
    df = _synthetic_table()
    df2 = df.copy()
    df2["underlying"] = "OTHER"
    combined = pd.concat([df, df2], ignore_index=True)
    out, report = import_quotes(combined, ticker_filter="SYN")
    assert (out["underlying"] == "SYN").all()
    assert report.n_output_rows == 3
