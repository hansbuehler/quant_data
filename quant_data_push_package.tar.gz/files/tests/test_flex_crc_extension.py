"""Tests for quantdata.dysanos.flex.crc_extension (Sections 2, 3, 5 of the
CRC-inspired DYSANOS FLEX extension). Synthetic-but-structurally-valid data
throughout -- see crc_extension/PHASE1_AUDIT.md for why."""

from __future__ import annotations

import torch

from quantdata.dysanos.flex.crc_extension.section2_pricing_identity import (
    BaseEnvironment,
    build_simulator,
    drift_feasibility_analysis,
    martingale_test,
    train_target_measure_kernel,
)
from quantdata.dysanos.flex.crc_extension.section5_crc_sequence import (
    constrained_inverse,
    run_crc_sequence,
)


def _env() -> BaseEnvironment:
    return BaseEnvironment(precision=64, device="cpu", debug=True)


# ---------------------------------------------------------------------
# Section 2: the discrete-time pricing identity.
# ---------------------------------------------------------------------

def test_raw_p_law_fails_martingality_with_high_power() -> None:
    """The unconstrained AR(1) is tested, not assumed, to violate the
    discrete pricing identity -- with enough paths to have real power."""
    sim = build_simulator(_env())
    result = martingale_test(sim, label="p", num_paths=100_000, seed=17)
    assert result.max_abs_t_stat > 5.0, (
        "expected a well-powered, statistically decisive rejection of "
        f"martingality for the raw P law, got t={result.max_abs_t_stat}"
    )


def test_martingale_test_is_reproducible_given_a_seed() -> None:
    sim = build_simulator(_env())
    r1 = martingale_test(sim, label="p", num_paths=5_000, seed=99)
    r2 = martingale_test(sim, label="p", num_paths=5_000, seed=99)
    assert r1.mean_abs_residual_by_expiry == r2.mean_abs_residual_by_expiry


def test_trained_target_kernel_changes_the_residual() -> None:
    """Training must actually move the kernel away from raw P (it is not a
    no-op); whether it reaches zero is a separate, harder question tested
    by the feasibility analysis below."""
    sim = build_simulator(_env())
    p_result = martingale_test(sim, label="p", num_paths=20_000, seed=5)
    kernel = train_target_measure_kernel(sim, epochs=80, paths_per_epoch=128, seed=5)
    q_result = martingale_test(sim, label="q", num_paths=20_000, seed=5, measure_kernel=kernel)
    assert q_result.mean_abs_residual_by_expiry != p_result.mean_abs_residual_by_expiry


# ---------------------------------------------------------------------
# Section 3: drift feasibility -- rank, conditioning, residual.
# ---------------------------------------------------------------------

def test_drift_feasibility_reports_a_well_formed_rank_and_residual() -> None:
    sim = build_simulator(_env())
    report = drift_feasibility_analysis(sim, num_paths=8_000, seed=3)
    assert 0 <= report.jacobian_rank <= report.mu_dim
    assert report.residual_dim == 3 * 5  # 3 model expiries x 5 test strikes
    assert 0.0 <= report.reduction_fraction <= 1.0 + 1.0e-6
    assert report.r0_norm > 0.0


def test_drift_feasibility_does_not_silently_claim_full_reduction() -> None:
    """A regression guard against silently loosening the reported
    conclusion: an additive mean-shift is not claimed to fully cancel the
    residual (matches the documented ~69% finding's qualitative shape:
    strictly between 0 and 1, not at either boundary)."""
    sim = build_simulator(_env())
    report = drift_feasibility_analysis(sim, num_paths=8_000, seed=3)
    assert 0.05 < report.reduction_fraction < 0.999


# ---------------------------------------------------------------------
# Section 5: the CRC recalibration sequence.
# ---------------------------------------------------------------------

def test_constrained_inverse_converges_to_a_reachable_target() -> None:
    sim = build_simulator(_env())
    state_dim = sim.dynamics.reduced_state_size
    torch.manual_seed(0)
    true_state = 0.2 * torch.randn(state_dim, dtype=torch.float64)
    spot = torch.tensor(1.0, dtype=torch.float64)
    from quantdata.dysanos.flex.crc_extension.section5_crc_sequence import _target_prices
    target = _target_prices(sim, true_state, spot).detach()
    proposal = 0.2 * torch.randn(state_dim, dtype=torch.float64)
    _, fit = constrained_inverse(sim, proposal_state=proposal, target_prices=target, spot=spot)
    assert fit.converged
    assert fit.post_correction_max_abs_error < fit.tolerance
    assert fit.min_decoded_density > 0.0


def test_constrained_inverse_reports_genuine_infeasibility() -> None:
    """The feasibility decision (F) must not be vacuous: an implausible
    target with a tight tolerance and few iterations must be reported as
    NOT converged, not silently accepted."""
    sim = build_simulator(_env())
    state_dim = sim.dynamics.reduced_state_size
    torch.manual_seed(1)
    proposal = 0.3 * torch.randn(state_dim, dtype=torch.float64)
    implausible_target = torch.rand(15, dtype=torch.float64) * 3.0
    spot = torch.tensor(1.0, dtype=torch.float64)
    _, fit = constrained_inverse(
        sim, proposal_state=proposal, target_prices=implausible_target, spot=spot,
        tolerance=1.0e-8, max_iterations=20,
    )
    assert not fit.converged


def test_crc_sequence_maintains_static_admissibility_throughout() -> None:
    result = run_crc_sequence(num_resets=3, seed=2024)
    for step in result["steps"]:
        assert step["feasibility"]["min_decoded_density"] > 0.0
        assert step["feasibility"]["converged"]


def test_crc_sequence_price_preserving_move_is_smaller_than_initial_calibration() -> None:
    """The reset's own correction step should generally move the raw state
    far less than the initial (uncalibrated) fit did, since the P-law
    proposal already tracks the oracle -- a genuine distinguishing check
    between representation-correction and full re-calibration."""
    result = run_crc_sequence(num_resets=3, seed=2024)
    initial_move = result["steps"][0]["feasibility"]["raw_state_move_l2"]
    later_moves = [s["feasibility"]["raw_state_move_l2"] for s in result["steps"][1:]]
    assert all(move < initial_move for move in later_moves)
