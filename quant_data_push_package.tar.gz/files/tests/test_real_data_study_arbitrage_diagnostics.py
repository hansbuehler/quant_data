"""Tests for real_data_study.arbitrage_diagnostics."""

from __future__ import annotations

import numpy as np

from quantdata.dysanos.bates_crc.heston_riccati import HestonParams
from quantdata.dysanos.bates_crc.real_data_study.arbitrage_diagnostics import (
    delta_hedge_challenger_test,
    pool_zscores_by_date,
    verify_structural_identities,
)


def test_verify_structural_identities_holds_for_arbitrary_fitted_params():
    heston = HestonParams(kappa=2.3, theta=0.045, xi=0.28, rho=-0.55)
    report = verify_structural_identities("2024-01-01", heston, tau=0.3)
    assert report.ok
    assert report.D_minus_i_abs < 1e-10
    assert report.A_minus_i_abs < 1e-10


def test_delta_hedge_challenger_zero_mean_when_perfectly_hedged():
    rng = np.random.default_rng(0)
    spot_moves = rng.normal(0, 0.01, size=200)
    deltas = np.full(200, 0.5)
    option_pnl = deltas * spot_moves  # perfectly replicated by the hedge
    report = delta_hedge_challenger_test(spot_moves, deltas, option_pnl)
    assert abs(report.mean_hedged_pnl) < 1e-12
    assert report.n_steps == 200


def test_delta_hedge_challenger_detects_nonzero_mean_with_reasonable_power():
    rng = np.random.default_rng(1)
    n = 500
    spot_moves = rng.normal(0, 0.01, size=n)
    deltas = np.full(n, 0.5)
    bias = 0.002
    option_pnl = deltas * spot_moves + bias + rng.normal(0, 0.001, size=n)
    report = delta_hedge_challenger_test(spot_moves, deltas, option_pnl)
    assert abs(report.mean_hedged_pnl - bias) < 0.001
    assert abs(report.t_stat_newey_west) > 2.0  # clearly detectable at this sample size
    assert "risk premium" in report.note


def test_sign_test_exact_pvalue_tiny_for_a_lopsided_small_sample():
    # n=20, 18 negative / 2 positive -- small sample, but the sign test is
    # EXACT (binomial), so it should still reject decisively without
    # relying on any normal/CLT approximation.
    rng = np.random.default_rng(2)
    hedged = np.concatenate([-np.abs(rng.normal(0.01, 0.002, size=18)),
                              np.abs(rng.normal(0.01, 0.002, size=2))])
    spot_moves = np.zeros(20)
    deltas = np.zeros(20)
    report = delta_hedge_challenger_test(spot_moves, deltas, hedged)
    assert report.n_pos == 2 and report.n_neg == 18
    assert report.sign_test_pvalue < 0.01


def test_sign_test_not_significant_for_a_balanced_sample():
    rng = np.random.default_rng(3)
    hedged = np.concatenate([-np.abs(rng.normal(0.01, 0.002, size=16)),
                              np.abs(rng.normal(0.01, 0.002, size=16))])
    report = delta_hedge_challenger_test(np.zeros(32), np.zeros(32), hedged)
    assert report.n_pos == 16 and report.n_neg == 16
    assert report.sign_test_pvalue > 0.5


def test_runs_test_flags_a_clustered_sign_sequence_as_nonrandom():
    # Two contiguous blocks (all-negative then all-positive): only 2 runs,
    # far fewer than a random ordering of 16/16 would produce -- the runs
    # test should flag this as significantly non-random.
    hedged = np.concatenate([-np.ones(16), np.ones(16)])
    report = delta_hedge_challenger_test(np.zeros(32), np.zeros(32), hedged)
    assert report.runs_test_pvalue < 0.01


def test_runs_test_flags_a_perfectly_alternating_sequence_as_nonrandom():
    # Too MANY runs is just as non-random as too few.
    hedged = np.tile([-1.0, 1.0], 16)
    report = delta_hedge_challenger_test(np.zeros(32), np.zeros(32), hedged)
    assert report.runs_test_pvalue < 0.01


def test_runs_test_not_significant_for_a_shuffled_sequence():
    rng = np.random.default_rng(4)
    signs = np.array([-1.0] * 16 + [1.0] * 16)
    rng.shuffle(signs)
    report = delta_hedge_challenger_test(np.zeros(32), np.zeros(32), signs)
    assert report.runs_test_pvalue > 0.05


def test_pool_zscores_by_date_ignores_within_date_clustering_in_the_primary_stat():
    # 20 dates, 6 near-identical contracts each (heavily correlated within a
    # date by construction): a naive contract-level pooling would see n=120
    # and a tiny se; the date-clustered stat should instead reflect the true
    # n=20 worth of independent information.
    rng = np.random.default_rng(5)
    z_by_date = {}
    for d in range(20):
        base = rng.normal(0.3, 1.0)  # one shared draw per date
        z_by_date[f"2025-{d:02d}"] = (base + rng.normal(0, 0.05, size=6)).tolist()
    report = pool_zscores_by_date(z_by_date)
    assert report.n_contract_weeks == 120
    assert report.n_dates == 20
    # naive (wrong) contract-level t-stat is inflated far beyond what n=20 independent draws would give
    assert abs(report.t_stat_naive_contract_level) > abs(report.t_stat_newey_west_by_date)


def test_pool_zscores_by_date_detects_a_genuine_across_date_bias():
    rng = np.random.default_rng(6)
    z_by_date = {f"2025-{d:02d}": (0.8 + rng.normal(0, 1.0, size=6)).tolist() for d in range(40)}
    report = pool_zscores_by_date(z_by_date)
    assert abs(report.t_stat_newey_west_by_date) > 2.0
    assert report.sign_test_pvalue_by_date < 0.05
