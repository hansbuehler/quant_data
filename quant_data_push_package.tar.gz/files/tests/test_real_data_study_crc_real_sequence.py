"""Synthetic tests for real_data_study.crc_real_sequence's admissibility
logic -- does not require real market data."""

from __future__ import annotations

from datetime import date

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.crc_real_sequence import (
    DatedBackground,
    evaluate_transition,
    evaluate_transition_forced_admissible,
)


def _bg(d: date, theta: float, jumps: GaussianJumpParams) -> DatedBackground:
    anchors = (0.9, 1.0, 1.1)
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=1, kappa=10.0, sigma_y=0.0)
    heston = HestonParams(kappa=2.0, theta=theta, xi=0.3, rho=-0.6)
    return DatedBackground(d=d, heston=heston, jumps=jumps, chain_config=chain_config, V_t=0.04)


JUMPS = GaussianJumpParams(lambda_J=0.2, m_J=-0.02, delta_J=0.08)
JUMPS_CLOSE = GaussianJumpParams(lambda_J=0.22, m_J=-0.025, delta_J=0.085)
JUMPS_EXTREME = GaussianJumpParams(lambda_J=4.0, m_J=-0.4, delta_J=0.08)


def test_small_theta_move_with_similar_jumps_is_admissible():
    prev = _bg(date(2020, 1, 1), 0.04, JUMPS)
    nxt = _bg(date(2020, 2, 1), 0.045, JUMPS_CLOSE)  # delta_theta=+0.005, well inside +/-0.03 band
    result = evaluate_transition(prev, nxt)
    assert result["band_ok"]
    assert result["jumps_in_box"]
    assert result["admissible"]
    assert result["apply_reset_diagnostics"]["projected"] is False


def test_large_theta_move_is_inadmissible_regardless_of_reserve():
    prev = _bg(date(2020, 1, 1), 0.04, JUMPS)
    nxt = _bg(date(2020, 2, 1), 0.20, JUMPS_CLOSE)  # delta_theta=+0.16, far outside band
    result = evaluate_transition(prev, nxt)
    assert not result["band_ok"]
    assert not result["admissible"]
    assert "exceeds the declared" in result["reason"]


def test_extreme_jump_params_are_inadmissible_even_with_small_theta_move():
    prev = _bg(date(2020, 1, 1), 0.04, JUMPS)
    nxt = _bg(date(2020, 2, 1), 0.045, JUMPS_EXTREME)
    result = evaluate_transition(prev, nxt)
    assert result["band_ok"]
    assert not result["jumps_in_box"]
    assert not result["admissible"]


def test_forced_admissible_pass_always_achieves_containment_and_projection_free():
    prev = _bg(date(2020, 1, 1), 0.04, JUMPS)
    nxt = _bg(date(2020, 2, 1), 0.20, JUMPS_EXTREME)  # both checks would fail in the standard pass
    result = evaluate_transition_forced_admissible(prev, nxt)
    assert result["projection_free"] is True
    assert result["theta_band_widening_vs_standard"] > 1.0
    assert result["jump_box_widen_factor_required"] >= 1.5


def test_forced_admissible_pass_preserves_protected_option_prices_exactly():
    from quantdata.dysanos.bates_crc.real_data_study.day_loader import EvaluationContract

    prev = _bg(date(2020, 1, 1), 0.04, JUMPS)
    nxt = _bg(date(2020, 4, 1), 0.06, JUMPS_CLOSE)
    gap_years = (nxt.d - prev.d).days / 365.25
    protected = EvaluationContract(expiry_years=gap_years * 0.3, target_tenor_years=gap_years * 0.3,
                                    target_moneyness=1.0, strike=1.0, bid=0.0, ask=1.0, dy2_model_mask=True,
                                    log_moneyness_error=0.0)
    result = evaluate_transition_forced_admissible(prev, nxt, eval_contracts=[protected])
    check = result["protected_option_check"]
    assert check["n_protected_contracts"] == 1
    assert "numerical_failure" not in check
    assert check["max_abs_price_diff"] < 1e-8
