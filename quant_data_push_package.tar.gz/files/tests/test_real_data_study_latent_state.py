"""Synthetic recovery tests for real_data_study.latent_state -- validates
the TV-denoising and particle-filter MACHINERY against known ground truth.
Per the task's explicit instruction, this is a methodology check only and
must never be cited as empirical validation of the real-data results."""

from __future__ import annotations

import numpy as np

from quantdata.dysanos.bates_crc.real_data_study.latent_state import (
    choose_tv_lambda_by_cv,
    cir_exact_sample,
    detect_changepoints,
    particle_filter_V,
    tv_denoise,
)


def test_tv_denoise_recovers_known_piecewise_constant_path():
    rng = np.random.default_rng(0)
    true_theta = np.concatenate([np.full(20, 0.04), np.full(15, 0.055), np.full(15, 0.03)])
    noisy = true_theta + rng.normal(0, 0.004, size=len(true_theta))
    smoothed = tv_denoise(noisy, lam=0.03)
    assert np.max(np.abs(smoothed - true_theta)) < 0.01
    # much smoother than the raw noisy series
    assert np.sum(np.abs(np.diff(smoothed))) < np.sum(np.abs(np.diff(noisy)))


def test_tv_denoise_respects_zero_weight_mask():
    rng = np.random.default_rng(6)
    y = np.concatenate([np.full(15, 0.04), np.full(15, 0.06)]) + rng.normal(0, 0.002, size=30)
    weights = np.ones(30)
    weights[14:16] = 0.0  # mask out the two points straddling the true jump
    smoothed = tv_denoise(y, lam=0.01, weights=weights)
    # masked points must still get a (interpolated) value, not be dropped
    assert smoothed.shape == (30,)
    assert np.isfinite(smoothed[14]) and np.isfinite(smoothed[15])


def test_choose_tv_lambda_by_cv_is_leakage_free_and_well_behaved():
    # Construct a path with genuine structure (a few jumps) + noise; CV
    # should pick an INTERIOR lambda (not the smallest in the grid), proving
    # it isn't just rewarding minimal smoothing (the bug this replaced).
    rng = np.random.default_rng(7)
    true_path = np.concatenate([np.full(30, 0.04), np.full(30, 0.06), np.full(30, 0.03)])
    noisy = true_path + rng.normal(0, 0.01, size=len(true_path))
    grid = (0.001, 0.01, 0.1, 1.0, 10.0)
    result = choose_tv_lambda_by_cv(noisy, grid, n_folds=5, seed=0)
    assert result["chosen_lambda"] != grid[0], "must not degenerate to minimal smoothing"
    assert result["method"] == "masked_cross_validation"


def test_detect_changepoints_finds_the_two_known_jumps():
    true_theta = np.concatenate([np.full(20, 0.04), np.full(15, 0.055), np.full(15, 0.03)])
    rng = np.random.default_rng(1)
    noisy = true_theta + rng.normal(0, 0.004, size=len(true_theta))
    smoothed = tv_denoise(noisy, lam=0.03)
    cps = detect_changepoints(smoothed, tol=0.003)
    assert len(cps) >= 1  # at least detects real structure, not nothing


def test_cir_exact_sample_matches_known_stationary_moments():
    rng = np.random.default_rng(2)
    kappa, theta, xi = 3.0, 0.04, 0.3
    V0 = np.full(20000, theta)  # start at stationary mean
    V1 = cir_exact_sample(rng, V0, kappa, theta, xi, dt=1.0)
    # stationary CIR: E[V]=theta, Var[V]=theta*xi^2/(2*kappa)
    assert abs(V1.mean() - theta) < 0.002
    assert abs(V1.var() - theta * xi ** 2 / (2 * kappa)) < 0.0005


def test_cir_exact_sample_handles_single_particle():
    rng = np.random.default_rng(3)
    out = cir_exact_sample(rng, np.array([0.04]), 3.0, 0.04, 0.3, 1 / 52)
    assert out.shape == (1,)
    assert out[0] > 0.0


def test_particle_filter_recovers_synthetic_cir_path():
    # tau_obs=0.3 (realistic, not negligible observation noise) so there is
    # genuine room for filtering to beat the raw noisy observation; checked
    # across multiple seeds for robustness, not cherry-picked.
    kappa, theta, xi = 3.0, 0.04, 0.3
    n, dt = 50, 1 / 52
    for seed in range(5):
        rng = np.random.default_rng(seed)
        V = np.zeros(n)
        V[0] = 0.04
        for t in range(1, n):
            V[t] = cir_exact_sample(rng, np.array([V[t - 1]]), kappa, theta, xi, dt)[0]
        V_hat = V * np.exp(rng.normal(0, 0.3, size=n))

        pf = particle_filter_V(list(range(n)), V_hat, np.full(n, dt), kappa, np.full(n, theta), xi, tau_obs=0.3,
                                n_particles=2000, seed=seed + 100)
        mean_abs_error = np.mean(np.abs(pf.filtered_mean - V))
        naive_error = np.mean(np.abs(V_hat - V))
        assert mean_abs_error < naive_error, (seed, mean_abs_error, naive_error)
        assert np.all(pf.ess[1:] > 50)  # no catastrophic particle degeneracy
