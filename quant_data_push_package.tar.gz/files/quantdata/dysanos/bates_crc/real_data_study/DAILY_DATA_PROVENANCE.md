# Daily data provenance (unblocks the "Historical Simulator" task)

## What arrived

`daily.zip` (327MB compressed, ~992MB extracted), supplied locally by the
user on 2026-10-06, containing pre-computed `smooth_interpolated_market`
outputs (PYTREE_HDF5 format, identical schema to this repo's own
`day_loader.load_day`):

| Ticker | N dates | Range |
|---|---|---|
| SPX | 892 | 2022-01-03 .. 2025-08-29 |
| NDX | 918 | 2022-01-03 .. 2025-08-29 |
| RUT | 918 | 2022-01-03 .. 2025-08-29 |
| VIX | 18 | 2022-01-03 .. 2022-01-27 (partial, not usable as a series) |

This is effectively a **daily** series (892/918 dates over ~3.5 years is
close to every trading day), and the SPX range matches dy2's own declared
`PHASE3_TRAIN_START`/`PHASE3_VALIDATION_END` window
(`weekly_dynamics.py`) almost exactly. This is the data source the
deferred "Historical Simulator" task was blocked on.

## Confirmed genuine, confirmed compatible, confirmed NOT the same filter config as this repo's defaults

- Spot-checked SPX 2024-03-05: `spot_ref=5078.64990234375`, exactly matching
  what this repo's own `day_loader.load_day('SPX', date(2024,3,5))` computes
  from the local WIDB fixture for that date (verified in the prior
  cross-sectional task) -- same underlying market data and convention.
- The cache directory's filter-identity hash prefix
  (`bid=0.011, nat,eth=10,bth=4,mps=1e-06,m ca250824`) does NOT match what
  this repo's current `OptionsFilter()`/`RawDayFilter()`/`ExpiryFilter()`/
  `MkArbFree()` defaults produce (`...m d872d290` for the same smoothness
  hash `sm_0.25 6b930b59`) -- confirmed by the differing raw contract/expiry
  counts for the same date (2961 contracts / 31 expiries here, vs. 1000 /
  50 from this repo's own pull) -- i.e. a different `OptionsFilter`
  configuration was used to produce this cache (plausibly: "the original
  repo" referenced earlier in this session, distinct from this
  `BlankaNHorvath/Agentic` sandbox). This does NOT block usability: it only
  means `smooth_interpolated_market`'s own hashed cache-key lookup cannot
  find these files automatically.

## How it's loaded

`real_data_study/daily_cache_loader.py` reads the files DIRECTLY by
`(ticker, date)` path (`SubDir(...).read(date.isoformat(),
fmt=Format.PYTREE_HDF5)`), bypassing the hash-based cache-key lookup
entirely -- no computation happens, no network access, no
`QUANTDATA_TEST_MODE=generate_tests` needed (plain `QUANTDATA_TEST_MODE=1`
suffices, since nothing beyond `quantdata` package import-time
initialisation is required). Returns the same `day_loader.DayBook`
dataclass the rest of `real_data_study/` already consumes, so
`build_evaluation_set` and every downstream calibrator work unchanged.

## Storage

The ~1GB cache directory (`/Users/blanka/Agentic/daily_data_cache/`,
extracted from `daily.zip`, both sibling to `quant_data-main/` and
**outside** this git repository) is gitignored at the outer-repo level
(`/daily.zip`, `/daily_data_cache/` in `/Users/blanka/Agentic/.gitignore`)
-- too large to commit, and fully reproducible by re-extracting the zip.
Only derived, small, committed artifacts (fitted parameter sequences,
metrics, figures, reports) go into git, per this whole project's
established convention.
