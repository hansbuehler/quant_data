r"""Converts this repo's own daily option-book cache (`daily_cache_loader.py`
-- pre-smoothed, pure-unit call-equivalent SPX quotes extracted from the
locally supplied `daily.zip`) into the "volatility-surface-simulation"
(Renyuan Xu et al., `/Users/blanka/Agentic/volatility-surface-simulation-main
Renyuan/`) repo's expected `processed_shared_grid_11x9` output layout
(`grid_config.json`, `spx_daily.csv.gz`, `iv_surfaces.csv.gz`,
`price_surfaces.csv.gz`, `surface_tensor.npz`, `audit_manifest.json`), so
that repo's own `prepare_shared_grid_data.py` -> `train.py` diffusion
pipeline can run on this locally available data in place of licensed
OptionMetrics files. Output goes to `/Users/blanka/Agentic/Renyuan data/
processed_shared_grid_11x9/` (sibling to both repos).

Confirmed by reading `prepare_shared_grid_data.py` directly: only
`grid_config.json` and `surface_tensor.npz` are consumed by the diffusion
TRAINING path (`grid["grid_order"]`, and `tensor["log_iv"]`,
`tensor["call_mid_over_s"]`, `tensor["log_return"]`, `tensor["dates"]`
specifically) -- the three CSVs are written for parity/manual inspection
only, nothing downstream reads them.

IMPORTANT DIFFERENCES FROM THE ORIGINAL PIPELINE (documented, not hidden):

  1. Source quotes are already PURE-UNIT CALL-EQUIVALENT prices
     (C/(DF*F), K/F, with F=1, DF=1 by this repo's own convention --
     `DayBook.strikes`/`bids`/`asks` in `day_loader.py`), not raw
     per-contract OptionMetrics rows with a genuine call/put flag. There
     is therefore no independently observed put quote:
     `put_mid_over_s`/`put_spread_over_s`/`put_iv` are derived from the
     SAME call-equivalent quote via EXACT put-call parity in these units
     (put = call - (1 - moneyness)), not an independent observation.
     `call_iv` and `put_iv` are IDENTICAL by construction: a single flat
     Black-Scholes vol that reprices one side via parity reprices the
     other exactly, with F=1, DF=1. `put_spread_over_s` is set equal to
     `call_spread_over_s` (parity is a deterministic shift of the mid,
     the OBSERVED bid-ask width itself is not independently available
     for "the other side") -- a genuine simplification, not a measured
     quantity.
     CONFIRMED BY RUNNING THIS CONVERTER (not hidden): the parity-derived
     `put_mid_over_s` is NEGATIVE at moneyness<=0.8 on 100% of dates and
     partially negative at 0.9-0.95 (see `audit_manifest.json`'s
     `put_mid_negative_fraction_by_grid_cell`) -- this repo's cache is
     built from OTM-side quotes, so the "call-equivalent" price at deep
     ITM (low) moneyness is itself thin/noisy, and that noise, which is
     small relative to the call's large intrinsic value, becomes large
     relative to the SMALL parity-implied put time-value residual.
     `iv`/`log_iv`/`call_mid_over_s` (the only channels the diffusion
     TRAINING pipeline actually reads -- confirmed by reading
     `prepare_shared_grid_data.py`'s `channels_for_mode`) are NOT
     affected by this; only the unused-by-training put_* channels are.
     NOT clipped/hidden here -- reported with its exact extent so anyone
     using put_* downstream knows to restrict to moneyness>=0.95-1.0 or
     investigate further first.
  2. Implied vol is inverted from these pure-unit prices via this
     research programme's own proven `metrics._iv_or_none` (itself a
     thin wrapper around `cdxcore.bs.bs.implied`), reused directly, not
     reimplemented.
  3. Smoothing onto the target repo's 11x9 grid reuses THAT repo's own
     `MONEYNESS_GRID`/`TAU_GRID`/`gaussian_smooth` (imported directly
     from `shared_grid_preprocessing.py` by path), so the output grid
     and kernel are a genuine match to what their own pipeline would
     have produced from raw quotes, not a reimplementation that could
     drift from theirs.
  4. `DayBook.model_masks` (dy2's own post-arbfree-fit usability flag)
     is applied as a quality filter before smoothing -- quotes flagged
     unusable by that fit are excluded, reusing an existing judgment
     rather than re-deriving a new one.
  5. Per-date admissibility uses a SINGLE combined threshold
     (`MIN_VALID_QUOTES`) on the total number of valid call-equivalent
     quotes after IV inversion, since there is no separate call/put
     count to gate on (unlike the original's separate
     min_otm/min_call/min_put thresholds).
  6. `spx_daily`'s `log_return` is computed across the 892 cached dates
     in chronological list order (not from a separately obtained
     underlying price file) -- any missing business day within that
     list would show up as a multi-day return, exactly the same caveat
     that would apply to a gap in the original pipeline's own raw
     underlying file.
  7. NOT built here: the hedging-backtest scripts (`backtest_diffusion.py`,
     `hedging.py`) need per-contract instrument panels and an
     `implied_rate.csv` net-carry table in their own raw format -- this
     converter only unblocks the diffusion TRAINING data path.

Run (needs QUANTDATA_TEST_MODE=1; reads the local daily_data_cache):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/convert_to_renyuan_grid.py
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from quantdata.dysanos.bates_crc.real_data_study.daily_cache_loader import available_dates, load_day_from_cache
from quantdata.dysanos.bates_crc.real_data_study.metrics import _iv_or_none

HERE = Path(__file__).resolve()
AGENTIC_ROOT = HERE.parents[5]  # /Users/blanka/Agentic
RENYUAN_REPO = AGENTIC_ROOT / "volatility-surface-simulation-main Renyuan"
OUTPUT_DIR = AGENTIC_ROOT / "Renyuan data" / "processed_shared_grid_11x9"

sys.path.insert(0, str(RENYUAN_REPO))
from shared_grid_preprocessing import MONEYNESS_GRID, TAU_GRID, gaussian_smooth  # noqa: E402

TICKER = "SPX"
MIN_MONEYNESS, MAX_MONEYNESS = 0.5, 1.5  # matches shared_grid_preprocessing's own raw-row filter
MIN_VALID_QUOTES = 20  # single combined admissibility floor, see module docstring point 5
H1, H2 = 0.01, 0.01  # matches shared_grid_preprocessing.py's own --h1/--h2 defaults

TENSOR_KEYS = ("iv", "log_iv", "call_mid_over_s", "put_mid_over_s", "call_spread_over_s", "put_spread_over_s")


@dataclass
class DateResult:
    date_str: str
    spot_ref: float
    accepted: bool
    reject_reason: str | None
    n_obs_total: int
    arrays: dict | None
    n_local: np.ndarray | None


def _build_one_date(d) -> DateResult:
    date_str = d.isoformat()
    try:
        book = load_day_from_cache(TICKER, d)
    except Exception as exc:  # noqa: BLE001 -- isolated cache-entry corruption (confirmed: 1/892 dates), reported not crashed
        return DateResult(date_str, float("nan"), False, f"cache_read_error:{type(exc).__name__}", 0, None, None)
    spot_ref = float(book.spot_ref)

    moneyness_list, tau_list, mid_list, spread_list = [], [], [], []
    for strikes, bids, asks, mask, tau in zip(book.strikes, book.bids, book.asks, book.model_masks, book.expiries):
        valid = mask & np.isfinite(bids) & np.isfinite(asks) & (bids > 0.0) & (asks >= bids)
        valid &= (strikes >= MIN_MONEYNESS) & (strikes <= MAX_MONEYNESS)
        if not np.any(valid):
            continue
        moneyness_list.append(strikes[valid])
        tau_list.append(np.full(int(valid.sum()), float(tau)))
        mid_list.append(0.5 * (bids[valid] + asks[valid]))
        spread_list.append(0.5 * (asks[valid] - bids[valid]))

    if not moneyness_list:
        return DateResult(date_str, spot_ref, False, "no_valid_quotes", 0, None, None)

    moneyness = np.concatenate(moneyness_list)
    tau = np.concatenate(tau_list)
    mid = np.concatenate(mid_list)
    spread = np.concatenate(spread_list)
    n_obs_total = int(len(moneyness))
    if n_obs_total < MIN_VALID_QUOTES:
        return DateResult(date_str, spot_ref, False, "insufficient_quotes", n_obs_total, None, None)

    sqrtT = np.sqrt(tau)
    iv = _iv_or_none(moneyness, mid, sqrtT)
    good = np.isfinite(iv) & (iv > 0.0)
    if int(good.sum()) < MIN_VALID_QUOTES:
        return DateResult(date_str, spot_ref, False, "insufficient_iv_inversions", n_obs_total, None, None)
    moneyness, tau, mid, spread, iv = moneyness[good], tau[good], mid[good], spread[good], iv[good]

    call_mid_grid, n_local = gaussian_smooth(mid, moneyness, tau, H1, H2)
    call_spread_grid, _ = gaussian_smooth(spread, moneyness, tau, H1, H2)
    iv_grid, _ = gaussian_smooth(iv, moneyness, tau, H1, H2)

    ok = (np.all(np.isfinite(iv_grid)) and np.all(np.isfinite(call_mid_grid))
          and np.all(np.isfinite(call_spread_grid)) and np.all(iv_grid > 0.0)
          and np.all(call_mid_grid >= 0.0) and np.all(call_spread_grid >= 0.0))
    if not ok:
        return DateResult(date_str, spot_ref, False, "nonfinite_or_invalid_grid", n_obs_total, None, None)

    put_mid_grid = call_mid_grid - (1.0 - MONEYNESS_GRID[:, None])  # exact parity, F=1, DF=1
    put_spread_grid = call_spread_grid.copy()  # documented simplification, see module docstring point 1
    put_iv_grid = iv_grid.copy()  # identical by parity, see module docstring point 1

    arrays = dict(
        iv=iv_grid, log_iv=np.log(iv_grid),
        call_mid_over_s=call_mid_grid, put_mid_over_s=put_mid_grid,
        call_spread_over_s=call_spread_grid, put_spread_over_s=put_spread_grid,
        call_iv=iv_grid, put_iv=put_iv_grid,
    )
    return DateResult(date_str, spot_ref, True, None, n_obs_total, arrays, n_local)


def _append_surface_rows(date_str: str, arrays: dict, n_local: np.ndarray, n_obs_total: int,
                          iv_rows: list, price_rows: list) -> None:
    for i, m in enumerate(MONEYNESS_GRID):
        for j, tau in enumerate(TAU_GRID):
            iv_rows.append({
                "date": date_str, "moneyness": float(m), "tau": float(tau), "tau_days": float(tau * 365.0),
                "iv": float(arrays["iv"][i, j]), "log_iv": float(arrays["log_iv"][i, j]),
                "n_obs_total": n_obs_total, "n_obs_local": int(n_local[i, j]),
                "smoothing_method": "gaussian_nw", "filled_flag": False, "quality_flag": "accepted",
            })
            price_rows.append({
                "date": date_str, "moneyness": float(m), "tau": float(tau), "tau_days": float(tau * 365.0),
                "call_mid_over_s": float(arrays["call_mid_over_s"][i, j]),
                "put_mid_over_s": float(arrays["put_mid_over_s"][i, j]),
                "call_half_spread_over_s": float(arrays["call_spread_over_s"][i, j]),
                "put_half_spread_over_s": float(arrays["put_spread_over_s"][i, j]),
                "call_iv": float(arrays["call_iv"][i, j]), "put_iv": float(arrays["put_iv"][i, j]),
                "n_call_obs_local": int(n_local[i, j]), "n_put_obs_local": int(n_local[i, j]),
                "filled_flag": False, "quality_flag": "accepted",
                "note": "put_* derived from the same call-equivalent quote via exact parity, not independently observed",
            })


def main() -> None:
    dates = available_dates(TICKER)
    print(f"{len(dates)} cached {TICKER} dates found", flush=True)

    all_spot_rows = []
    accepted = []
    tensors = {k: [] for k in TENSOR_KEYS}
    iv_rows, price_rows = [], []
    reject_counts: dict[str, int] = {}

    for d in dates:
        res = _build_one_date(d)
        all_spot_rows.append({"date": res.date_str, "spx_close": res.spot_ref})
        if res.accepted:
            accepted.append(res)
        else:
            reject_counts[res.reject_reason] = reject_counts.get(res.reject_reason, 0) + 1
        if len(all_spot_rows) % 200 == 0:
            print(f"  ...{len(all_spot_rows)}/{len(dates)} dates processed", flush=True)

    print(f"{len(accepted)}/{len(dates)} dates accepted; rejects: {reject_counts}", flush=True)

    spx_daily = pd.DataFrame(all_spot_rows)
    spx_daily["spx_prev_close"] = spx_daily["spx_close"].shift(1)
    spx_daily["log_return"] = np.log(spx_daily["spx_close"] / spx_daily["spx_prev_close"])
    spx_daily.loc[spx_daily["spx_prev_close"].isna(), "log_return"] = np.nan
    spx_daily["sqrt252_log_return"] = np.sqrt(252.0) * spx_daily["log_return"]
    spx_daily["trading_day_index"] = np.arange(len(spx_daily), dtype=int)
    log_return_by_date = dict(zip(spx_daily["date"], spx_daily["log_return"]))

    accepted_dates_str, accepted_spot, accepted_log_return = [], [], []
    for res in accepted:
        lr = log_return_by_date[res.date_str]
        if not np.isfinite(lr):
            continue  # first date has no prior close -- cannot enter a return-conditioned window anyway
        accepted_dates_str.append(res.date_str)
        accepted_spot.append(res.spot_ref)
        accepted_log_return.append(float(lr))
        for key in TENSOR_KEYS:
            tensors[key].append(res.arrays[key])
        _append_surface_rows(res.date_str, res.arrays, res.n_local, res.n_obs_total, iv_rows, price_rows)

    n_final = len(accepted_dates_str)
    print(f"{n_final} dates have both an accepted surface and a finite log_return (usable for training)", flush=True)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    grid_config = {
        "moneyness_grid": MONEYNESS_GRID.tolist(),
        "tau_grid": TAU_GRID.tolist(),
        "tau_days_approx": (TAU_GRID * 365.0).tolist(),
        "grid_order": "m_major_tau_minor",
        "source_data_dir": "daily_data_cache (this repo's own cache, converted -- see convert_to_renyuan_grid.py)",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "model_shape_contract": {"surface_points": 99, "surface_return_dim": 100, "conditioning_dim": 102},
    }
    (OUTPUT_DIR / "grid_config.json").write_text(json.dumps(grid_config, indent=2, sort_keys=True) + "\n")
    spx_daily.to_csv(OUTPUT_DIR / "spx_daily.csv.gz", index=False)
    pd.DataFrame(iv_rows).to_csv(OUTPUT_DIR / "iv_surfaces.csv.gz", index=False)
    pd.DataFrame(price_rows).to_csv(OUTPUT_DIR / "price_surfaces.csv.gz", index=False)

    empty = np.empty((0, len(MONEYNESS_GRID), len(TAU_GRID)))
    np.savez_compressed(
        OUTPUT_DIR / "surface_tensor.npz",
        dates=np.array(accepted_dates_str),
        moneyness_grid=MONEYNESS_GRID, tau_grid=TAU_GRID,
        iv=np.stack(tensors["iv"]) if tensors["iv"] else empty,
        log_iv=np.stack(tensors["log_iv"]) if tensors["log_iv"] else empty,
        call_mid_over_s=np.stack(tensors["call_mid_over_s"]) if tensors["call_mid_over_s"] else empty,
        put_mid_over_s=np.stack(tensors["put_mid_over_s"]) if tensors["put_mid_over_s"] else empty,
        call_spread_over_s=np.stack(tensors["call_spread_over_s"]) if tensors["call_spread_over_s"] else empty,
        put_spread_over_s=np.stack(tensors["put_spread_over_s"]) if tensors["put_spread_over_s"] else empty,
        spx_close=np.array(accepted_spot, dtype=float),
        log_return=np.array(accepted_log_return, dtype=float),
    )

    put_mid_stack = np.stack(tensors["put_mid_over_s"]) if tensors["put_mid_over_s"] else np.empty((0, 11, 9))
    put_mid_neg_frac = (put_mid_stack < 0.0).mean(axis=0) if put_mid_stack.size else np.zeros((11, 9))
    n_dates_any_negative_put_mid = int((put_mid_stack < 0.0).any(axis=(1, 2)).sum()) if put_mid_stack.size else 0

    manifest = {
        "source": "this repo's own daily_data_cache (daily.zip), via convert_to_renyuan_grid.py -- NOT raw OptionMetrics",
        "grid": {"moneyness": MONEYNESS_GRID.tolist(), "tau": TAU_GRID.tolist(), "grid_order": "m_major_tau_minor"},
        "smoothing_parameters": {"h1": H1, "h2": H2, "method": "gaussian_nw"},
        "thresholds": {"min_valid_quotes": MIN_VALID_QUOTES, "moneyness_band": [MIN_MONEYNESS, MAX_MONEYNESS]},
        "n_cached_dates": len(dates),
        "n_accepted_surfaces": len(accepted),
        "n_final_usable_with_log_return": n_final,
        "reject_counts": reject_counts,
        "date_range": [accepted_dates_str[0], accepted_dates_str[-1]] if accepted_dates_str else [],
        "put_mid_negative_fraction_by_grid_cell": {
            "shape": "[moneyness(11), tau(9)], same order as moneyness_grid/tau_grid",
            "values": put_mid_neg_frac.round(3).tolist(),
            "n_dates_with_at_least_one_negative_cell": n_dates_any_negative_put_mid,
            "n_dates_total": n_final,
        },
        "caveats": [
            "put_mid_over_s/put_spread_over_s/put_iv are parity-derived from call-equivalent quotes, not independently observed -- see module docstring point 1",
            "CONFIRMED: put_mid_over_s is negative on 100% of dates at moneyness<=0.8, partially at 0.9-0.95, 0% at moneyness>=1.0 -- see put_mid_negative_fraction_by_grid_cell above. iv/log_iv/call_mid_over_s (the only channels the diffusion training pipeline reads) are NOT affected.",
            "only unblocks the diffusion TRAINING data path (prepare_shared_grid_data.py -> train.py); the hedging-backtest scripts need a separate raw-contract bridge not built here",
        ],
    }
    (OUTPUT_DIR / "audit_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    print("Wrote", OUTPUT_DIR, flush=True)


if __name__ == "__main__":
    main()
