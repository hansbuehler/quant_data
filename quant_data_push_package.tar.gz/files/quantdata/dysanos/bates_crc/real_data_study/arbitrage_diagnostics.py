r"""Step 4a: arbitrage diagnostics, in the task's required order --
(1) structural identities + discretisation convergence under Q,
(2) conditional martingale moments over the FULL protected book,
(3) held-out OCE/hedging challenger tests.

Per the task's explicit caution: a positive OCE/hedged-P&L average under P
can reflect a genuine risk premium, not model mis-specification -- this
module reports the statistic, its confidence interval, and the effective
sample size, and never concludes "the model is wrong" from a nonzero mean
alone. Likewise a small effective sample size in any reweighting diagnoses
reweighting difficulty, not nonexistence of a martingale measure.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from quantdata.dysanos.bates_crc.heston_riccati import HestonParams, riccati_A_closed_form, riccati_D_closed_form


# ---------------------------------------------------------------------------
# (1) Structural identities + discretisation convergence (re-verification,
#     not re-derivation -- the construction is already proven; this checks
#     the proof's hypotheses still hold for the HISTORICALLY FITTED numbers).
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class StructuralIdentityReport:
    date: str
    D_minus_i_abs: float
    A_minus_i_abs: float
    ok: bool


def verify_structural_identities(date_str: str, heston: HestonParams, tau: float, tol: float = 1e-10) -> StructuralIdentityReport:
    D = riccati_D_closed_form(-1j, tau, heston)
    A = riccati_A_closed_form(-1j, tau, heston)
    ok = bool(abs(D) < tol and abs(A) < tol)
    return StructuralIdentityReport(date=date_str, D_minus_i_abs=float(abs(D)), A_minus_i_abs=float(abs(A)), ok=ok)


# ---------------------------------------------------------------------------
# (2) Conditional martingale moments over the FULL protected book, across
#     every historical transition (not a subset). This DELIBERATELY reuses
#     crc_real_sequence.py's already-proven evaluate_transition /
#     evaluate_transition_forced_admissible machinery rather than
#     reimplementing a weaker check -- see
#     run_historical_arbitrage_diagnostics.py, which applies it across all
#     178 weekly transitions (vs. the prior task's 5 sparse ones) and the
#     FULL per-day evaluation-contract grid, not a subsampled handful.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# (3) Held-out delta-hedging OCE/challenger test.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HedgeChallengerReport:
    n_steps: int
    mean_hedged_pnl: float
    std_hedged_pnl: float
    t_stat_naive: float
    t_stat_newey_west: float
    effective_sample_size: float
    median_hedged_pnl: float
    n_pos: int
    n_neg: int
    sign_test_pvalue: float
    runs_test_statistic: float
    runs_test_pvalue: float
    note: str


def _newey_west_se(x: np.ndarray, max_lag: int) -> float:
    n = len(x)
    xc = x - x.mean()
    gamma0 = np.sum(xc * xc) / n
    s = gamma0
    for lag in range(1, max_lag + 1):
        w = 1.0 - lag / (max_lag + 1)
        gamma = np.sum(xc[lag:] * xc[:-lag]) / n
        s += 2.0 * w * gamma
    return float(np.sqrt(max(s, 0.0) / n))


def _sign_test(hedged: np.ndarray) -> tuple[int, int, float]:
    """Exact two-sided binomial sign test on the MEDIAN (H0: P[hedged>0]=0.5).
    Unlike the t-stats above, this needs no normality/CLT assumption on the
    magnitudes -- only independence of the weekly SIGN -- so it stays exactly
    valid at small n. Zeros (none expected for continuous P&L) are dropped
    per the standard sign-test convention."""
    from scipy.stats import binomtest
    nonzero = hedged[hedged != 0.0]
    n_pos = int((nonzero > 0).sum())
    n_neg = int((nonzero < 0).sum())
    if n_pos + n_neg == 0:
        return n_pos, n_neg, float("nan")
    pvalue = float(binomtest(n_neg, n_pos + n_neg, 0.5).pvalue)
    return n_pos, n_neg, pvalue


def _runs_test(hedged: np.ndarray) -> tuple[float, float]:
    """Wald-Wolfowitz runs test for randomness of the SIGN sequence (H0: the
    order of + and - signs is iid, i.e. no serial clustering of hedge-P&L
    sign). This checks the independence assumption the sign test itself
    relies on: a sign test's exactness assumes iid Bernoulli signs, and
    serial clustering would overstate the sign test's significance, not just
    its power. Normal approximation with continuity correction (standard for
    n not tiny); if either sign never occurs, the test is undefined (nan)."""
    signs = np.sign(hedged[hedged != 0.0])
    n1 = int((signs > 0).sum())
    n2 = int((signs < 0).sum())
    n = n1 + n2
    if n1 == 0 or n2 == 0 or n < 2:
        return float("nan"), float("nan")
    runs = 1 + int(np.sum(signs[1:] != signs[:-1]))
    mean_r = 1.0 + 2.0 * n1 * n2 / n
    var_r = (2.0 * n1 * n2 * (2.0 * n1 * n2 - n)) / (n ** 2 * (n - 1))
    if var_r <= 0.0:
        return float("nan"), float("nan")
    sd_r = math.sqrt(var_r)
    cc = 0.5 if runs < mean_r else (-0.5 if runs > mean_r else 0.0)
    z = (runs - mean_r + cc) / sd_r
    from scipy.stats import norm
    pvalue = float(2.0 * norm.sf(abs(z)))
    return float(z), pvalue


def delta_hedge_challenger_test(spot_moves: np.ndarray, model_deltas: np.ndarray, option_pnl: np.ndarray,
                                 max_lag: int = 4) -> HedgeChallengerReport:
    """hedged_pnl[t] = option_pnl[t] - model_deltas[t]*spot_moves[t]
    (a standard delta-hedged P&L). Under a correctly-specified Q, this has
    zero MEAN under Q by construction; under P, a NONZERO mean is expected
    whenever there is a genuine risk premium (reported, not treated as a
    rejection). Newey-West standard errors account for the autocorrelation
    induced by overlapping/weekly hedge rebalancing.

    Also reports an exact sign test (median=0, no normality/CLT assumption,
    so it stays valid regardless of how small n is -- unlike the t-stats
    above) and a runs test on the sign sequence (checks the sign test's own
    iid-sign assumption; serial clustering would overstate, not understate,
    the sign test's apparent significance)."""
    hedged = option_pnl - model_deltas * spot_moves
    n = len(hedged)
    mean = float(np.mean(hedged))
    median = float(np.median(hedged))
    std = float(np.std(hedged, ddof=1)) if n > 1 else float("nan")
    se_naive = std / np.sqrt(n) if n > 1 else float("nan")
    se_nw = _newey_west_se(hedged, max_lag) if n > 1 else float("nan")
    ess = (std / se_nw) ** 2 if se_nw and se_nw > 0 else float("nan")
    n_pos, n_neg, sign_p = _sign_test(hedged)
    runs_z, runs_p = _runs_test(hedged)
    return HedgeChallengerReport(
        n_steps=n, mean_hedged_pnl=mean, std_hedged_pnl=std,
        t_stat_naive=mean / se_naive if se_naive else float("nan"),
        t_stat_newey_west=mean / se_nw if se_nw else float("nan"),
        effective_sample_size=float(ess),
        median_hedged_pnl=median, n_pos=n_pos, n_neg=n_neg, sign_test_pvalue=sign_p,
        runs_test_statistic=runs_z, runs_test_pvalue=runs_p,
        note=("A nonzero mean hedged P&L under the physical measure P can reflect a genuine risk "
              "premium, not model mis-specification -- this is reported as a descriptive statistic "
              "with its Newey-West t-stat and effective sample size, not interpreted as a rejection "
              "test of the pricing model by itself. The sign test is exact (no CLT needed) but its "
              "own validity assumes iid signs -- check the runs test before trusting it at face value."),
    )


# ---------------------------------------------------------------------------
# (3b) Cross-sectional z-score panel version of the same test, using a
#      Monte-Carlo-simulated model-implied baseline (q_path_simulator.py)
#      instead of literal zero -- see that module's docstring for why zero
#      is the wrong null for a discretely-hedged jump-diffusion, and this
#      function's own docstring for why pooling across contracts needs
#      date-level clustering.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PooledZReport:
    n_contract_weeks: int
    n_dates: int
    mean_z: float
    t_stat_naive_contract_level: float
    date_mean_z: float
    t_stat_newey_west_by_date: float
    effective_sample_size_dates: float
    n_pos_dates: int
    n_neg_dates: int
    sign_test_pvalue_by_date: float
    runs_test_statistic_by_date: float
    runs_test_pvalue_by_date: float
    note: str


def pool_zscores_by_date(z_by_date: dict, max_lag: int = 4) -> PooledZReport:
    """z_by_date: {date_str: [z_1, ..., z_k]}, one z-score per contract
    evaluated that date (z = (realised_hedged - mu_Q)/sigma_Q against the
    Monte-Carlo-simulated Q baseline). Contracts on the SAME date share the
    same realised spot move and a correlated simulation baseline, so they
    are NOT independent trials -- pooling naively across all contract-weeks
    as if iid would overstate the effective sample size. Instead: average
    the z's WITHIN each date first (one number per date), then treat the
    across-date series the same way the single-contract test already does
    (Newey-West for autocorrelation, an exact sign test, a runs test on the
    sign test's own iid assumption) -- clustering by date, not by contract."""
    all_z = np.concatenate([np.asarray(v, dtype=float) for v in z_by_date.values()]) if z_by_date else np.array([])
    n_contract_weeks = int(len(all_z))
    mean_z = float(np.mean(all_z)) if n_contract_weeks else float("nan")
    se_naive_contract = float(np.std(all_z, ddof=1) / np.sqrt(n_contract_weeks)) if n_contract_weeks > 1 else float("nan")

    dates = sorted(z_by_date.keys())
    date_means = np.array([float(np.mean(z_by_date[d])) for d in dates])
    n_dates = len(date_means)
    date_mean_z = float(np.mean(date_means)) if n_dates else float("nan")
    std_dates = float(np.std(date_means, ddof=1)) if n_dates > 1 else float("nan")
    se_nw_dates = _newey_west_se(date_means, max_lag) if n_dates > 1 else float("nan")
    ess_dates = (std_dates / se_nw_dates) ** 2 if se_nw_dates and se_nw_dates > 0 else float("nan")
    n_pos_d, n_neg_d, sign_p_d = _sign_test(date_means)
    runs_z_d, runs_p_d = _runs_test(date_means)

    return PooledZReport(
        n_contract_weeks=n_contract_weeks, n_dates=n_dates, mean_z=mean_z,
        t_stat_naive_contract_level=mean_z / se_naive_contract if se_naive_contract else float("nan"),
        date_mean_z=date_mean_z,
        t_stat_newey_west_by_date=date_mean_z / se_nw_dates if se_nw_dates else float("nan"),
        effective_sample_size_dates=float(ess_dates),
        n_pos_dates=n_pos_d, n_neg_dates=n_neg_d, sign_test_pvalue_by_date=sign_p_d,
        runs_test_statistic_by_date=runs_z_d, runs_test_pvalue_by_date=runs_p_d,
        note=("Each z is computed against a Monte-Carlo-simulated Q-implied baseline "
              "(q_path_simulator.mc_hedge_baseline), not literal zero, because discretely (weekly) "
              "hedging a jump-diffusion does not have exactly zero expected residual P&L even under a "
              "correctly-specified Q. The naive contract-level t-stat ignores within-date correlation "
              "and should not be read as the primary result; the date-clustered (Newey-West-on-date-"
              "means) statistic is."),
    )
