r"""Final orchestrator: runs latent-state inference, dynamics comparison,
and generates all LaTeX table/figure fragments for the Historical Simulator
report. Run AFTER run_historical_calibration.py (and, separately,
run_historical_arbitrage_diagnostics.py) have completed.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from quantdata.dysanos.bates_crc.real_data_study.dynamics_comparison import (
    runtime_and_failure_rates,
    volatility_clustering,
)
from quantdata.dysanos.bates_crc.real_data_study.run_historical_calibration import OUT_PATH

HERE = Path(__file__).resolve().parent
DATA = HERE / "report_historical" / "data"
FIGS = HERE / "report_historical" / "figures"
DATA.mkdir(parents=True, exist_ok=True)
FIGS.mkdir(parents=True, exist_ok=True)

LATENT_PATH = HERE / "report" / "data" / "historical_latent_state.json"
ARB_PATH = HERE / "report" / "data" / "historical_arbitrage_diagnostics.json"


def write_table(path: Path, rows: list[tuple], header: tuple) -> None:
    with open(path, "w") as f:
        f.write("\\begin{tabular}{" + "l" * len(header) + "}\n\\toprule\n")
        f.write(" & ".join(header) + " \\\\\n\\midrule\n")
        for row in rows:
            f.write(" & ".join(str(x) for x in row) + " \\\\\n")
        f.write("\\bottomrule\n\\end{tabular}\n")


def main() -> None:
    with open(LATENT_PATH) as f:
        latent = json.load(f)
    with open(OUT_PATH) as f:
        raw_rows = json.load(f)

    bg = latent["background"]
    write_table(DATA / "fixed_background_table.tex", [
        ("Heston $\\kappa$", f"{bg['heston_kappa']:.4f}"),
        ("Heston $\\xi$", f"{bg['heston_xi']:.4f}"),
        ("Heston $\\rho$", f"{bg['heston_rho']:.4f}"),
        ("Chain $\\kappa$", f"{bg['chain_kappa']:.4f}"),
        ("Anchor half-width", f"{bg['anchor_half_width']:.4f}"),
        ("N train dates used", str(bg["n_train_dates"])),
    ], ("Parameter", "Value (TRAIN median)"))

    on = latent["observation_noise"]
    write_table(DATA / "observation_noise_table.tex", [
        ("$\\sigma_{obs}(\\theta)$", f"{on['sigma_obs_theta']:.5f}"),
        ("$\\tau_{obs}(\\log V)$", f"{on['tau_obs_logV']:.4f}"),
    ], ("Noise parameter", "Value (TRAIN)"))

    rl = latent["reset_proposal_law"]
    write_table(DATA / "reset_proposal_law_table.tex", [
        ("N resets identified (TRAIN)", str(rl["n_resets_used"])),
        ("$\\mu_\\Delta$", f"{rl['mu_delta']:.5f}" if rl["n_resets_used"] else "--"),
        ("$\\sigma_\\Delta$", f"{rl['sigma_delta']:.5f}" if rl["n_resets_used"] > 1 else "--"),
    ], ("Quantity", "Value"))

    rp = latent["variance_risk_premium"]
    write_table(DATA / "risk_premium_table.tex", [
        ("$\\eta_V$ (variance risk premium)", f"{rp['eta_V']:.4f}"),
        ("$\\kappa_P$ (implied P mean-reversion)", f"{rp['kappa_P']:.4f}"),
        ("$\\kappa_P > 0$?", "Yes" if rp["kappa_P"] > 0 else "NO -- P ill-posed, reported not hidden"),
    ], ("Quantity", "Value"))

    # theta / V path figures
    dates = latent["dates"]
    x = np.arange(len(dates))
    splits = latent["splits"]
    colors = {"train": "#2b6cb0", "validation": "#38a169", "held_out": "#c05621"}

    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.scatter(x, latent["theta_raw"], s=8, alpha=0.4, color="gray", label="raw (noisy)")
    ax.plot(x, latent["theta_smoothed"], color="#1a202c", lw=1.5, label="TV-smoothed latent")
    for cp in latent["changepoints_all_indices"]:
        ax.axvline(cp, color="red", alpha=0.3, lw=0.8)
    for split, color in colors.items():
        mask = [s == split for s in splits]
        idx = [i for i, m in enumerate(mask) if m]
        if idx:
            ax.axvspan(min(idx), max(idx), alpha=0.05, color=color)
    ax.set_xlabel("weekly date index (2022-01 .. 2025-08)")
    ax.set_ylabel(r"$\theta_t$")
    ax.legend(frameon=False, fontsize=8)
    ax.set_title("Theta path: raw calibration vs. TV-denoised latent state")
    fig.tight_layout()
    fig.savefig(FIGS / "theta_path.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 4.5))
    V_raw = np.array(latent["V_raw"])
    V_f = np.array(latent["V_filtered_mean"])
    V_std = np.array(latent["V_filtered_std"])
    ax.scatter(x, V_raw, s=8, alpha=0.4, color="gray", label="raw (noisy)")
    ax.plot(x, V_f, color="#1a202c", lw=1.5, label="particle-filtered latent")
    ax.fill_between(x, V_f - V_std, V_f + V_std, color="#1a202c", alpha=0.15)
    ax.set_xlabel("weekly date index")
    ax.set_ylabel(r"$V_t$")
    ax.legend(frameon=False, fontsize=8)
    ax.set_title("V path: raw calibration vs. particle-filtered latent state")
    fig.tight_layout()
    fig.savefig(FIGS / "V_path.png", dpi=150)
    plt.close(fig)

    # fixed-contract option-price dynamics: DLV x Bates vs. dy2, same dates,
    # same contracts, per split (both already fit identically per date by
    # run_historical_calibration.py)
    dy2_rows = []
    for split in ("train", "validation", "held_out"):
        sub = [r for r in raw_rows if r["split"] == split and r.get("dlv_bates", {}).get("converged") and "dy2" in r]
        if not sub:
            continue
        for model, label in (("dy2", "dy2"), ("dlv_bates", "DLV$\\times$Bates")):
            iv = np.array([r[model]["median_abs_iv_error_bps"] for r in sub])
            inside = np.array([r[model]["pcnt_inside_bid_ask"] for r in sub])
            dy2_rows.append((split.replace("_", "-"), label, str(len(sub)), f"{np.median(iv):.2f}",
                              f"{100*np.median(inside):.1f}\\%"))
    write_table(DATA / "dy2_comparison_table.tex", dy2_rows,
                ("Split", "Model", "N dates", "Median $|IV error|$ (bps)", "Median \\% inside bid-ask"))

    # dynamics: runtime/failure + vol clustering on theta returns as a proxy
    runtime_report = runtime_and_failure_rates(raw_rows)
    theta_returns = np.diff(np.array(latent["theta_smoothed"]))
    vc = volatility_clustering(theta_returns, max_lag=10)
    write_table(DATA / "dynamics_summary_table.tex", [
        ("N dates attempted", str(runtime_report.n_dates)),
        ("N converged", str(runtime_report.n_converged)),
        ("Failure rate", f"{runtime_report.failure_rate*100:.1f}\\%"),
        ("Median wall-clock (s)", f"{runtime_report.median_wall_clock_seconds:.1f}"),
        ("Ljung-Box stat ($\\theta$ returns, 10 lags)", f"{vc.ljung_box_stat:.2f}"),
        ("Ljung-Box p-value", f"{vc.ljung_box_pvalue:.4f}"),
    ], ("Quantity", "Value"))

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(range(1, 11), vc.acf_abs_returns, color="#2b6cb0")
    ax.set_xlabel("lag (weeks)")
    ax.set_ylabel(r"ACF of $|\Delta\theta_t|$")
    ax.set_title("Volatility clustering proxy: ACF of absolute theta changes")
    fig.tight_layout()
    fig.savefig(FIGS / "vol_clustering.png", dpi=150)
    plt.close(fig)

    # minimal PCA placeholder figure (scope-limited, documented)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.text(0.5, 0.5, "Full surface PCA deferred\n(see scope note)", ha="center", va="center", fontsize=11)
    ax.axis("off")
    fig.savefig(FIGS / "pca_scree.png", dpi=150)
    plt.close(fig)

    # arbitrage diagnostics tables
    if ARB_PATH.exists():
        with open(ARB_PATH) as f:
            arb = json.load(f)
        write_table(DATA / "structural_identities_summary.tex", [
            ("N dates checked", str(len(arb["structural_identities"]))),
            ("N failures", str(arb["n_structural_identity_failures"])),
        ], ("Quantity", "Value"))
        write_table(DATA / "protected_option_summary_table.tex", [
            ("N transitions checked", str(arb["n_total_transitions"])),
            ("N admissible (standard region)", str(arb["n_admissible_transitions"])),
            ("\\% admissible", f"{100*arb['n_admissible_transitions']/max(arb['n_total_transitions'],1):.1f}\\%"),
        ], ("Quantity", "Value"))
    else:
        write_table(DATA / "structural_identities_summary.tex", [("status", "NOT YET RUN")], ("Quantity", "Value"))
        write_table(DATA / "protected_option_summary_table.tex", [("status", "NOT YET RUN")], ("Quantity", "Value"))

    oce_path = DATA / "oce_challenger_result.json"
    if oce_path.exists():
        with open(oce_path) as f:
            oce = json.load(f)
        sig = "Yes" if abs(oce["t_stat_newey_west"]) > 1.96 else "No (not significant at 5\\%)"
        sign_sig = "Yes" if oce["sign_test_pvalue"] < 0.05 else "No (not significant at 5\\%)"
        runs_sig = "Yes -- sign test's iid assumption is suspect" if oce["runs_test_pvalue"] < 0.05 \
            else "No -- sign sequence looks iid"
        write_table(DATA / "oce_challenger_table.tex", [
            ("N held-out weekly steps used", str(oce["n_steps"])),
            ("Mean hedged P\\&L", f"{oce['mean_hedged_pnl']:.5f}"),
            ("Median hedged P\\&L", f"{oce['median_hedged_pnl']:.5f}"),
            ("Std hedged P\\&L", f"{oce['std_hedged_pnl']:.5f}"),
            ("$t$-stat (naive)", f"{oce['t_stat_naive']:.3f}"),
            ("$t$-stat (Newey-West)", f"{oce['t_stat_newey_west']:.3f}"),
            ("Effective sample size (NW)", f"{oce['effective_sample_size']:.1f}"),
            ("Significant at 5\\%? (mean test)", sig),
            ("N negative / N positive weeks", f"{oce['n_neg']} / {oce['n_pos']}"),
            ("Sign test $p$-value (exact binomial)", f"{oce['sign_test_pvalue']:.4f}"),
            ("Significant at 5\\%? (sign test)", sign_sig),
            ("Runs test statistic (sign-sequence)", f"{oce['runs_test_statistic']:.3f}"),
            ("Runs test $p$-value", f"{oce['runs_test_pvalue']:.4f}"),
            ("Sign clustering detected?", runs_sig),
        ], ("Quantity", "Value"))
    else:
        write_table(DATA / "oce_challenger_table.tex", [("status", "NOT YET RUN")], ("Quantity", "Value"))

    panel_path = DATA / "oce_panel_result.json"
    if panel_path.exists():
        with open(panel_path) as f:
            panel = json.load(f)
        if "status" not in panel:
            panel_sig = "Yes" if abs(panel["t_stat_newey_west_by_date"]) > 1.96 else "No (not significant at 5\\%)"
            panel_sign_sig = "Yes" if panel["sign_test_pvalue_by_date"] < 0.05 else "No (not significant at 5\\%)"
            panel_runs_sig = "Yes -- sign test's iid assumption is suspect" \
                if panel["runs_test_pvalue_by_date"] < 0.05 else "No -- sign sequence looks iid"
            cp = panel["contract_panel"]
            write_table(DATA / "oce_panel_table.tex", [
                ("Contract panel", f"{len(cp['moneyness_targets'])} moneyness $\\times$ "
                                    f"{len(cp['tenor_targets'])} tenors"),
                ("MC paths per baseline", str(cp["n_mc_paths"])),
                ("N contract-weeks", str(panel["n_contract_weeks"])),
                ("N dates", str(panel["n_dates"])),
                ("Naive contract-level $t$-stat (WRONG, ignores clustering)", f"{panel['t_stat_naive_contract_level']:.3f}"),
                ("Date-clustered mean $z$", f"{panel['date_mean_z']:.4f}"),
                ("$t$-stat (Newey-West on date means)", f"{panel['t_stat_newey_west_by_date']:.3f}"),
                ("Effective sample size (dates)", f"{panel['effective_sample_size_dates']:.1f}"),
                ("Significant at 5\\%? (date-clustered)", panel_sig),
                ("N negative / N positive dates", f"{panel['n_neg_dates']} / {panel['n_pos_dates']}"),
                ("Sign test $p$-value (by date)", f"{panel['sign_test_pvalue_by_date']:.4f}"),
                ("Significant at 5\\%? (sign test)", panel_sign_sig),
                ("Runs test $p$-value (by date)", f"{panel['runs_test_pvalue_by_date']:.4f}"),
                ("Sign clustering detected?", panel_runs_sig),
            ], ("Quantity", "Value"))
        else:
            write_table(DATA / "oce_panel_table.tex", [("status", panel["status"])], ("Quantity", "Value"))
    else:
        write_table(DATA / "oce_panel_table.tex", [("status", "NOT YET RUN")], ("Quantity", "Value"))

    gap_path = DATA / "oce_gap_result.json"
    if gap_path.exists():
        with open(gap_path) as f:
            gap = json.load(f)
        if "status" not in gap:
            gap_sig = "Yes" if abs(gap["t_stat_newey_west_by_date"]) > 1.96 else "No (not significant at 5\\%)"
            gap_sign_sig = "Yes" if gap["sign_test_pvalue_by_date"] < 0.05 else "No (not significant at 5\\%)"
            rh = gap["rehedged_with_oce_delta"]
            rh_sig = "Yes" if abs(rh["t_stat_newey_west"]) > 1.96 else "No (not significant at 5\\%)"
            write_table(DATA / "oce_gap_table.tex", [
                ("Risk-aversion scale (entropic OCE)", f"{gap['risk_aversion_scale']:.1f}"),
                ("N contract-weeks (OCE solves converged)", str(gap["n_contract_weeks"])),
                ("N dates", str(gap["n_dates"])),
                ("Date-clustered mean gap ($\\delta^*_{\\rm OCE}-\\delta_{\\rm model}$)", f"{gap['date_mean_gap']:.4f}"),
                ("$t$-stat (Newey-West on date means)", f"{gap['t_stat_newey_west_by_date']:.3f}"),
                ("Effective sample size (dates)", f"{gap['effective_sample_size_dates']:.1f}"),
                ("Significant at 5\\%?", gap_sig),
                ("N negative / N positive dates", f"{gap['n_neg_dates']} / {gap['n_pos_dates']}"),
                ("Sign test $p$-value (by date)", f"{gap['sign_test_pvalue_by_date']:.4f}"),
                ("Significant at 5\\%? (sign test)", gap_sign_sig),
                ("Runs test $p$-value (by date)", f"{gap['runs_test_pvalue_by_date']:.4f}"),
            ], ("Quantity", "Value"))
            write_table(DATA / "oce_rehedge_table.tex", [
                ("N held-out weeks (date-averaged panel)", str(rh["n_steps"])),
                ("Mean hedged P\\&L (OCE-optimal $\\delta^*$)", f"{rh['mean_hedged_pnl']:.5f}"),
                ("Median hedged P\\&L (OCE-optimal $\\delta^*$)", f"{rh['median_hedged_pnl']:.5f}"),
                ("$t$-stat (Newey-West)", f"{rh['t_stat_newey_west']:.3f}"),
                ("Significant at 5\\%?", rh_sig),
                ("N negative / N positive weeks", f"{rh['n_neg']} / {rh['n_pos']}"),
                ("Sign test $p$-value", f"{rh['sign_test_pvalue']:.4f}"),
            ], ("Quantity", "Value"))
        else:
            write_table(DATA / "oce_gap_table.tex", [("status", gap["status"])], ("Quantity", "Value"))
            write_table(DATA / "oce_rehedge_table.tex", [("status", gap["status"])], ("Quantity", "Value"))
    else:
        write_table(DATA / "oce_gap_table.tex", [("status", "NOT YET RUN")], ("Quantity", "Value"))
        write_table(DATA / "oce_rehedge_table.tex", [("status", "NOT YET RUN")], ("Quantity", "Value"))

    # deferred/scope table
    write_table(DATA / "hist_deferred_table.tex", [
        ("Fixed-contract DLV$\\times$Bates vs.\\ dy2 comparison", "Implemented: identical dates/contracts, all 3 splits"),
        ("Fixed background (shared, not per-day)", "Implemented: TRAIN-median robust estimate"),
        ("Latent-state filtering", "Implemented: exact-CIR particle filter + TV denoising"),
        ("P/Q risk premium", "Implemented: extended-affine, explicit sign convention"),
        ("Reset-proposal law", "Implemented: truncated-normal MLE on identified resets"),
        ("Structural identities", "Re-verified across all historical dates"),
        ("Protected-option martingale check", "Across all 178 real weekly transitions"),
        ("Held-out OCE/hedge test", "Implemented: single-contract + sign/runs tests + 6-contract "
                                     "Monte-Carlo-baseline panel with date-clustered pooling + genuine "
                                     "entropic-OCE hedge-ratio optimization with gap/re-hedge reporting"),
        ("Full surface PCA / skew-term-structure time series", "Scope-limited this pass, deferred"),
        ("Front-expiry behaviour time series", "Scope-limited this pass, deferred"),
    ], ("Component", "Status"))

    print("Wrote all tables/figures to", DATA, "and", FIGS)


if __name__ == "__main__":
    main()
