r"""Step 2+3 orchestrator: turns the raw per-date calibration path
(historical_calibration.json) into the fitted latent-state path, fixed
background, risk premia, observation noise, and reset-proposal law --
the "actual fitted parameter sequences" deliverable.

Chronological discipline: the TV-denoising smoothness lambda is chosen by
one-step validation-split error (never held-out); the fixed background and
observation-noise/risk-premium estimates use the TRAIN split only; the
held-out split is touched ONLY in the downstream comparison/diagnostic
scripts (never here).

Run (plain QUANTDATA_TEST_MODE=1, no real-data computation here):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/run_historical_latent_state.py
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from quantdata.dysanos.bates_crc.real_data_study.historical_dynamics import (
    estimate_observation_noise,
    estimate_variance_risk_premium,
    extract_fixed_background,
    extract_series,
    fit_reset_proposal_law,
)
from quantdata.dysanos.bates_crc.real_data_study.latent_state import (
    choose_tv_lambda_by_cv,
    detect_changepoints,
    particle_filter_V,
    tv_denoise,
)
from quantdata.dysanos.bates_crc.real_data_study.run_historical_calibration import OUT_PATH

HERE = Path(__file__).resolve().parent
RESULT_PATH = HERE / "report" / "data" / "historical_latent_state.json"

LAM_GRID = (0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
CHANGEPOINT_TOL_MULTIPLIER = 3.0  # a changepoint is a jump > this many sigma_obs


def _json_default(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return str(obj)


def main() -> None:
    with open(OUT_PATH) as f:
        rows = json.load(f)
    rows = [r for r in rows if "dlv_bates" in r and r["dlv_bates"].get("converged")]
    print(f"{len(rows)} converged dates loaded", flush=True)

    background = extract_fixed_background(rows, split="train")
    print("fixed background:", background, flush=True)

    series = extract_series(rows)
    splits = np.array(series["splits"])
    train_mask = splits == "train"
    val_mask = splits == "validation"
    train_val_mask = train_mask | val_mask

    # Leakage-free: masked cross-validation on TRAIN+VALIDATION only (held-out
    # untouched), then the CHOSEN lambda is applied to the full series.
    lam_choice = choose_tv_lambda_by_cv(series["theta"][train_val_mask], LAM_GRID, n_folds=8, seed=0)
    print("theta TV lambda (masked CV, leakage-free):", lam_choice, flush=True)
    theta_smoothed = tv_denoise(series["theta"], lam=lam_choice["chosen_lambda"])

    noise = estimate_observation_noise(series["theta"], theta_smoothed, series["V"], series["V"], train_mask)
    print("observation noise:", noise, flush=True)

    changepoints_all = detect_changepoints(theta_smoothed, tol=CHANGEPOINT_TOL_MULTIPLIER * max(noise.sigma_obs_theta, 1e-6))
    changepoints_train = [i for i in changepoints_all if train_mask[i]]
    print(f"detected {len(changepoints_all)} changepoints total, {len(changepoints_train)} in TRAIN", flush=True)

    reset_law = fit_reset_proposal_law(theta_smoothed, changepoints_train)
    print("reset proposal law (TRAIN only):", reset_law, flush=True)

    pf = particle_filter_V(series["dates"], series["V"], series["dt_years"], background.heston_kappa, theta_smoothed,
                            background.heston_xi, tau_obs=max(noise.tau_obs_logV, 0.05), n_particles=4000, seed=0)
    print(f"particle filter: min ESS={pf.ess[1:].min():.0f}/4000, mean ESS={pf.ess[1:].mean():.0f}", flush=True)

    risk_premium = estimate_variance_risk_premium(pf.filtered_mean[train_mask], theta_smoothed[train_mask],
                                                   series["dt_years"][train_mask], kappa_Q=background.heston_kappa)
    print("variance risk premium (TRAIN only):", risk_premium, flush=True)

    out = dict(
        background=dict(heston_kappa=background.heston_kappa, heston_xi=background.heston_xi,
                         heston_rho=background.heston_rho, chain_kappa=background.chain_kappa,
                         anchor_half_width=background.anchor_half_width, n_train_dates=background.n_train_dates),
        observation_noise=dict(sigma_obs_theta=noise.sigma_obs_theta, tau_obs_logV=noise.tau_obs_logV),
        tv_lambda_choice=lam_choice,
        changepoints_all_indices=changepoints_all,
        changepoints_train_indices=changepoints_train,
        reset_proposal_law=dict(mu_delta=reset_law.mu_delta, sigma_delta=reset_law.sigma_delta,
                                 n_resets_used=reset_law.n_resets_used, delta_values=reset_law.delta_values,
                                 reset_indices=reset_law.reset_indices),
        variance_risk_premium=dict(eta_V=risk_premium.eta_V, kappa_P=risk_premium.kappa_P),
        dates=series["dates"], splits=series["splits"],
        theta_raw=series["theta"], theta_smoothed=theta_smoothed,
        V_raw=series["V"], V_filtered_mean=pf.filtered_mean, V_filtered_std=pf.filtered_std,
        V_particle_ess=pf.ess,
        lambda_J_raw=series["lambda_J"], m_J_raw=series["m_J"], delta_J_raw=series["delta_J"],
        dt_years=series["dt_years"],
    )
    with open(RESULT_PATH, "w") as f:
        json.dump(out, f, indent=2, default=_json_default)
    print("Wrote", RESULT_PATH, flush=True)


if __name__ == "__main__":
    main()
