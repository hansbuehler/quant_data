r"""Step 3 of the Historical Simulator task: fixed background parameters,
physical risk premia, and the admissible theta-reset proposal law, fit
JOINTLY across the smoothed latent path -- per HISTORICAL_PQ_SPECIFICATION.md.

Scope note on the "fixed background" simplification (reported, not hidden):
the per-date calibration (chain_bates_calibration.calibrate_chain_bates)
independently re-fits ALL 9 parameters (chain kappa, V_t, heston kappa/
theta/xi/rho, 3 jump params) every day -- exactly the "day-by-day
recalibration treated as evolution" the task warns against. Ideally one
would re-fit (theta_t, V_t, jump_t) with (kappa, xi, rho, chain_kappa) held
at their path-level estimate in a SECOND constrained pass per day; this
first implementation instead treats the full independent per-day fit as a
noisier observation of the same evolving state, which the TV-denoising/
particle-filter step (latent_state.py) is designed to handle, and extracts
the FIXED background as the ROBUST (median) central tendency over the
TRAIN split alone. Documented explicitly here and in the report, not
silently assumed away.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm

from quantdata.dysanos.bates_crc.real_data_study import config as cfg
from quantdata.dysanos.bates_crc.real_data_study.latent_state import (
    ParticleFilterResult,
    choose_tv_lambda_by_cv,
    detect_changepoints,
    particle_filter_V,
    tv_denoise,
)


@dataclass(frozen=True)
class FixedBackground:
    heston_kappa: float
    heston_xi: float
    heston_rho: float
    chain_kappa: float
    anchor_half_width: float
    n_train_dates: int


def extract_fixed_background(rows: list[dict], split: str = "train") -> FixedBackground:
    sub = [r for r in rows if r["split"] == split and "dlv_bates" in r]
    kappas = np.array([r["dlv_bates"]["heston"]["kappa"] for r in sub])
    xis = np.array([r["dlv_bates"]["heston"]["xi"] for r in sub])
    rhos = np.array([r["dlv_bates"]["heston"]["rho"] for r in sub])
    chain_kappas = np.array([r["dlv_bates"]["chain_kappa"] for r in sub])
    anchors = np.array([r["dlv_bates"]["anchors"][-1] for r in sub])
    half_widths = np.log(anchors)
    return FixedBackground(
        heston_kappa=float(np.median(kappas)), heston_xi=float(np.median(xis)),
        heston_rho=float(np.median(rhos)), chain_kappa=float(np.median(chain_kappas)),
        anchor_half_width=float(np.median(half_widths)), n_train_dates=len(sub),
    )


def extract_series(rows: list[dict]) -> dict:
    dates = [r["date"] for r in rows if "dlv_bates" in r]
    theta = np.array([r["dlv_bates"]["heston"]["theta"] for r in rows if "dlv_bates" in r])
    V = np.array([r["dlv_bates"]["V_t"] for r in rows if "dlv_bates" in r])
    lambda_J = np.array([r["dlv_bates"]["jumps"]["lambda_J"] for r in rows if "dlv_bates" in r])
    m_J = np.array([r["dlv_bates"]["jumps"]["m_J"] for r in rows if "dlv_bates" in r])
    delta_J = np.array([r["dlv_bates"]["jumps"]["delta_J"] for r in rows if "dlv_bates" in r])
    splits = [r["split"] for r in rows if "dlv_bates" in r]
    from datetime import date as _date
    dt_years = np.zeros(len(dates))
    for i in range(1, len(dates)):
        y, m, d = (int(x) for x in dates[i].split("-"))
        y0, m0, d0 = (int(x) for x in dates[i - 1].split("-"))
        dt_years[i] = (_date(y, m, d) - _date(y0, m0, d0)).days / 365.25
    dt_years[0] = cfg.HISTORICAL_WEEKLY_STRIDE / 252.0
    return dict(dates=dates, theta=theta, V=V, lambda_J=lambda_J, m_J=m_J, delta_J=delta_J,
                splits=splits, dt_years=dt_years)


@dataclass(frozen=True)
class ObservationNoise:
    sigma_obs_theta: float
    tau_obs_logV: float


def estimate_observation_noise(theta_raw: np.ndarray, theta_smoothed: np.ndarray, V_raw: np.ndarray,
                                V_smoothed: np.ndarray, train_mask: np.ndarray) -> ObservationNoise:
    resid_theta = (theta_raw - theta_smoothed)[train_mask]
    resid_logV = (np.log(np.maximum(V_raw, 1e-10)) - np.log(np.maximum(V_smoothed, 1e-10)))[train_mask]
    return ObservationNoise(sigma_obs_theta=float(np.std(resid_theta)), tau_obs_logV=float(np.std(resid_logV)))


@dataclass(frozen=True)
class RiskPremiumEstimate:
    eta_V: float
    kappa_P: float
    theta_P_scale: float
    eta_Z: float | None
    method: str


def estimate_variance_risk_premium(V_smoothed: np.ndarray, theta_smoothed: np.ndarray, dt_years: np.ndarray,
                                    kappa_Q: float) -> RiskPremiumEstimate:
    """Regress (V[t+1]-V[t])/dt on (theta[t]-V[t]) over the smoothed TRAIN
    path to get an empirical P mean-reversion speed kappa_P, then
    eta = kappa_Q - kappa_P per Sec. 3a of HISTORICAL_PQ_SPECIFICATION.md
    (kappa_P = kappa_Q - eta)."""
    dV = np.diff(V_smoothed) / dt_years[1:]
    x = (theta_smoothed[:-1] - V_smoothed[:-1])
    # OLS through a single slope: dV = kappa_P * x + noise
    mask = np.isfinite(dV) & np.isfinite(x) & (np.abs(x) > 1e-8)
    kappa_P = float(np.sum(dV[mask] * x[mask]) / np.sum(x[mask] ** 2))
    eta = kappa_Q - kappa_P
    return RiskPremiumEstimate(eta_V=eta, kappa_P=kappa_P, theta_P_scale=float("nan"), eta_Z=None,
                                method="OLS slope of dV/dt on (theta-V), smoothed TRAIN path")


@dataclass(frozen=True)
class ResetProposalLaw:
    mu_delta: float
    sigma_delta: float
    n_resets_used: int
    reset_indices: list
    delta_values: list


def fit_reset_proposal_law(theta_smoothed: np.ndarray, changepoint_indices: list[int]) -> ResetProposalLaw:
    """Truncated-normal MLE on the identified Delta_theta at each detected
    reset event (Sec. 5). With very few resets (plausible: a handful over
    3.5 years), reports the sample itself alongside the fitted moments so
    the small-sample caveat is visible, not hidden behind a point estimate."""
    deltas = [float(theta_smoothed[i] - theta_smoothed[i - 1]) for i in changepoint_indices]
    if len(deltas) == 0:
        return ResetProposalLaw(mu_delta=float("nan"), sigma_delta=float("nan"), n_resets_used=0,
                                 reset_indices=[], delta_values=[])
    mu = float(np.mean(deltas))
    sigma = float(np.std(deltas)) if len(deltas) > 1 else float("nan")
    return ResetProposalLaw(mu_delta=mu, sigma_delta=sigma, n_resets_used=len(deltas),
                             reset_indices=list(changepoint_indices), delta_values=deltas)
