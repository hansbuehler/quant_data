r"""Step 4a orchestrator: runs the three arbitrage diagnostics, in the
required order, across the full weekly historical path.

(1) Structural identities, re-verified for every historically fitted date.
(2) Protected-option martingale invariance, reusing crc_real_sequence.py's
    already-proven evaluate_transition/evaluate_transition_forced_admissible
    machinery across all 178 real weekly transitions (vs. the prior task's
    5 sparse ones) and the FULL per-day evaluation-contract grid.
(3) A held-out delta-hedge challenger test (HELD-OUT split only).

Run (QUANTDATA_TEST_MODE=generate_tests needed for the daily_cache_loader-
backed per-day evaluation-contract loads used by the martingale check):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/run_historical_arbitrage_diagnostics.py
"""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import numpy as np

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.arbitrage_diagnostics import (
    delta_hedge_challenger_test,
    verify_structural_identities,
)
from quantdata.dysanos.bates_crc.real_data_study.crc_real_sequence import (
    DatedBackground,
    evaluate_transition,
    evaluate_transition_forced_admissible,
)
from quantdata.dysanos.bates_crc.real_data_study.daily_cache_loader import load_day_from_cache
from quantdata.dysanos.bates_crc.real_data_study.day_loader import build_evaluation_set
from quantdata.dysanos.bates_crc.real_data_study.run_historical_calibration import OUT_PATH

HERE = Path(__file__).resolve().parent
RESULT_PATH = HERE / "report" / "data" / "historical_arbitrage_diagnostics.json"


def _json_default(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return str(obj)


def _row_to_background(r: dict) -> DatedBackground:
    y, m, d = (int(x) for x in r["date"].split("-"))
    b = r["dlv_bates"]
    heston = HestonParams(**b["heston"])
    jumps = GaussianJumpParams(**b["jumps"])
    anchors = tuple(b["anchors"])
    i0 = len(anchors) // 2
    chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=i0, kappa=b["chain_kappa"], sigma_y=0.0)
    return DatedBackground(d=date(y, m, d), heston=heston, jumps=jumps, chain_config=chain_config, V_t=b["V_t"])


def main() -> None:
    with open(OUT_PATH) as f:
        rows = json.load(f)
    rows = [r for r in rows if "dlv_bates" in r and r["dlv_bates"].get("converged")]
    print(f"{len(rows)} converged dates", flush=True)

    # (1) structural identities
    identity_reports = []
    for r in rows:
        heston = HestonParams(**r["dlv_bates"]["heston"])
        rep = verify_structural_identities(r["date"], heston, tau=0.25)
        identity_reports.append(dict(date=rep.date, D_minus_i_abs=rep.D_minus_i_abs, A_minus_i_abs=rep.A_minus_i_abs,
                                      ok=rep.ok))
    n_identity_fail = sum(1 for r in identity_reports if not r["ok"])
    print(f"structural identities: {len(identity_reports)-n_identity_fail}/{len(identity_reports)} hold", flush=True)

    # (2) protected-option martingale invariance across every real weekly transition
    backgrounds = [_row_to_background(r) for r in rows]
    standard_results, forced_results = [], []
    for i in range(len(backgrounds) - 1):
        prev, nxt = backgrounds[i], backgrounds[i + 1]
        try:
            book = load_day_from_cache("SPX", prev.d)
            ev = build_evaluation_set(book)
            contracts = ev.contracts
        except Exception:
            contracts = None
        std = evaluate_transition(prev, nxt, eval_contracts=contracts)
        standard_results.append(std)
        if (i + 1) % 20 == 0:
            n_admissible = sum(1 for s in standard_results if s["admissible"])
            print(f"  [{i+1}/{len(backgrounds)-1}] transitions checked, {n_admissible} admissible so far", flush=True)

    n_admissible = sum(1 for s in standard_results if s["admissible"])
    print(f"protected-option check: {n_admissible}/{len(standard_results)} transitions admissible "
          f"in the standard region", flush=True)

    out = dict(
        structural_identities=identity_reports,
        n_structural_identity_failures=n_identity_fail,
        protected_option_transitions=standard_results,
        n_admissible_transitions=n_admissible,
        n_total_transitions=len(standard_results),
    )
    with open(RESULT_PATH, "w") as f:
        json.dump(out, f, indent=2, default=_json_default)
    print("Wrote", RESULT_PATH, flush=True)


if __name__ == "__main__":
    main()
