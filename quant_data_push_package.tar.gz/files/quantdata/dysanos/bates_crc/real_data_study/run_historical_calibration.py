r"""Step 1 of the Historical Simulator task: per-date cross-sectional
calibration across the full weekly chronological path (train + validation +
held-out), using the dense daily_data_cache (DAILY_DATA_PROVENANCE.md).

This produces the RAW, noisy, independent per-date point estimates that the
latent-state smoothing step (run_historical_latent_state.py) then treats as
NOISY OBSERVATIONS of a smoothly-evolving latent state -- per the task's
explicit instruction not to treat day-to-day recalibration as the latent
path itself.

Writes results incrementally (flushes after every date) so a long run can
be interrupted/resumed without losing progress.

Run (no QUANTDATA_TEST_MODE=generate_tests needed -- daily_cache_loader
reads pre-computed files directly, no computation against WIDB):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/run_historical_calibration.py
"""

from __future__ import annotations

import json
import time
import traceback
from dataclasses import asdict
from datetime import date
from pathlib import Path

import numpy as np

from quantdata.dysanos.bates_crc.real_data_study import config as cfg
from quantdata.dysanos.bates_crc.real_data_study.chain_bates_calibration import (
    ChainBatesCalibrationError,
    calibrate_chain_bates,
)
from quantdata.dysanos.bates_crc.real_data_study.daily_cache_loader import available_dates, load_day_from_cache
from quantdata.dysanos.bates_crc.real_data_study.day_loader import build_evaluation_set
from quantdata.dysanos.bates_crc.real_data_study.dy2_baseline import price_dy2
from quantdata.dysanos.bates_crc.real_data_study.metrics import evaluate_model

HERE = Path(__file__).resolve().parent
OUT_PATH = HERE / "report" / "data" / "historical_calibration.json"

N_STARTS_HISTORICAL = 1  # warm-started from the previous chronological date; for dates with no
N_STARTS_HISTORICAL_COLD = 3  # warm start available (the first date), use this many cold-start attempts instead


def weekly_dates(ticker: str = cfg.PRIMARY_TICKER, stride: int = cfg.HISTORICAL_WEEKLY_STRIDE) -> list:
    return available_dates(ticker)[::stride]


def split_label(d: date) -> str:
    s = d.isoformat()
    if s < cfg.HISTORICAL_TRAIN_END:
        return "train"
    if s < cfg.HISTORICAL_VALIDATION_END:
        return "validation"
    return "held_out"


def _json_default(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, date):
        return obj.isoformat()
    return str(obj)


def _warm_start_vector(prev_entry: dict | None) -> np.ndarray | None:
    """Builds the 10-vector `calibrate_chain_bates` expects
    (chain_kappa, V_t, heston_kappa, heston_theta, heston_xi, heston_rho,
    lambda_J, m_J, delta_J, anchor_half_width) from the PREVIOUS
    chronological date's converged result, or None if unavailable."""
    if prev_entry is None or "dlv_bates" not in prev_entry:
        return None
    b = prev_entry["dlv_bates"]
    half_width = float(np.log(b["anchors"][-1]))
    return np.array([
        b["chain_kappa"], b["V_t"], b["heston"]["kappa"], b["heston"]["theta"], b["heston"]["xi"],
        b["heston"]["rho"], b["jumps"]["lambda_J"], b["jumps"]["m_J"], b["jumps"]["delta_J"], half_width,
    ])


def calibrate_one(d: date, prev_entry: dict | None = None) -> dict:
    t0 = time.time()
    entry: dict = dict(date=d.isoformat(), split=split_label(d))
    try:
        book = load_day_from_cache(cfg.PRIMARY_TICKER, d)
        ev = build_evaluation_set(book)
        entry["n_evaluation_contracts"] = len(ev.contracts)
        entry["n_excluded"] = len(ev.excluded)
    except Exception as exc:  # noqa: BLE001
        entry["load_error"] = f"{exc}\n{traceback.format_exc()}"
        entry["wall_clock_seconds"] = time.time() - t0
        return entry

    try:
        m_dy2 = evaluate_model("dy2", lambda s, e: price_dy2(book, s, e), ev.contracts)
        entry["dy2"] = dict(pcnt_inside_bid_ask=m_dy2.pcnt_inside_bid_ask,
                             median_abs_iv_error_bps=m_dy2.median_abs_iv_error_bps,
                             median_fit_err=m_dy2.median_fit_err)
    except Exception as exc:  # noqa: BLE001
        entry["dy2_error"] = str(exc)

    try:
        warm_start = _warm_start_vector(prev_entry)
        n_starts = N_STARTS_HISTORICAL if warm_start is not None else N_STARTS_HISTORICAL_COLD
        calib = calibrate_chain_bates(ev, n_starts=n_starts,
                                       n_quad=cfg.FOURIER_N_QUAD_OPTIMIZATION,
                                       u_max=cfg.FOURIER_U_MAX_OPTIMIZATION,
                                       warm_start_x0=warm_start)
        entry["warm_started"] = warm_start is not None
        m_bates = evaluate_model("dlv_bates", calib.price, ev.contracts)
        entry["dlv_bates"] = dict(
            heston=asdict(calib.heston), jumps=asdict(calib.jumps), V_t=calib.V_t,
            chain_kappa=calib.chain_config.kappa, anchors=list(calib.chain_config.anchors),
            final_cost=calib.final_cost, converged=calib.converged,
            chapman_kolmogorov_residual=calib.chapman_kolmogorov_residual,
            generator_residual=calib.generator_residual,
            pcnt_inside_bid_ask=m_bates.pcnt_inside_bid_ask,
            median_abs_iv_error_bps=m_bates.median_abs_iv_error_bps,
            median_fit_err=m_bates.median_fit_err,
            n_starts_converged=sum(1 for s in calib.starts if s.get("success")),
            n_starts_total=len(calib.starts),
        )
    except ChainBatesCalibrationError as exc:
        entry["dlv_bates_error"] = str(exc)

    entry["wall_clock_seconds"] = time.time() - t0
    return entry


def main() -> None:
    dates = weekly_dates()
    print(f"{len(dates)} weekly dates: {dates[0]} .. {dates[-1]}", flush=True)
    results = []
    if OUT_PATH.exists():
        with open(OUT_PATH) as f:
            results = json.load(f)
        done_dates = {r["date"] for r in results}
        print(f"resuming: {len(done_dates)} dates already done", flush=True)
    else:
        done_dates = set()

    by_date = {r["date"]: r for r in results}
    last_converged = None  # tracks the most recent chronologically-converged entry, for warm-starting

    for i, d in enumerate(dates):
        if d.isoformat() in done_dates:
            existing = by_date[d.isoformat()]
            if "dlv_bates" in existing:
                last_converged = existing
            continue
        entry = calibrate_one(d, prev_entry=last_converged)
        if "dlv_bates" in entry:
            last_converged = entry
        results.append(entry)
        results.sort(key=lambda r: r["date"])
        with open(OUT_PATH, "w") as f:
            json.dump(results, f, indent=2, default=_json_default)
        bates = entry.get("dlv_bates", {})
        status = "OK" if bates else entry.get("dlv_bates_error", entry.get("load_error", "?"))[:60]
        print(f"[{i+1}/{len(dates)}] {d} ({entry['split']}) {entry['wall_clock_seconds']:.1f}s "
              f"pcnt={bates.get('pcnt_inside_bid_ask')} {status}", flush=True)

    print("DONE. Wrote", OUT_PATH, flush=True)


if __name__ == "__main__":
    main()
