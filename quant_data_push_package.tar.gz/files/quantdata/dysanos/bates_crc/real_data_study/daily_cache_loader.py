r"""Loader for the dense daily real-data cache supplied locally for the
Historical Simulator task (892 SPX dates, 2022-01-03 to 2025-08-29, plus
NDX/RUT at similar density) -- see DAILY_DATA_PROVENANCE.md.

The cache is a set of `smooth_interpolated_market` PYTREE_HDF5 outputs
(identical schema to `day_loader.load_day`'s own `smooth_interpolated_market`
call -- confirmed directly: spot_ref for SPX 2024-03-05 matches exactly
what this repo's own `day_loader.load_day` computes from the WIDB fixture
for that same date), but with a DIFFERENT filter-identity hash prefix than
what this repo's current `OptionsFilter`/`RawDayFilter`/`ExpiryFilter`/
`MkArbFree` defaults produce -- so it cannot be found through
`smooth_interpolated_market`'s own hashed cache-key lookup. This module
reads the files directly by (ticker, date) path instead, bypassing that
lookup entirely; this does not touch WRDS/Massive or any network resource,
and does not require QUANTDATA_TEST_MODE=generate_tests (no computation
happens -- these files are pre-computed).

The cache directory itself (~1GB) is NOT part of this git repository (see
/daily_data_cache/ in the outer repo's .gitignore) -- it must be present
locally (extracted from daily.zip) for this module to work.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from pathlib import Path

import numpy as np
from cdxcore.subdir import Format, SubDir

from quantdata.sanos.arbfree import ArbFreePricer

from quantdata.dysanos.bates_crc.real_data_study.day_loader import DayBook

# Sibling to quant_data-main, outside the git repo -- see outer .gitignore.
CACHE_ROOT = Path(__file__).resolve().parents[5] / "daily_data_cache"


def _market_subdir() -> Path:
    candidates = list(CACHE_ROOT.glob("*/sm_0.25*"))
    if len(candidates) != 1:
        raise FileNotFoundError(
            f"expected exactly one 'sm_0.25*' subdirectory under {CACHE_ROOT}, found {candidates}. "
            "Extract daily.zip to /Users/blanka/Agentic/daily_data_cache/ first."
        )
    return candidates[0]


def available_dates(ticker: str) -> list[date]:
    ticker_dir = _market_subdir() / ticker
    if not ticker_dir.is_dir():
        raise FileNotFoundError(f"no cached dates for ticker {ticker!r} under {ticker_dir}")
    dates = []
    for p in ticker_dir.glob("*.h5"):
        y, m, d = (int(x) for x in p.stem.split("-"))
        dates.append(date(y, m, d))
    return sorted(dates)


def load_day_from_cache(ticker: str, d: date) -> DayBook:
    ticker_dir = _market_subdir() / ticker
    sd = SubDir(str(ticker_dir))
    raw = sd.read(d.isoformat(), fmt=Format.PYTREE_HDF5)
    if raw is None:
        raise FileNotFoundError(f"no cached entry for {ticker} {d} under {ticker_dir}")
    market = raw["market"]
    af_pricer = ArbFreePricer.from_dict(raw["af_pricer"])
    n_raw = int(sum(len(s) for s in market["strikes"]))
    return DayBook(
        ticker=ticker, d=d, spot_ref=float(raw["spot_ref"]), fwd_over_spot=1.0,
        expiries=np.asarray(market["expiries"], dtype=float),
        strikes=[np.asarray(s, dtype=float) for s in market["strikes"]],
        bids=[np.asarray(b, dtype=float) for b in market["bids"]],
        asks=[np.asarray(a, dtype=float) for a in market["asks"]],
        model_masks=[np.asarray(m, dtype=bool) for m in market["model_masks"]],
        dy2_af_pricer=af_pricer, dy2_fit_result=raw["fit_result"], n_raw_contracts=n_raw,
    )
