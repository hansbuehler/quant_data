r"""Monte Carlo simulator of the FITTED Q dynamics, one rebalancing period
(one week) forward -- built to answer a specific methodological objection
to `arbitrage_diagnostics.delta_hedge_challenger_test`: a discretely
(weekly) delta-hedged jump-diffusion does NOT have exactly zero expected
residual P&L even under a perfectly-specified Q, for two reasons that
compound:

  (1) a single linear (spot) delta does not span jump risk -- it only
      captures the jump law's average contribution to the price's spot
      sensitivity, not any individual jump realisation;
  (2) discrete (not continuous) rebalancing of a nonlinear position leaves
      a gamma-type residual whose expectation at THIS specific
      discretisation is a property of the model, not a universal zero.

So "compare the realised hedged P&L against literal zero" is the wrong
null. The right null is "compare it against what the FITTED Q model
itself predicts for this exact discrete hedge," and the only reliable way
to get that is to simulate it -- discretise the fitted Q dynamics, run many
one-week-forward paths from the same starting state, apply the identical
discrete hedge, and read off the model-implied mean and std.

State dynamics simulated (matches chain_pricer.py's mixture pricing
formula and heston_riccati.py's characteristic-function convention
exactly, not a different/approximate model):
  - X_t: the finite-state nearest-neighbour absorbing chain
    (comparison_interface.CoherentChainBlackAdapter) -- EXACTLY simulable
    (it already has an exact matrix-exponential transition kernel), so the
    terminal anchor index is drawn directly from that transition row, no
    discretisation needed for this factor.
  - (V_t, log Y_t): the Heston-plus-Gaussian-compound-Poisson-jump factor.
    The jump component is handled EXACTLY (jump count ~ Poisson(lambda_J*dt),
    summed jump size ~ Normal(N*m_J, N*delta_J^2) given the count -- additive
    separability of compound-Poisson increments is exact, not an
    approximation). Only the continuous (Heston) part uses a discretised
    (correlated, full-truncation Euler) scheme, with many substeps per
    week -- this is NOT the same embedding-validation question flagged for
    the PRIMARY latent-state particle filter in latent_state.py (which
    infers a state from many REAL historical observations, where getting
    the transition law exactly right matters a great deal); here it is a
    short, single-step-ahead FORWARD baseline simulation, where a
    fine-enough Euler discretisation of the same fitted SDE converges to
    the correct conditional law and is reported as such, not hidden as
    if it were exact.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig, CoherentChainBlackAdapter
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.fast_bates_pricer import price_calls_ordinary_bates_batched_V


def simulate_chain_terminal_index(rng: np.random.Generator, chain_config: ChainGeneratorConfig, dt_years: float,
                                   n_paths: int) -> np.ndarray:
    """Exact draw of X_{t+dt}'s anchor index given X_t = initial_index, from
    the chain's own matrix-exponential transition row (no discretisation)."""
    i0 = chain_config.initial_index
    q = CoherentChainBlackAdapter(chain_config).transition_matrix(dt_years)[i0, :]
    q = np.clip(q, 0.0, None)
    q = q / q.sum()
    return rng.choice(len(chain_config.anchors), size=n_paths, p=q)


def simulate_bates_terminal(rng: np.random.Generator, V0: float, heston: HestonParams, jumps: GaussianJumpParams,
                             dt_years: float, n_paths: int, n_substeps: int = 20) -> tuple[np.ndarray, np.ndarray]:
    """(V_T, logY_T) for n_paths independent draws, Y_0=1 (log Y_0=0).
    Diffusion part: correlated full-truncation Euler, n_substeps steps.
    Jump part: exact compound-Poisson (Gaussian jump sizes), applied once
    over the full interval (additive separability from the diffusion part
    is exact for compound-Poisson jumps independent of the Brownian
    drivers)."""
    h = dt_years / n_substeps
    sqrt_h = np.sqrt(h)
    rho = heston.rho
    V = np.full(n_paths, V0, dtype=float)
    logY = np.zeros(n_paths, dtype=float)
    for _ in range(n_substeps):
        z_v = rng.standard_normal(n_paths)
        z_indep = rng.standard_normal(n_paths)
        z_y = rho * z_v + np.sqrt(max(1.0 - rho ** 2, 0.0)) * z_indep
        V_pos = np.maximum(V, 0.0)
        sqrt_V = np.sqrt(V_pos)
        logY += -0.5 * V_pos * h + sqrt_V * sqrt_h * z_y
        V = V + heston.kappa * (heston.theta - V_pos) * h + heston.xi * sqrt_V * sqrt_h * z_v
        V = np.maximum(V, 0.0)

    kappa_J = np.exp(jumps.m_J + 0.5 * jumps.delta_J ** 2) - 1.0
    logY -= jumps.lambda_J * kappa_J * dt_years  # martingale compensator, exact (deterministic, linear in t)

    n_jumps = rng.poisson(lam=max(jumps.lambda_J * dt_years, 0.0), size=n_paths)
    jump_mean = n_jumps * jumps.m_J
    jump_std = np.sqrt(n_jumps) * jumps.delta_J
    jump_sum = rng.normal(loc=jump_mean, scale=np.where(jump_std > 0.0, jump_std, 1e-300))
    jump_sum = np.where(n_jumps > 0, jump_sum, 0.0)
    logY += jump_sum
    return V, logY


def simulate_hedge_pnl_components(rng: np.random.Generator, chain_config: ChainGeneratorConfig,
                                   heston: HestonParams, jumps: GaussianJumpParams, V0: float, price0: float,
                                   strike_pure: float, tau_orig: float, dt_years: float, *, n_paths: int = 4000,
                                   n_substeps: int = 20, n_quad: int = 80, u_max: float = 150.0,
                                   min_remaining_tau: float = 7 / 365.25) -> tuple[np.ndarray, np.ndarray]:
    """Simulate n_paths one-week-forward draws of the SAME fitted Q
    dynamics the model was calibrated under, reprice the SAME fixed-strike
    contract at the simulated terminal state, and return the RAW per-path
    (simulated_option_pnl, spot_move) arrays -- the shared building block
    for both `mc_hedge_baseline` (a fixed hedge ratio's baseline mean/std)
    and `solve_oce_optimal_delta` (optimizing the hedge ratio itself), so
    the same simulated paths are reused rather than re-simulated for each."""
    x = np.asarray(chain_config.anchors, dtype=float)
    i_T = simulate_chain_terminal_index(rng, chain_config, dt_years, n_paths)
    V_T, logY_T = simulate_bates_terminal(rng, V0, heston, jumps, dt_years, n_paths, n_substeps=n_substeps)
    S_rel_T = x[i_T] * np.exp(logY_T)  # relative to S_0=1 at the start of this week

    tau_remaining = max(tau_orig - dt_years, min_remaining_tau)
    K_new = strike_pure / S_rel_T  # re-normalise so "current spot" = 1 again at T, per the pure-units convention

    P_full = CoherentChainBlackAdapter(chain_config).transition_matrix(tau_remaining)  # (n_anchors, n_anchors)
    weights = P_full[i_T, :]  # (n_paths, n_anchors), continuation mixture from each path's own terminal anchor

    n_paths_, n_anchors = weights.shape
    K_grid = (K_new[:, None] / x[None, :]).ravel()
    V_grid = np.repeat(V_T, n_anchors)
    bates_grid = price_calls_ordinary_bates_batched_V(heston, jumps, V_grid, K_grid, tau_remaining,
                                                        n_quad=n_quad, u_max=u_max).reshape(n_paths_, n_anchors)
    component_grid = x[None, :] * bates_grid
    price_T_local = np.sum(weights * component_grid, axis=1)  # price at T, normalised to "spot=1" at T
    price_T = S_rel_T * price_T_local  # back to the ORIGINAL S_0=1 normalisation, matching price0's units

    simulated_option_pnl = price_T - price0
    spot_move_sim = S_rel_T - 1.0
    return simulated_option_pnl, spot_move_sim


@dataclass(frozen=True)
class McHedgeBaseline:
    mu_q: float
    sigma_q: float
    n_paths: int


def mc_hedge_baseline(rng: np.random.Generator, chain_config: ChainGeneratorConfig, heston: HestonParams,
                       jumps: GaussianJumpParams, V0: float, price0: float, strike_pure: float, tau_orig: float,
                       dt_years: float, model_delta: float, *, n_paths: int = 4000, n_substeps: int = 20,
                       n_quad: int = 80, u_max: float = 150.0, min_remaining_tau: float = 7 / 365.25) -> McHedgeBaseline:
    """Apply the SAME discrete delta hedge used on the real data to the
    simulated paths, and return the resulting (mean, std) of the
    model-implied hedged P&L -- the correct baseline against which the
    REALISED hedged P&L should be compared (not literal zero)."""
    simulated_option_pnl, spot_move_sim = simulate_hedge_pnl_components(
        rng, chain_config, heston, jumps, V0, price0, strike_pure, tau_orig, dt_years, n_paths=n_paths,
        n_substeps=n_substeps, n_quad=n_quad, u_max=u_max, min_remaining_tau=min_remaining_tau)
    simulated_hedged = simulated_option_pnl - model_delta * spot_move_sim
    return McHedgeBaseline(mu_q=float(np.mean(simulated_hedged)), sigma_q=float(np.std(simulated_hedged, ddof=1)),
                            n_paths=n_paths)


# ---------------------------------------------------------------------------
# OCE (Optimized Certainty Equivalent) hedge-ratio optimization, per the
# genuine Ben-Tal-Teboulle definition -- NOT the fixed-delta test above.
# rho_gamma(L) = (1/gamma) log E[exp(gamma*L)] (entropic/exponential OCE),
# L(delta) = delta*spot_move - option_pnl (a LOSS: positive = hedge loses
# money), delta* = argmin_delta rho_gamma(L(delta)). This is smooth and
# strictly convex in delta (log-sum-exp of an affine function), so Newton's
# method with the closed-form (softmax-weighted) gradient/Hessian below
# converges in a handful of steps from any starting point.
# ---------------------------------------------------------------------------

RISK_AVERSION_SCALE = 2.0  # documented modelling choice, see module docstring addendum below


def _oce_objective_grad_hess(delta: float, option_pnl: np.ndarray, spot_move: np.ndarray,
                              gamma: float) -> tuple[float, float, float]:
    n = len(option_pnl)
    L = delta * spot_move - option_pnl
    m = np.max(gamma * L)
    w_unnorm = np.exp(gamma * L - m)
    sum_w_unnorm = np.sum(w_unnorm)
    objective = (m + math.log(sum_w_unnorm) - math.log(n)) / gamma  # (1/gamma) log( (1/n) sum exp(gamma*L) )
    w = w_unnorm / sum_w_unnorm  # softmax / exponentially-tilted path weights, numerically stable
    mean_sm = float(np.sum(w * spot_move))
    grad = mean_sm
    var_sm = float(np.sum(w * spot_move ** 2) - mean_sm ** 2)
    hess = gamma * max(var_sm, 1e-300)
    return float(objective), grad, hess


@dataclass(frozen=True)
class OceSolveResult:
    delta_star: float
    gradient_at_star: float
    gradient_at_delta0: float
    gamma: float
    n_iter: int
    converged: bool


def solve_oce_optimal_delta(option_pnl: np.ndarray, spot_move: np.ndarray, delta0: float, *,
                             risk_aversion_scale: float = RISK_AVERSION_SCALE, max_iter: int = 50,
                             tol: float = 1e-10) -> OceSolveResult:
    """Newton's method on the strictly convex entropic-OCE objective.
    gamma is set as risk_aversion_scale / std(option_pnl) -- calibrated to
    the UNHEDGED option P&L's own scale, a fixed property of the data, not
    of delta0 or of the current Newton iterate -- so the objective
    rho_gamma(delta) being minimized is one well-defined function with a
    unique global minimizer regardless of starting point (delta0 only
    selects where Newton's method starts walking from, not a different
    objective; checked in tests/test_real_data_study_q_path_simulator.py by
    verifying several very different starting points all converge to the
    same delta*). This is a documented MODELLING CHOICE
    (risk_aversion_scale=2.0 by default), not a value derived from data --
    a different scale would give a different delta*, though the entropic
    OCE's qualitative behaviour (a well-defined gap from the model's delta)
    is a standard, well-behaved feature of this risk measure, not fitted
    here."""
    baseline_scale = float(np.std(option_pnl, ddof=1))
    gamma = risk_aversion_scale / max(baseline_scale, 1e-12)

    obj0, grad0, _ = _oce_objective_grad_hess(delta0, option_pnl, spot_move, gamma)
    delta = delta0
    obj = obj0
    converged = False
    n_iter = 0
    for n_iter in range(1, max_iter + 1):
        obj, grad, hess = _oce_objective_grad_hess(delta, option_pnl, spot_move, gamma)
        if abs(grad) < tol:
            converged = True
            break
        step = grad / hess
        # Armijo backtracking: a raw Newton step can wildly overshoot when
        # starting far from the optimum (the softmax-weighted Hessian can
        # be tiny out in the tails), so halve the step until the objective
        # actually decreases -- the log-sum-exp objective is convex, so a
        # sufficiently small step always exists and always decreases it.
        new_delta = delta - step
        new_obj, _, _ = _oce_objective_grad_hess(new_delta, option_pnl, spot_move, gamma)
        backtracks = 0
        while (not np.isfinite(new_obj) or new_obj > obj - 1e-4 * step * grad) and backtracks < 60:
            step *= 0.5
            new_delta = delta - step
            new_obj, _, _ = _oce_objective_grad_hess(new_delta, option_pnl, spot_move, gamma)
            backtracks += 1
        delta = new_delta
    obj_final, grad_final, _ = _oce_objective_grad_hess(delta, option_pnl, spot_move, gamma)
    if abs(grad_final) < 1e-6:
        converged = True
    return OceSolveResult(delta_star=float(delta), gradient_at_star=float(grad_final), gradient_at_delta0=float(grad0),
                           gamma=float(gamma), n_iter=n_iter, converged=converged)
