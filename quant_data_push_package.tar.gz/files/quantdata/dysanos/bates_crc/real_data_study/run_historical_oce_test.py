r"""Step 4a(3): the held-out delta-hedge OCE/challenger test. HELD-OUT
split only (2025-01-03 .. 2025-08-28) -- never touched by fitting.

For a fixed representative near-ATM, ~1-month contract (nearest available
match each week), computes the REALISED weekly option P&L from actual
quoted mid-prices, the MODEL's delta (finite difference on the fitted
Q-price w.r.t. spot) at the start of each week, and the resulting
delta-hedged P&L series -- then runs arbitrage_diagnostics.delta_hedge_challenger_test.

Run (needs QUANTDATA_TEST_MODE=1; daily_cache_loader reads pre-computed
files directly):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/run_historical_oce_test.py
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.arbitrage_diagnostics import delta_hedge_challenger_test
from quantdata.dysanos.bates_crc.real_data_study.chain_pricer import price_calls_chain_bates
from quantdata.dysanos.bates_crc.real_data_study.daily_cache_loader import load_day_from_cache
from quantdata.dysanos.bates_crc.real_data_study.run_historical_calibration import OUT_PATH

HERE = Path(__file__).resolve().parent
RESULT_PATH = HERE / "report_historical" / "data" / "oce_challenger_result.json"

TARGET_TENOR = 1 / 12
TARGET_MONEYNESS = 1.0
SPOT_BUMP_REL = 0.01


def _json_default(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return str(obj)


def _nearest_contract(book, target_tenor: float, target_moneyness: float):
    diffs = np.abs(book.expiries - target_tenor)
    ei = int(np.argmin(diffs))
    strikes = book.strikes[ei]
    bids, asks = book.bids[ei], book.asks[ei]
    sane = np.isfinite(bids) & np.isfinite(asks) & (asks > bids)
    if not np.any(sane):
        return None
    log_k = np.log(strikes)
    kdiffs = np.where(sane, np.abs(log_k - np.log(target_moneyness)), np.inf)
    si = int(np.argmin(kdiffs))
    return dict(expiry_years=float(book.expiries[ei]), strike=float(strikes[si]),
                mid=float(0.5 * (bids[si] + asks[si])), spot_ref=book.spot_ref)


def main() -> None:
    with open(OUT_PATH) as f:
        rows = json.load(f)
    held_out = [r for r in rows if r["split"] == "held_out" and "dlv_bates" in r
                and r["dlv_bates"].get("converged")]
    held_out.sort(key=lambda r: r["date"])
    print(f"{len(held_out)} held-out dates with converged fits", flush=True)

    spot_moves, model_deltas, option_pnls = [], [], []
    for i in range(len(held_out) - 1):
        r = held_out[i]
        y, m, d = (int(x) for x in r["date"].split("-"))
        from datetime import date
        book_t = load_day_from_cache("SPX", date(y, m, d))
        c_t = _nearest_contract(book_t, TARGET_TENOR, TARGET_MONEYNESS)

        y2, m2, d2 = (int(x) for x in held_out[i + 1]["date"].split("-"))
        book_t1 = load_day_from_cache("SPX", date(y2, m2, d2))
        elapsed = (date(y2, m2, d2) - date(y, m, d)).days / 365.25
        c_t1 = _nearest_contract(book_t1, max(c_t["expiry_years"] - elapsed, 7 / 365.25), TARGET_MONEYNESS)
        if c_t is None or c_t1 is None:
            continue

        b = r["dlv_bates"]
        heston = HestonParams(**b["heston"])
        jumps = GaussianJumpParams(**b["jumps"])
        anchors = tuple(b["anchors"])
        chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=len(anchors) // 2,
                                             kappa=b["chain_kappa"], sigma_y=0.0)
        k = np.array([c_t["strike"]])
        tau = np.array([c_t["expiry_years"]])
        p0 = price_calls_chain_bates(chain_config, heston, jumps, b["V_t"], k, tau, n_quad=100, u_max=150.0)[0]
        k_up = np.array([c_t["strike"] / (1 + SPOT_BUMP_REL)])  # pure strike scales inversely with a spot bump
        p_up = price_calls_chain_bates(chain_config, heston, jumps, b["V_t"], k_up, tau, n_quad=100, u_max=150.0)[0]
        model_delta = float((p_up - p0) / SPOT_BUMP_REL)  # d(price)/d(relative spot move), pure units

        realised_spot_move = (book_t1.spot_ref - book_t.spot_ref) / book_t.spot_ref
        realised_option_pnl_pure = c_t1["mid"] - c_t["mid"]  # approximation: ignores strike/tenor drift between weeks

        spot_moves.append(realised_spot_move)
        model_deltas.append(model_delta)
        option_pnls.append(realised_option_pnl_pure)

    spot_moves = np.array(spot_moves)
    model_deltas = np.array(model_deltas)
    option_pnls = np.array(option_pnls)
    print(f"{len(spot_moves)} usable held-out weekly steps", flush=True)

    if len(spot_moves) >= 4:
        report = delta_hedge_challenger_test(spot_moves, model_deltas, option_pnls)
        out = dict(n_steps=report.n_steps, mean_hedged_pnl=report.mean_hedged_pnl,
                   std_hedged_pnl=report.std_hedged_pnl, t_stat_naive=report.t_stat_naive,
                   t_stat_newey_west=report.t_stat_newey_west,
                   effective_sample_size=report.effective_sample_size,
                   median_hedged_pnl=report.median_hedged_pnl, n_pos=report.n_pos, n_neg=report.n_neg,
                   sign_test_pvalue=report.sign_test_pvalue,
                   runs_test_statistic=report.runs_test_statistic, runs_test_pvalue=report.runs_test_pvalue,
                   note=report.note)
    else:
        out = dict(status="too few usable held-out steps for a meaningful test", n_usable=len(spot_moves))

    with open(RESULT_PATH, "w") as f:
        json.dump(out, f, indent=2, default=_json_default)
    print(out, flush=True)
    print("Wrote", RESULT_PATH, flush=True)


if __name__ == "__main__":
    main()
