# The physical law P and pricing law Q: explicit specification

This document fixes, BEFORE any historical fitting is run, exactly what is
being estimated and why it is a valid equivalent-measure change. Written to
satisfy Historical Simulator task point 2 precisely: explicit P and Q,
`b^P-b^Q=Sigma*lambda` for the diffusion component with a stated sign
convention, jumps/resets via likelihood ratios and support conditions, both
P and Q reset laws inside the admissible region, no silent assumption that
dy2's AR(1) IS this Q model, and an explicit, validated continuous-time
embedding rather than an unjustified inference from weekly covariances.

## 1. State and what is already fixed under Q (cite, do not re-derive)

The full state is `(X_t, V_t, Z_t, R_t)` where `X_t` is the coherent chain
position, `V_t` the Heston variance, `Z_t = log Y_t` the Bates log-factor,
and `R_t = (n_t, theta-path, jump-params-path, b_used)` the discrete
reserve/reset state from `reserve_crc.BcrcState`.

Already established (prior tasks, re-cited not re-derived):

- **X_t** is an EXACT zero-drift martingale under Q for ANY `kappa>0` and
  ANY anchor grid (birth-death generator `A`, `E^Q[X_T|F_t]=X_t` exactly;
  exact Chapman-Kolmogorov `P(tau1)P(tau2)=P(tau1+tau2)`). No embedding
  question arises: the exact transition matrix `expm(A*tau)` is used
  directly, at any horizon, not approximated from a discretised SDE.
- **(V_t, Z_t)** jointly solve the Heston+Gaussian-jump SDE under Q:
  ```
  dV_t = kappa*(theta_n - V_t) dt + xi*sqrt(V_t) dW^Q_{V,t}
  dZ_t = -V_t/2 dt - lambda_bar*kappa_bar dt + sqrt(V_t) dW^Q_{Z,t} + dJ^Q_t
  ```
  with `d<W^Q_V,W^Q_Z>_t = rho dt`, `theta_n` the CURRENT reserve-state
  target variance (piecewise-constant, jumps only at reset times), and
  `J^Q_t` a COMPOUND POISSON process driven by the DOMINATING ENVELOPE
  `nu-bar` (NOT the current jump parameters `p_n` -- this is the AUDIT.md
  Sec. 8 cancellation identity: the current jump parameters cancel out of
  the priced dynamics exactly, so the actual Q jump law is always the
  fixed envelope, compensated by `kappa_bar = E^{nu-bar}[e^z-1]`).
- **R_t** evolves deterministically except at scheduled reset times, where
  `Delta_n` is chosen subject to `reserve_crc.admissible_delta_interval`
  (price-preservation constraint, already proven exact).

## 2. A structural fact that simplifies the risk-premium specification

The reserve correction `ell_s(u)` is a DETERMINISTIC function of calendar
time `s` given the REALISED reset history (it depends on `(theta-path,
b_used, reset_times)` only, never on the random state `(V_t,Z_t,X_t)`
itself). Consequently
```
Phi_t(u,T) = Phi^{Heston+jump}_t(u,T; nu-bar) * exp( integral_t^T ell_s(u) ds )
```
factors into an ORDINARY (reserve-free) Bates conditional characteristic
function times a purely deterministic multiplicative correction. A
deterministic quantity is unaffected by an equivalent change of measure
(Girsanov only reweights STOCHASTIC drift). **Therefore the P/Q risk-premium
question below applies only to the genuinely random components -- `(V_t,
Z_t)`'s diffusion, the jump law, and `X_t`'s transition rate -- and NOT to
the reserve correction itself**, which is identical under P and Q by
construction. This is stated explicitly here because it would be easy to
mistakenly try to assign a risk premium to the reserve term; there is none
to assign.

## 3. The diffusion risk premium: `b^P - b^Q = Sigma*lambda`

**Sign convention** (stated explicitly, per the task's requirement): write
the Q-dynamics as `dX_t = b^Q(X_t) dt + Sigma(X_t) dW^Q_t`. Girsanov's
theorem gives `dW^Q_t = dW^P_t - lambda(X_t) dt` for a market-price-of-risk
process `lambda`, so that under P,
```
dX_t = b^Q(X_t) dt + Sigma(X_t)(dW^P_t - lambda(X_t) dt) ... rearranged ...
dX_t = [b^Q(X_t) - Sigma(X_t) lambda(X_t)] dt + Sigma(X_t) dW^P_t
```
i.e. `b^P = b^Q - Sigma*lambda` under THIS sign convention (lambda defined
via `dW^Q = dW^P - lambda dt`), equivalently `b^P - b^Q = -Sigma*lambda`.
The task's stated relation `b^P - b^Q = Sigma*lambda` corresponds to the
OPPOSITE sign convention, `dW^Q_t = dW^P_t + lambda(X_t) dt`; both are
standard in the literature (compare Heston 1993's own convention to e.g.
Pan 2002). **This document adopts `dW^Q_t = dW^P_t + lambda(X_t) dt`, i.e.
`b^P = b^Q - Sigma*lambda` becomes `b^P = b^Q + Sigma*lambda` is NOT what
falls out -- working it through**: `dX_t = b^Q dt + Sigma(dW^P+lambda dt) =
(b^Q+Sigma*lambda) dt + Sigma dW^P_t`, so **`b^P = b^Q + Sigma*lambda`,
i.e. `b^P - b^Q = Sigma*lambda`, exactly the task's stated relation**, under
the convention `dW^Q_t = dW^P_t + lambda(X_t) dt`. Used consistently below.

### 3a. Variance risk premium (extended-affine / completely-affine form)

Standard choice (Pan 2002; Broadie-Chernov-Johannes 2007), chosen because
it keeps P ALSO an exact CIR process (closed-form P-transition, needed for
the embedding requirement in Sec. 5):
```
lambda_V(V_t) = eta * sqrt(V_t) / xi   (eta: one scalar parameter, fitted)
```
so `Sigma_V = xi*sqrt(V_t)` and `Sigma_V * lambda_V = eta*V_t`, giving
```
b^P_V = kappa*(theta_n - V_t) + eta*V_t = (kappa-eta)*(theta_n*kappa/(kappa-eta) - V_t)
```
i.e. P is CIR with `kappa_P = kappa - eta`, `theta_P = theta_n*kappa/(kappa-eta)`
(same `xi`). Requires `kappa_P>0` for P to remain a well-posed mean-reverting
CIR process -- checked explicitly after fitting `eta`, not assumed.

### 3b. Equity (log-price) risk premium

```
lambda_Z = eta_Z / sqrt(V_t) * V_t = eta_Z * sqrt(V_t)   (eta_Z: scalar, fitted)
```
(a constant-Sharpe-ratio-type specification, standard for a stochastic-vol
log-price process), giving
```
b^P_Z = -V_t/2 - lambda_bar*kappa_bar + Sigma_Z*lambda_Z = -V_t/2 - lambda_bar*kappa_bar + eta_Z*V_t
```
with `Sigma_Z = sqrt(V_t)`.

## 4. Jumps and discrete resets: likelihood ratios and support conditions

**Jump law.** Under Q the jump law is the envelope `nu-bar = N(0, s_star^2)`
scaled by intensity `Lambda*R_*` (Sec. 1). Under P, jump intensity
`lambda_J^P` and jump-size law `N(m_J^P, delta_J^{P,2})` are ALLOWED to
differ (historical jump risk premium), subject to:
- **Support condition**: both P and Q jump-size laws are Gaussian on all of
  R -- automatically mutually absolutely continuous (equivalent) for any
  `delta_J^P, delta_J^Q > 0`, since a Gaussian density is everywhere
  positive. No additional condition needed for the SIZE law.
- **Intensity condition**: `lambda_J^P` and the Q envelope intensity must
  both be finite and nonnegative (already enforced by construction); this
  alone suffices for compound-Poisson equivalence.
- **Explicit likelihood ratio** (compound-Poisson Girsanov, standard form):
  for a path with jump times `tau_1<...<tau_n` in `[t,T]` and sizes
  `z_1,...,z_n`,
  ```
  dP/dQ |_{[t,T]} = exp( (lambda_J^Q - lambda_J^P)(T-t) ) * prod_i [ lambda_J^P f^P(z_i) / (lambda_J^Q f^Q(z_i)) ]
  ```
  where `f^P, f^Q` are the Gaussian jump-size densities. This is the exact,
  finite-dimensional density used in Sec. 6's observation likelihood.

**Reset law.** The Q "reset law" is not a probability distribution over
`Delta_n` at all -- it is the DETERMINISTIC admissibility constraint
(`reserve_crc.admissible_delta_interval`): Q-pricing only needs to know
WHICH post-reset state obtains, conditional on the realised choice, not a
probability over choices. The P reset law, by contrast, IS a genuine fitted
probability distribution over `Delta_n` (how the recalibrator historically
tends to move theta) -- Sec. 5. **Equivalence requirement**: the P
proposal law must assign zero probability outside, and (to avoid a
degenerate/non-identified estimation) positive density everywhere inside,
the SAME admissible interval the Q construction uses -- enforced directly
by construction (Sec. 5's proposal law is a truncated distribution on
exactly that interval).

## 5. The admissible theta-reset proposal dynamics (fitted, not assumed)

A location-scale distribution on `Delta_n`, TRUNCATED to
`[theta_min-theta_prev, min(r_n,theta_max-theta_prev)]` (the exact Q
admissible interval), fitted by MLE on the SMOOTHED (Sec. 6) historical
`Delta_theta` path at each identified reset event:
```
Delta_n | F_{t_n-} ~ TruncatedNormal(mu_delta, sigma_delta^2; [lo_n, hi_n])
```
`(mu_delta, sigma_delta)` are the two fitted parameters (richer families
were considered and rejected for this first pass as overfitting a ~5-10
reset-event sample -- see Sec. 7's scope note). This directly operationalises
"admissible theta-reset proposal dynamics," fit from data, not asserted.

## 6. Observation model: evolution explains observations, not day-by-day overwriting

Per task point 1's explicit instruction, the per-date CROSS-SECTIONAL
calibration (`chain_bates_calibration.calibrate_chain_bates`, already
built) is treated as a NOISY OBSERVATION of the true latent state, not the
latent state itself:
```
hat_theta_t = theta_t^{true} + eps_t,   eps_t ~ N(0, sigma_obs^2)
hat_V_t     = V_t^{true} * exp(eta_t),  eta_t ~ N(0, tau_obs^2)   (log-normal, V_t>0)
```
`(sigma_obs, tau_obs)` are estimated from the TRAIN split's residuals
against a first-pass smoother (Sec. 7), not assumed a priori. This is what
makes "model evolution explains observations" operational: the LATENT path
is the SMOOTHED state, and `apply_reset` is applied to the LATENT path's
own identified jumps, never directly to two consecutive raw calibration
points.

## 7. The continuous-time embedding (validated, not inferred from a weekly covariance alone)

Per the task's explicit caution, weekly-sampled innovations are NOT used to
infer a Brownian rank or diffusion coefficient directly. Instead:
- **V_t**: the EXACT CIR transition law is used --
  `V_{t+Delta} | V_t ~ c * NoncentralChiSquared(df, lambda_ncp)` with the
  standard closed-form `(c, df, lambda_ncp)` in terms of `(kappa,theta,xi,Delta)`
  (Cox-Ingersoll-Ross 1985) -- NOT a Gaussian/Euler approximation. This is
  the "specified and validated embedding": the discrete-time (weekly)
  observation law is the EXACT image of the continuous-time SDE at lag
  `Delta`=1 week, not an ad hoc discretisation.
- **X_t**: exact `expm(A*Delta)` transition, as already used throughout.
- **theta_t, jump-params_t**: piecewise-constant between resets (no SDE,
  no embedding question).
- A **bootstrap particle filter** (using the EXACT CIR transition as the
  proposal/transition kernel, and the observation model of Sec. 6 as the
  weight function) is used for latent `V_t` filtering/smoothing across the
  weekly path -- not a linear-Gaussian Kalman approximation, specifically
  because the exact transition is available and non-Gaussian.

## 8. Chain X_t's P-dynamics and the independence restriction

X_t has no independent risk-premium story beyond what Sec. 3 already
assigns to `(V_t,Z_t)`: under this model, X represents the orthogonal,
Q-martingale latent mixture factor, and `thm:dlv-bates` requires X
independent of Y UNDER Q. **Respecting the information restriction**: a
joint calibration policy that lets X's OWN parameters (`kappa_chain`,
anchor width) depend on information that would make X and Y dependent
under Q is NOT implemented -- `kappa_chain` is fit per-date exactly as
before (cross-sectionally, from the SAME day's book, independent of any
other day's Y-path), and no cross-coupling term between X's P-drift and
Y's realised path is introduced. If the historical data were found to
require such coupling to fit well, the correct response (per the task's
explicit instruction) is to REJECT that policy, not to keep the separated
pricing formula while secretly coupling the P-fit -- this is checked for
explicitly in Sec. 9 of the companion implementation notes
(`run_historical_latent_state.py` docstring) and reported honestly if it
occurs.
