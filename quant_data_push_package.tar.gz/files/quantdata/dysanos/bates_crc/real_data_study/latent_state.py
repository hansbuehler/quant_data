r"""Step 2 of the Historical Simulator task: latent-state inference from the
noisy per-date cross-sectional calibrations (run_historical_calibration.py),
per HISTORICAL_PQ_SPECIFICATION.md.

Two different smoothing devices are used, matched to the two different
TRUE underlying processes (not one generic smoother applied blindly):

- V_t (Heston variance): a genuine diffusion under Q, with a KNOWN EXACT
  transition law (noncentral chi-squared, Cox-Ingersoll-Ross 1985). A
  bootstrap particle filter uses that EXACT transition as its propagation
  kernel -- this is the "specified and validated embedding" the task
  requires, not a Gaussian/Euler approximation of weekly innovations.
- theta_t (the reserve's recalibration target): piecewise CONSTANT between
  discrete reset events, not a diffusion at all. Total-variation (TV)
  denoising (a convex QP, solved exactly via cvxpy) separates genuine level
  changes (candidate resets) from observation noise, respecting that
  structure -- a Kalman/particle smoother built for a diffusion would be
  the wrong tool here.

Observation noise (sigma_obs for theta, tau_obs for log V) is estimated
from each smoother's own residuals on the TRAIN split only, never touching
validation/held-out, per the chronological-split discipline.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.stats import ncx2

from quantdata.dysanos.bates_crc.real_data_study import config as cfg

HERE = Path(__file__).resolve().parent
DATA = HERE / "report" / "data"


def load_raw_path(path: Path = DATA / "historical_calibration.json") -> list[dict]:
    with open(path) as f:
        rows = json.load(f)
    return [r for r in rows if "dlv_bates" in r]


# ---------------------------------------------------------------------------
# TV denoising (theta_t, and the jump-parameter paths): exact convex QP.
# ---------------------------------------------------------------------------


def tv_denoise(y: np.ndarray, lam: float, weights: np.ndarray | None = None) -> np.ndarray:
    """argmin_x 0.5*sum(w*(x-y)^2) + lam*sum(|x[i+1]-x[i]|), solved exactly
    via cvxpy (a standard convex QP -- the exact TV-denoised path, not an
    iterative approximation). `weights` (default all-ones) lets a point be
    down-weighted (e.g. 0 to mask it out entirely for cross-validation,
    Sec. choose_tv_lambda_by_cv) without needing a separate code path."""
    import cvxpy as cp

    n = len(y)
    w = np.ones(n) if weights is None else np.asarray(weights, dtype=float)
    x = cp.Variable(n)
    obj = 0.5 * cp.sum(cp.multiply(w, cp.square(x - y))) + lam * cp.sum(cp.abs(x[1:] - x[:-1]))
    prob = cp.Problem(cp.Minimize(obj))
    prob.solve(solver=cp.CLARABEL)
    return np.asarray(x.value)


def choose_tv_lambda_by_cv(y: np.ndarray, lam_grid: tuple, *, n_folds: int = 5, seed: int = 0) -> dict:
    """Proper smoothing-parameter selection via MASKED cross-validation:
    for each lambda, repeatedly mask out a random ~1/n_folds subset of
    points (set their weight to 0, so TV-denoising must interpolate over
    them using ONLY the other points), and score the masked points'
    interpolated value against their OWN (held-out, never used to fit)
    true value. This is the standard, leakage-free way to tune a
    denoising parameter without ground truth -- unlike naively comparing a
    lambda's smoothed value to the SAME raw data it was smoothed from
    (which trivially favours minimal smoothing and was the bug in an
    earlier version of this function, now replaced)."""
    rng = np.random.default_rng(seed)
    n = len(y)
    scores: dict[float, float] = {}
    for lam in lam_grid:
        fold_errors = []
        for fold in range(n_folds):
            mask_idx = rng.choice(n, size=max(1, n // (2 * n_folds)), replace=False)
            weights = np.ones(n)
            weights[mask_idx] = 0.0
            smoothed = tv_denoise(y, lam, weights=weights)
            fold_errors.append(np.mean((smoothed[mask_idx] - y[mask_idx]) ** 2))
        scores[lam] = float(np.mean(fold_errors))
    best_lam = min(scores, key=scores.get)
    return dict(chosen_lambda=best_lam, scores=scores, method="masked_cross_validation")


def detect_changepoints(smoothed: np.ndarray, tol: float) -> list[int]:
    diffs = np.abs(np.diff(smoothed))
    return [i + 1 for i, d in enumerate(diffs) if d > tol]


# ---------------------------------------------------------------------------
# Exact CIR transition + bootstrap particle filter for V_t.
# ---------------------------------------------------------------------------


def cir_exact_sample(rng: np.random.Generator, V0: np.ndarray, kappa: float, theta: float, xi: float,
                      dt: float) -> np.ndarray:
    """V_{t+dt} | V_t, drawn EXACTLY from the CIR transition law
    (Cox-Ingersoll-Ross 1985): V_{t+dt} = c * NoncentralChiSquared(df, nc),
    c = xi^2*(1-exp(-kappa*dt))/(4*kappa), df = 4*kappa*theta/xi^2,
    nc = V0*4*kappa*exp(-kappa*dt) / (xi^2*(1-exp(-kappa*dt)))."""
    c = xi ** 2 * (1.0 - np.exp(-kappa * dt)) / (4.0 * kappa)
    df = 4.0 * kappa * theta / xi ** 2
    nc = V0 * 4.0 * kappa * np.exp(-kappa * dt) / (xi ** 2 * (1.0 - np.exp(-kappa * dt)))
    draws = np.atleast_1d(ncx2.rvs(df, nc, random_state=rng))
    return c * draws


@dataclass(frozen=True)
class ParticleFilterResult:
    dates: list
    filtered_mean: np.ndarray
    filtered_std: np.ndarray
    ess: np.ndarray  # effective sample size per step -- diagnoses degeneracy


def particle_filter_V(dates: list, V_hat: np.ndarray, dt_years: np.ndarray, kappa: float, theta_path: np.ndarray,
                       xi: float, tau_obs: float, *, n_particles: int = 4000, seed: int = 0) -> ParticleFilterResult:
    """Bootstrap particle filter for V_t using the EXACT CIR transition
    (cir_exact_sample) as the proposal, and the log-normal observation
    model hat_V_t = V_t*exp(noise), noise~N(0,tau_obs^2), as the weight
    function. theta_path is the (already reset-aware) piecewise-constant
    target variance driving each step's transition -- NOT re-estimated
    here, taken from the theta_t TV-denoised path."""
    rng = np.random.default_rng(seed)
    n = len(V_hat)
    particles = np.full(n_particles, max(V_hat[0], 1e-6))
    means, stds, ess = np.zeros(n), np.zeros(n), np.zeros(n)
    means[0], stds[0], ess[0] = particles.mean(), particles.std(), n_particles

    for t in range(1, n):
        particles = cir_exact_sample(rng, particles, kappa, theta_path[t], xi, dt_years[t])
        particles = np.maximum(particles, 1e-10)
        log_ratio = np.log(np.maximum(V_hat[t], 1e-10)) - np.log(particles)
        log_w = -0.5 * (log_ratio / tau_obs) ** 2
        log_w -= log_w.max()
        w = np.exp(log_w)
        w /= w.sum()
        ess[t] = 1.0 / np.sum(w ** 2)
        means[t] = np.sum(w * particles)
        stds[t] = np.sqrt(np.sum(w * (particles - means[t]) ** 2))
        idx = rng.choice(n_particles, size=n_particles, p=w)
        particles = particles[idx]

    return ParticleFilterResult(dates=dates, filtered_mean=means, filtered_std=stds, ess=ess)
