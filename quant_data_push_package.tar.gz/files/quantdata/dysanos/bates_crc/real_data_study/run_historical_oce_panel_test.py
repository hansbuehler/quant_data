r"""Step 4a(3), cross-sectional expansion: the same held-out delta-hedge
challenger idea as run_historical_oce_test.py, but (a) across a small
representative panel of contracts per week instead of one, and (b) scored
against a Monte-Carlo-simulated Q-implied baseline (q_path_simulator.py)
instead of literal zero -- see that module's docstring and
arbitrage_diagnostics.pool_zscores_by_date's docstring for why both
changes are needed: a single linear delta does not span jump risk and
discrete rebalancing of ANY nonlinear position leaves a residual whose
Q-expectation is a property of the model, not automatically zero; and
contracts on the same date are not independent trials, so pooling must be
done by date-level clustering, not naively across all contract-weeks.

Also solves, per contract-week, for the genuine OCE-optimal hedge ratio
(q_path_simulator.solve_oce_optimal_delta, entropic risk measure) using
the SAME simulated paths, and reports the gap between that and the
model's own finite-difference Q-delta -- the model's delta was never
chosen to minimize this risk measure, so a nonzero gap is expected; the
question is its sign, size, and whether re-hedging the REAL data with the
OCE-optimal ratio instead changes the held-out conclusion.

HELD-OUT split only (2025-01-03 .. 2025-08-28), never touched by fitting.

Run (needs QUANTDATA_TEST_MODE=1; daily_cache_loader reads pre-computed
files directly):
    QUANTDATA_TEST_MODE=1 .venv312/bin/python \
        quantdata/dysanos/bates_crc/real_data_study/run_historical_oce_panel_test.py
"""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import numpy as np

from quantdata.dysanos.bates_crc.comparison_interface import ChainGeneratorConfig
from quantdata.dysanos.bates_crc.heston_riccati import GaussianJumpParams, HestonParams
from quantdata.dysanos.bates_crc.real_data_study.arbitrage_diagnostics import delta_hedge_challenger_test, pool_zscores_by_date
from quantdata.dysanos.bates_crc.real_data_study.chain_pricer import price_calls_chain_bates
from quantdata.dysanos.bates_crc.real_data_study.daily_cache_loader import load_day_from_cache
from quantdata.dysanos.bates_crc.real_data_study.q_path_simulator import simulate_hedge_pnl_components, solve_oce_optimal_delta
from quantdata.dysanos.bates_crc.real_data_study.run_historical_calibration import OUT_PATH
from quantdata.dysanos.bates_crc.real_data_study.run_historical_oce_test import _nearest_contract

HERE = Path(__file__).resolve().parent
RESULT_PATH = HERE / "report_historical" / "data" / "oce_panel_result.json"
GAP_RESULT_PATH = HERE / "report_historical" / "data" / "oce_gap_result.json"

MONEYNESS_TARGETS = (0.95, 1.0, 1.05)
TENOR_TARGETS = (1 / 12, 3 / 12)
SPOT_BUMP_REL = 0.01
N_MC_PATHS = 4000
N_MC_SUBSTEPS = 20
MC_SEED = 2026


def _json_default(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return str(obj)


def main() -> None:
    with open(OUT_PATH) as f:
        rows = json.load(f)
    held_out = [r for r in rows if r["split"] == "held_out" and "dlv_bates" in r
                and r["dlv_bates"].get("converged")]
    held_out.sort(key=lambda r: r["date"])
    print(f"{len(held_out)} held-out dates with converged fits", flush=True)

    rng = np.random.default_rng(MC_SEED)
    z_by_date: dict[str, list[float]] = {}
    gap_by_date: dict[str, list[float]] = {}
    realized_oce_hedged_by_date: dict[str, list[float]] = {}
    n_contract_weeks_attempted = 0
    n_contract_weeks_usable = 0
    n_oce_converged = 0

    for i in range(len(held_out) - 1):
        r = held_out[i]
        y, m, d = (int(x) for x in r["date"].split("-"))
        book_t = load_day_from_cache("SPX", date(y, m, d))

        y2, m2, d2 = (int(x) for x in held_out[i + 1]["date"].split("-"))
        book_t1 = load_day_from_cache("SPX", date(y2, m2, d2))
        elapsed = (date(y2, m2, d2) - date(y, m, d)).days / 365.25

        b = r["dlv_bates"]
        heston = HestonParams(**b["heston"])
        jumps = GaussianJumpParams(**b["jumps"])
        anchors = tuple(b["anchors"])
        chain_config = ChainGeneratorConfig(anchors=anchors, initial_index=len(anchors) // 2,
                                             kappa=b["chain_kappa"], sigma_y=0.0)
        V0 = b["V_t"]

        date_zs = []
        date_gaps = []
        date_oce_hedged = []
        for tenor_target in TENOR_TARGETS:
            for moneyness_target in MONEYNESS_TARGETS:
                n_contract_weeks_attempted += 1
                c_t = _nearest_contract(book_t, tenor_target, moneyness_target)
                if c_t is None:
                    continue
                c_t1 = _nearest_contract(book_t1, max(c_t["expiry_years"] - elapsed, 7 / 365.25), moneyness_target)
                if c_t1 is None:
                    continue

                k = np.array([c_t["strike"]])
                tau = np.array([c_t["expiry_years"]])
                p0 = price_calls_chain_bates(chain_config, heston, jumps, V0, k, tau, n_quad=100, u_max=150.0)[0]
                k_up = np.array([c_t["strike"] / (1 + SPOT_BUMP_REL)])
                p_up = price_calls_chain_bates(chain_config, heston, jumps, V0, k_up, tau, n_quad=100,
                                                u_max=150.0)[0]
                model_delta = float((p_up - p0) / SPOT_BUMP_REL)

                realised_spot_move = (book_t1.spot_ref - book_t.spot_ref) / book_t.spot_ref
                realised_option_pnl = c_t1["mid"] - c_t["mid"]
                realised_hedged = realised_option_pnl - model_delta * realised_spot_move

                sim_option_pnl, sim_spot_move = simulate_hedge_pnl_components(
                    rng, chain_config, heston, jumps, V0, float(p0), strike_pure=c_t["strike"],
                    tau_orig=float(c_t["expiry_years"]), dt_years=elapsed, n_paths=N_MC_PATHS,
                    n_substeps=N_MC_SUBSTEPS)
                sim_hedged = sim_option_pnl - model_delta * sim_spot_move
                mu_q, sigma_q = float(np.mean(sim_hedged)), float(np.std(sim_hedged, ddof=1))
                if sigma_q <= 0.0 or not np.isfinite(sigma_q):
                    continue
                z = (realised_hedged - mu_q) / sigma_q
                date_zs.append(float(z))
                n_contract_weeks_usable += 1

                oce = solve_oce_optimal_delta(sim_option_pnl, sim_spot_move, delta0=model_delta)
                if oce.converged:
                    n_oce_converged += 1
                    date_gaps.append(oce.delta_star - model_delta)
                    date_oce_hedged.append(realised_option_pnl - oce.delta_star * realised_spot_move)

        if date_zs:
            z_by_date[r["date"]] = date_zs
        if date_gaps:
            gap_by_date[r["date"]] = date_gaps
            realized_oce_hedged_by_date[r["date"]] = date_oce_hedged

    print(f"{n_contract_weeks_usable}/{n_contract_weeks_attempted} contract-weeks usable, "
          f"across {len(z_by_date)} dates", flush=True)

    if len(z_by_date) >= 4:
        report = pool_zscores_by_date(z_by_date)
        out = dict(n_contract_weeks=report.n_contract_weeks, n_dates=report.n_dates, mean_z=report.mean_z,
                   t_stat_naive_contract_level=report.t_stat_naive_contract_level,
                   date_mean_z=report.date_mean_z, t_stat_newey_west_by_date=report.t_stat_newey_west_by_date,
                   effective_sample_size_dates=report.effective_sample_size_dates,
                   n_pos_dates=report.n_pos_dates, n_neg_dates=report.n_neg_dates,
                   sign_test_pvalue_by_date=report.sign_test_pvalue_by_date,
                   runs_test_statistic_by_date=report.runs_test_statistic_by_date,
                   runs_test_pvalue_by_date=report.runs_test_pvalue_by_date,
                   note=report.note, z_by_date=z_by_date,
                   contract_panel=dict(moneyness_targets=list(MONEYNESS_TARGETS), tenor_targets=list(TENOR_TARGETS),
                                        n_mc_paths=N_MC_PATHS, n_mc_substeps=N_MC_SUBSTEPS))
    else:
        out = dict(status="too few usable held-out dates for a meaningful panel test", n_dates=len(z_by_date))

    with open(RESULT_PATH, "w") as f:
        json.dump(out, f, indent=2, default=_json_default)
    print({k: v for k, v in out.items() if k != "z_by_date"}, flush=True)
    print("Wrote", RESULT_PATH, flush=True)

    print(f"{n_oce_converged}/{n_contract_weeks_usable} OCE solves converged", flush=True)
    if len(gap_by_date) >= 4:
        gap_report = pool_zscores_by_date(gap_by_date)  # generic date-clustered pooling, reused for the gap too
        # date-averaged (not naively pooled across all 192 contract-weeks, for the same clustering reason as above)
        date_avg_oce_hedged = np.array([np.mean(v) for v in realized_oce_hedged_by_date.values()])
        rehedge_report = delta_hedge_challenger_test(np.zeros_like(date_avg_oce_hedged),
                                                       np.zeros_like(date_avg_oce_hedged), date_avg_oce_hedged)
        gap_out = dict(
            n_contract_weeks=gap_report.n_contract_weeks, n_dates=gap_report.n_dates,
            mean_gap=gap_report.mean_z, t_stat_naive_contract_level=gap_report.t_stat_naive_contract_level,
            date_mean_gap=gap_report.date_mean_z, t_stat_newey_west_by_date=gap_report.t_stat_newey_west_by_date,
            effective_sample_size_dates=gap_report.effective_sample_size_dates,
            n_pos_dates=gap_report.n_pos_dates, n_neg_dates=gap_report.n_neg_dates,
            sign_test_pvalue_by_date=gap_report.sign_test_pvalue_by_date,
            runs_test_pvalue_by_date=gap_report.runs_test_pvalue_by_date,
            risk_aversion_scale=2.0,
            rehedged_with_oce_delta=dict(
                n_steps=rehedge_report.n_steps, mean_hedged_pnl=rehedge_report.mean_hedged_pnl,
                median_hedged_pnl=rehedge_report.median_hedged_pnl,
                t_stat_newey_west=rehedge_report.t_stat_newey_west,
                n_pos=rehedge_report.n_pos, n_neg=rehedge_report.n_neg,
                sign_test_pvalue=rehedge_report.sign_test_pvalue,
            ),
            note=("delta_star (entropic OCE, gamma=risk_aversion_scale/std(option_pnl)) minus the model's own "
                  "finite-difference Q-delta, per contract-week, pooled by date-level clustering (same method as "
                  "the z-score panel). 'rehedged_with_oce_delta' re-runs the realised-data hedge test using "
                  "delta_star in place of the model's delta, on the contract-panel's hedged P&L averaged WITHIN "
                  "each date first (not naively pooled across all contract-weeks, for the same clustering reason "
                  "as the z-score panel) -- i.e. does optimal (OCE) hedging, not the model's own Q-delta, change "
                  "the held-out conclusion."),
        )
    else:
        gap_out = dict(status="too few converged OCE solves for a meaningful gap report")

    with open(GAP_RESULT_PATH, "w") as f:
        json.dump(gap_out, f, indent=2, default=_json_default)
    print(gap_out, flush=True)
    print("Wrote", GAP_RESULT_PATH, flush=True)


if __name__ == "__main__":
    main()
