r"""Step 4b: compare dynamics across the historical path -- fixed-contract
option changes, spot-surface dependence, surface PCA, vol clustering,
term-structure/skew changes, tails, front-expiry behaviour, runtime/failure
rates. The identical dy2 comparator is run over the SAME horizon (no
indefinite-rolling-simulator claim -- Historical Simulator task point 5).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class PCAResult:
    components: np.ndarray  # (n_components, n_features)
    explained_variance_ratio: np.ndarray
    scores: np.ndarray  # (n_dates, n_components)
    n_components_95pct: int


def surface_pca(price_matrix: np.ndarray, n_components: int = 5) -> PCAResult:
    """price_matrix: (n_dates, n_contracts), already in a common 'pure'
    unit so dates are directly comparable. Standard PCA on the
    mean-centred matrix via SVD (no external ML dependency)."""
    mean = price_matrix.mean(axis=0, keepdims=True)
    centered = price_matrix - mean
    U, S, Vt = np.linalg.svd(centered, full_matrices=False)
    var = S ** 2 / (price_matrix.shape[0] - 1)
    ratio = var / var.sum()
    cum = np.cumsum(ratio)
    n95 = int(np.searchsorted(cum, 0.95) + 1)
    k = min(n_components, Vt.shape[0])
    scores = U[:, :k] * S[:k]
    return PCAResult(components=Vt[:k], explained_variance_ratio=ratio[:k], scores=scores, n_components_95pct=n95)


@dataclass(frozen=True)
class VolClusteringReport:
    acf_abs_returns: np.ndarray  # autocorrelation of |returns| at lags 1..max_lag
    acf_returns: np.ndarray      # autocorrelation of raw returns (should be near 0 if no momentum)
    ljung_box_stat: float
    ljung_box_pvalue: float


def _acf(x: np.ndarray, max_lag: int) -> np.ndarray:
    x = x - x.mean()
    n = len(x)
    denom = np.sum(x ** 2)
    return np.array([np.sum(x[lag:] * x[:-lag]) / denom if lag > 0 else 1.0 for lag in range(1, max_lag + 1)])


def volatility_clustering(returns: np.ndarray, max_lag: int = 10) -> VolClusteringReport:
    from scipy.stats import chi2

    acf_abs = _acf(np.abs(returns), max_lag)
    acf_raw = _acf(returns, max_lag)
    n = len(returns)
    lb_stat = n * (n + 2) * np.sum([acf_abs[k - 1] ** 2 / (n - k) for k in range(1, max_lag + 1)])
    lb_p = float(1.0 - chi2.cdf(lb_stat, df=max_lag))
    return VolClusteringReport(acf_abs_returns=acf_abs, acf_returns=acf_raw, ljung_box_stat=float(lb_stat),
                                ljung_box_pvalue=lb_p)


@dataclass(frozen=True)
class SkewTermStructureReport:
    dates: list
    skew_25delta_proxy: np.ndarray  # (put_iv - call_iv) at a fixed moneyness pair, per date
    term_slope_proxy: np.ndarray    # (long_iv - short_iv) at fixed tenors, per date


def skew_and_term_structure(iv_surface: dict) -> SkewTermStructureReport:
    """iv_surface: {date_str: {(tenor,moneyness): iv}}. Uses the nearest
    available (tenor,moneyness) keys to fixed targets rather than requiring
    an exact grid match."""
    dates = sorted(iv_surface.keys())
    skew = np.full(len(dates), np.nan)
    term = np.full(len(dates), np.nan)
    for i, d in enumerate(dates):
        surf = iv_surface[d]
        keys = list(surf.keys())
        if not keys:
            continue
        tenors = sorted(set(k[0] for k in keys))
        if len(tenors) >= 1:
            short_t = tenors[0]
            long_t = tenors[-1]
            short_vals = [v for (t, m), v in surf.items() if t == short_t]
            long_vals = [v for (t, m), v in surf.items() if t == long_t]
            if short_vals and long_vals:
                term[i] = float(np.mean(long_vals) - np.mean(short_vals))
        moneys = sorted(set(k[1] for k in keys))
        if len(moneys) >= 2:
            lo_m, hi_m = moneys[0], moneys[-1]
            lo_vals = [v for (t, m), v in surf.items() if m == lo_m]
            hi_vals = [v for (t, m), v in surf.items() if m == hi_m]
            if lo_vals and hi_vals:
                skew[i] = float(np.mean(lo_vals) - np.mean(hi_vals))
    return SkewTermStructureReport(dates=dates, skew_25delta_proxy=skew, term_slope_proxy=term)


@dataclass(frozen=True)
class RuntimeFailureReport:
    n_dates: int
    n_converged: int
    n_failed: int
    failure_rate: float
    mean_wall_clock_seconds: float
    median_wall_clock_seconds: float
    failure_dates: list


def runtime_and_failure_rates(rows: list[dict]) -> RuntimeFailureReport:
    converged = [r for r in rows if "dlv_bates" in r and r["dlv_bates"].get("converged")]
    failed = [r for r in rows if "dlv_bates" not in r or not r["dlv_bates"].get("converged")]
    times = [r.get("wall_clock_seconds", np.nan) for r in rows]
    return RuntimeFailureReport(
        n_dates=len(rows), n_converged=len(converged), n_failed=len(failed),
        failure_rate=len(failed) / len(rows) if rows else float("nan"),
        mean_wall_clock_seconds=float(np.nanmean(times)) if times else float("nan"),
        median_wall_clock_seconds=float(np.nanmedian(times)) if times else float("nan"),
        failure_dates=[r["date"] for r in failed],
    )
